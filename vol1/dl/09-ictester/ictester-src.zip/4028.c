
/*
 *	4028.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 4028 test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	CD 4028
 *
 *	BCD to decimal decoder
 *
 *	Inputs:
 *		10	A
 *		13	B
 *		12	C
 *		11	D
 *
 *	Outputs:
 *		 1	4
 *		 2	2
 *		 3	0
 *		 4	7
 *		 5	9
 *		 6	5
 *		 7	6
 *		 9	8
 *		14	1
 *		15	3
 *
 *	The CD4028 is a BCD-to-decimal decoder consisting of 4 inputs (ABCD) and
 *	10 outputs. A BCD code applied to the 4 inputs results in a high level at the
 *	selected 1-of-10 decimal decoded outputs.
 *
 *	TI (acquired from Harris), and Renesas all indicate that input codes 10..15 product NO outputs.
 *	The CD4028BE chips I bought off Aliexpress product code 8, and the National Semiconductor data
 *	sheet indicates that they should map { 10, 11, 12, 13, 14, 15 } to { 8, 9, 8, 9, 8, 9 }.
 *
 *	So... we don't gate pass/fail on the results of the bonus codes, but we do present them for information.
*/

bool
test_4028 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

#define	A	10
#define	B	13
#define	C	12
#define	D	11

	uint8_t outputs [] = { A, B, C, D };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

#define	Y0	 3
#define	Y1	14
#define	Y2	 2
#define	Y3	15
#define	Y4	 1
#define	Y5	 6
#define	Y6	 7
#define	Y7	 4
#define	Y8	 9
#define	Y9	 5

	uint8_t inputs [] = { Y0, Y1, Y2, Y3, Y4, Y5, Y6, Y7, Y8, Y9 };
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 16; i++) {
		// set up BCD values
		dip_set_output (&dip, outputs [0], !!(i & 1));
		dip_set_output (&dip, outputs [1], !!(i & 2));
		dip_set_output (&dip, outputs [2], !!(i & 4));
		dip_set_output (&dip, outputs [3], !!(i & 8));
		sleep_us (10);

		// read back outputs
		bool values [NELEMENTS (inputs)];
		int which = -1;
		for (int j = 0; j < NELEMENTS (inputs); j++) {
			values [j] = dip_get_input (&dip, inputs [j]);
			if (values [j]) {
				if (which != -1) {
					if (pass) {
						if (sniff) return false;
						printf ("FAIL:  input pattern %d%d%d%d results in more than one output active (%d and %d are both on)\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1), which, j);
						pass = false;
					} else {
						if (sniff) return false;
						printf ("FAIL:  input pattern %d%d%d%d results in more than one output active (%d is also on)\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1), j);
					}
				}
				which = j;
			}
		}
		if (which == -1) {
			if (i < 10) {
				if (sniff) return false;
				printf ("FAIL:  input pattern %d%d%d%d does not result in any active outputs\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1));
				pass = false;
			} else {
				if (sniff) return false;
				printf ("INFO:  input pattern %d%d%d%d did not results in any output being active\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1));
			}
		}

		// assuming there was just one, see if it was the right one :-)
		if (pass) {
			if (i < 10) {								// 0000 .. 1001 inclusive decode as 0 .. 9 inclusive
				if (i != which) {
					if (sniff) return false;
					printf ("FAIL:  input pattern %d%d%d%d results in output %d, expected %d\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1), which, i);
					pass = false;
				}
			} else {									// codes 10..15 do not gate pass/fail, but we print them for info
				if (!sniff) {
					printf ("INFO:  input pattern %d%d%d%d results in output %d\n", !!(i & 8), !!(i & 4), !!(i & 2), !!(i & 1), which);
				}
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

