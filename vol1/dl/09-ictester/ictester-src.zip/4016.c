
/*
 *	4016.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 04	R. Krten		created
*/

#include "main.h"

/*
 *	CD 4016
 *
 *	Quad bilateral switch
 *
 *	Inputs:
 *		 1	I/O A1
 *		 2	I/O A2
 *		13	Control A
 *
 *		 3	I/O B1
 *		 4	I/O B2
 *		 5	Control B
 *
 *		 6	Control C
 *		 8	I/O C1
 *		 9	I/O C2
 *
 *		10	I/O D1
 *		11	I/O D2
 *		12	Control D
 *
 *	The RCA-CD4016A Series types are quad bilateral switches intended for the
 *	transmission or multiplexing of analog or digital signals.
 *
 *	Each of the four independent bilateral switches has a single control signal
 *	input which simultaneously biases both the p and n device in a given switch ON
 *	or OFF.
*/

#define	NUNITS	4

bool
test_4016 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t io [2][NUNITS] =
	{
		{ 1, 3, 8, 10 },								// ordered as "A" sets of the four switches
		{ 2, 4, 9, 11 }									// ordered as "B" sets of the four switches
	};

	uint8_t controls [NUNITS] = { 13, 5, 6, 12 };		// ordered as Control A .. D

	// controls are always outputs
	dip_make_outputs (&dip, controls, NUNITS);

	bool pass = true;

	for (int phase = 0; phase < 2; phase++) {
		int IN = phase == 0;
		int OUT = phase == 1;

		dip_make_inputs  (&dip, io [IN], NUNITS);
		dip_make_outputs (&dip, io [OUT], NUNITS);

		// disable controls, all inputs should read as tristate
		for (int u = 0; u < NUNITS; u++) {
			dip_set_output (&dip, controls [u], false);
		}

		// set all outputs to zero
		for (int o = 0; o < NUNITS; o++) {
			dip_set_output (&dip, io [OUT][o], false);
		}

		sleep_us (1);

		for (int i = 0; i < NUNITS; i++) {
			if (!dip_is_tristate (&dip, io [IN][i])) {
				if (sniff) return false;
				printf ("FAIL: unit %d is not tristate with low as input and low as control during phase %d\n", i, phase);
				pass = false;
			}
		}

		// set all outputs to one
		for (int o = 0; o < NUNITS; o++) {
			dip_set_output (&dip, io [OUT][o], true);
		}

		sleep_us (1);

		for (int i = 0; i < NUNITS; i++) {
			if (!dip_is_tristate (&dip, io [IN][i])) {
				if (sniff) return false;
				printf ("FAIL: unit %d is not tristate with high as input and low as control during phase %d\n", i, phase);
				pass = false;
			}
		}

		// enable controls, all inputs should read as the value we set for output
		for (int u = 0; u < NUNITS; u++) {
			dip_set_output (&dip, controls [u], true);
		}

		for (int v = 0; v < 2; v++) {
			// set outputs to v
			for (int o = 0; o < NUNITS; o++) {
				dip_set_output (&dip, io [OUT][o], v);
			}
			sleep_us (1);

			// verify that outputs match v
			for (int o = 0; o < NUNITS; o++) {
				if (dip_get_input (&dip, io [IN][o]) != v) {
					if (sniff) return false;
					printf ("FAIL: expected unit %d to be %d during phase %d\n", o, v, phase);
					pass = false;
				}
			}

		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

