
/*
 *	6830.c
 *
 *	(C) Copyright 2026 by Robert Krten, all rights reserved.
 *
 *	2026 04 28	R. Krten		created
*/

#include "main.h"

/*
 *	6830 MIKBUG PROM tester
 *
 *	*** THIS CHIP REQUIRES AN ADAPTOR SOCKET ***
 *
 *	This is the chip-tester view of the pinouts
 *
 *	Inputs:
 *		 1	A0		- on this chip, this is pin 24
 *		23	A1
 *		22	A2
 *		21	A3
 *		20	A4
 *		19	A5
 *		18	A6
 *		17	A7
 *		16	A8
 *		15	A9
 *
 *		14	CS3
 *		13	CS2
 *		11	-CS1
 *		10	CS0
 *
 *	Outputs:
 *		 2	D0
 *		 3	D1
 *		 4	D2
 *		 5	D3
 *		 6	D4
 *		 7	D5
 *		 8	D6
 *		 9	D7
 *
 *	The chip takes GND on pin 1 and VCC on pin 12.
 *	The adaptor socket routes:
 *		- GND from chip-tester pin 12 to chip pin 1
 *		- VCC from chip-tester pin 24 to chip pin 12
 *		- A0  from chip-tester pin  1 to chip pin 24
*/

// *************************************************
// *** UNTESTED -- We don't actually have a 6830 ***
// *************************************************

bool
test_6830 (void)
{
	if (sniff) return false;							// impossible to auto-detect

	dip_t dip;
	dip_init (&dip, 24, -1);

	//					   0   1   2   3   4   5   6   7   8   9  10  11  12  13
	uint8_t outputs [] = { 1, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 11, 10 };	// ordered A0..A9, CS3..0
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_CS3	10
	#define	O_CS2	11
	#define	O_NCS1	12
	#define	O_CS0	13

	uint8_t inputs [] = { 2, 3, 4, 5, 6, 7, 8, 9 };		// ordered D0..D7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	// test 1, enable everything and see if we can read any data at all
	dip_set_output (&dip, outputs [O_CS3],  1);
	dip_set_output (&dip, outputs [O_CS2],  1);
	dip_set_output (&dip, outputs [O_NCS1], 0);			// negative logic
	dip_set_output (&dip, outputs [O_CS0],  1);

	printf ("\n");
	char content [17] = { 0 };							// nul terminated at [16]
	for (int i = 0; i < 512; i++) {
		// set up address
		dip_set_outputs (&dip, outputs, i, 9);			// there are 9 address bits (A9 is always zero)

		sleep_us (1);
		uint8_t data = dip_get_inputs (&dip, inputs, 8);
		content [i % 16] = isprint (data) ? data : '.';

		if ((i % 16) == 0) {
			printf ("%04X ", i);
		}
		printf ("%02X ", data);
		if ((i % 8) == 0) {
			printf (" ");
		} else if ((i % 16) == 15) {
			printf (" %s\n", content);
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}

	return pass;
}

