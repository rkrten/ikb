
/*
 *	74_quad_gates.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 7400, 7402, 7408, 7432, 7486, etc. test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

// most of these gates have this pinout:
static bool
common (bool (*func) (bool a, bool b, bool y, int unit))
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 1, 4, 9, 12, 2, 5, 10, 13 };	// ordered A1, A2, A3, A4, B1, B2, B3, B4
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 3, 6, 8, 11 };				// ordered Y1, Y2, Y3, Y4
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 256; i++) {
		bool a1 = !!(i & 0x01);
		bool a2 = !!(i & 0x02);
		bool a3 = !!(i & 0x04);
		bool a4 = !!(i & 0x08);
		bool b1 = !!(i & 0x10);
		bool b2 = !!(i & 0x20);
		bool b3 = !!(i & 0x40);
		bool b4 = !!(i & 0x80);

		dip_set_outputs (&dip, outputs, i, 8);
		sleep_us (1);

		if (!func (a1, b1, dip_get_input (&dip, inputs [0]), 0)) pass = false;
		if (!func (a2, b2, dip_get_input (&dip, inputs [1]), 1)) pass = false;
		if (!func (a3, b3, dip_get_input (&dip, inputs [2]), 2)) pass = false;
		if (!func (a4, b4, dip_get_input (&dip, inputs [3]), 3)) pass = false;
		if (sniff && !pass) {
			return false;
		}
	}

	return pass;
}

// all these years, and I never noticed that the '02 is mirrored compared to all the others!
static bool
special_02 (bool (*func) (bool a, bool b, bool y, int unit))
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 2, 5, 8, 11, 3, 6, 9, 12 };	// ordered A1, A2, A3, A4, B1, B2, B3, B4
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 1, 4, 10, 13 };				// ordered Y1, Y2, Y3, Y4
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 256; i++) {
		bool a1 = !!(i & 0x01);
		bool a2 = !!(i & 0x02);
		bool a3 = !!(i & 0x04);
		bool a4 = !!(i & 0x08);
		bool b1 = !!(i & 0x10);
		bool b2 = !!(i & 0x20);
		bool b3 = !!(i & 0x40);
		bool b4 = !!(i & 0x80);

		dip_set_outputs (&dip, outputs, i, 8);
		sleep_us (1);

		if (!func (a1, b1, dip_get_input (&dip, inputs [0]), 0)) pass = false;
		if (!func (a2, b2, dip_get_input (&dip, inputs [1]), 1)) pass = false;
		if (!func (a3, b3, dip_get_input (&dip, inputs [2]), 2)) pass = false;
		if (!func (a4, b4, dip_get_input (&dip, inputs [3]), 3)) pass = false;
		if (sniff && !pass) {
			return false;
		}
	}

	return pass;
}

/*
 *	Compare expected vs actual
 *
 *	A B AND NAND OR NOR XOR
 *	- - --- ---- -- --- ---
 *	0 0   1    0  0   1   0
 *	0 1   1    0  1   0   1
 *	1 0   1    0  1   0   1
 *	1 1   0    1  1   0   0
*/

static bool
test_and (bool a, bool b, bool y, int unit)
{
	if (y != (a & b)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != A%d (%d) & B%d (%d)\n", unit, y, unit, a, unit, b);
		return false;
	}
	return true;
}

static bool
test_nand (bool a, bool b, bool y, int unit)
{
	if (y != !(a & b)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != -(A%d (%d) & B%d (%d))\n", unit, y, unit, a, unit, b);
		return false;
	}
	return true;
}

static bool
test_or (bool a, bool b, bool y, int unit)
{
	if (y != (a | b)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != A%d (%d) | B%d (%d)\n", unit, y, unit, a, unit, b);
		return false;
	}
	return true;
}

static bool
test_nor (bool a, bool b, bool y, int unit)
{
	if (y != !(a | b)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != -(A%d (%d) | B%d (%d))\n", unit, y, unit, a, unit, b);
		return false;
	}
	return true;
}

static bool
test_xor (bool a, bool b, bool y, int unit)
{
	if (y != (a ^ b)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != A%d (%d) ^ B%d (%d)\n", unit, y, unit, a, unit, b);
		return false;
	}
	return true;
}

bool
test_7400 (void)
{
	bool pass = common (test_nand);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

bool
test_7402 (void)
{
	bool pass = special_02 (test_nor);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

bool
test_7408 (void)
{
	bool pass = common (test_and);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

bool
test_7432 (void)
{
	bool pass = common (test_or);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

bool
test_7486 (void)
{
	bool pass = common (test_xor);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

