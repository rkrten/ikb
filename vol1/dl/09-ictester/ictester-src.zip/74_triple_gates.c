
/*
 *	74_triple_gates.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 7410 test module.
 *
 *	2025 11 03	R. Krten		created
*/

#include "main.h"

static bool
common (bool (*func) (bool a, bool b, bool c, bool y, int unit))
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 1, 3, 9, 2, 4, 10, 13, 5, 11 };	// ordered A1, A2, A3, B1, B2, B3, C1, C2, C3
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 12, 6, 8 };						// ordered Y1, Y2, Y3
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 512; i++) {
		bool a1 = !!(i & 0x001);
		bool a2 = !!(i & 0x002);
		bool a3 = !!(i & 0x004);
		bool b1 = !!(i & 0x008);
		bool b2 = !!(i & 0x010);
		bool b3 = !!(i & 0x020);
		bool c1 = !!(i & 0x040);
		bool c2 = !!(i & 0x080);
		bool c3 = !!(i & 0x100);

		dip_set_outputs (&dip, outputs, i, 9);
		sleep_us (1);

		if (!func (a1, b1, c1, dip_get_input (&dip, inputs [0]), 0)) pass = false;
		if (!func (a2, b2, c2, dip_get_input (&dip, inputs [1]), 1)) pass = false;
		if (!func (a3, b3, c3, dip_get_input (&dip, inputs [2]), 2)) pass = false;
		if (sniff && !pass) {
			return false;
		}
	}

	return pass;
}

static bool
test_nand (bool a, bool b, bool c, bool y, int unit)
{
	if (y != !(a & b & c)) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != -(A%d (%d) & B%d (%d) & C%d (%d)\n", unit, y, unit, a, unit, b, unit, c);
		return false;
	}
	return true;
}

bool
test_7410 (void)
{
	bool pass = common (test_nand);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

