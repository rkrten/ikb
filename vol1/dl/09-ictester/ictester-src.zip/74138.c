
/*
 *	74138.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 74138 test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74138
 *
 *	3-line to 8-line decoders / demultiplexers
 *
 *	Inputs:
 *		 1	A
 *		 2	B
 *		 3	C
 *		 4 -g2a
 *		 5 -g2b
 *		 6 g1
 *
 *	Outputs:
 *		 7	7
 *		 9	6
 *		10	5
 *		11	4
 *		12	3
 *		13	2
 *		14	1
 *		15	0
 *
 *	The 74138 decodes one of eight lines dependent on the conditions at the three
 *	binary select inputs and the three enable inputs.
 *	Two active-low and one active-high enable inputs reduce the need for external
 *	gates or inverters when expanding.
 *
 *	G1 must be high, and both G2A and G2B must be low, in order to decode ABC into
 *	an active low 0..7 output.
*/

bool
test_74138 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 2, 3, 6, 4, 5 };				// ordered A, B, C, G1, G2A, G2B
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A		0
	#define	O_B		1
	#define	O_C		2
	#define	O_G1	3
	#define	O_G2A	4
	#define	O_G2B	5

	uint8_t inputs [] = { 15, 14, 13, 12, 11, 10, 9, 7 };	// ordered Y0 .. Y7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;
	for (int g1 = 0; g1 < 2; g1++) {
		dip_set_output (&dip, outputs [O_G1], g1);
		for (int g2a = 0; g2a < 2; g2a++) {
			dip_set_output (&dip, outputs [O_G2A], g2a);
			for (int g2b = 0; g2b < 2; g2b++) {
				dip_set_output (&dip, outputs [O_G2B], g2b);

				for (int i = 0; i < 8; i++) {
					dip_set_outputs (&dip, outputs + O_A, i, 3);
					sleep_us (10);

					// read back outputs
					bool values [NELEMENTS (inputs)];
					int which = -1;
					for (int j = 0; j < NELEMENTS (inputs); j++) {
						values [j] = !dip_get_input (&dip, inputs [j]);	// apply negative logic for simplicity
						if (values [j]) {
							if (which == -1) {
								which = j;
							} else {
								if (pass) {
									if (sniff) return false;
									printf ("FAIL 1:  input pattern G1 %d==1 G2A %d==0 G2B %d==0 %d%d%d results in more than one output active (%d and %d are both on)\n", g1, g2a, g2b, !!(i & 1), !!(i & 2), !!(i & 4), which, j);
									pass = false;
								} else {
									if (sniff) return false;
									printf ("FAIL 2:  input pattern G1 %d==1 G2A %d==0 G2B %d==0 %d%d%d results in more than one output active (%d is also on)\n", g1, g2a, g2b, !!(i & 1), !!(i & 2), !!(i & 4), j);
								}
							}
						}
					}

					// if we don't have any, it might be ok -- after all, there are three enable bits; G1 = 1, G2A = 0, G2B = 0 to enable outputs
					if (!g1 || (g2a || g2b)) {
						if (which != -1) {
							if (sniff) return false;
							printf ("FAIL 3:  input pattern G1 %d==1 G2A %d==0 G2B %d==0 %d%d%d results in an output (%d) being active when we expected none.\n", g1, g2a, g2b, !!(i & 1), !!(i & 2), !!(i & 4), which);
							pass = false;
						}
					} else {
						if (pass) {
							if (i != which) {
								if (sniff) return false;
								if (which == -1) {
									printf ("FAIL 4:  input pattern G1 %d==1 G2A %d==0 G2B %d==0 %d%d%d doesn't result in any output, expected %d\n", g1, g2a, g2b, !!(i & 1), !!(i & 2), !!(i & 4), i);
								} else {
									printf ("FAIL 5:  input pattern G1 %d==1 G2A %d==0 G2B %d==0 %d%d%d results in %d, expected %d\n", g1, g2a, g2b, !!(i & 1), !!(i & 2), !!(i & 4), which, i);
								}
								pass = false;
							}
						}
					}
				}
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

