
/*
 *	74166.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 03	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74166
 *
 *	8-bit parallel-in / serial-out shift register
 *
 *	Inputs:
 *		 1	SER
 *		 2	A
 *		 3	B
 *		 4	C
 *		 5	D
 *		10	E
 *		11	F
 *		12	G
 *		14	H
 *		 9	-CLR
 *		 6	CLKINH
 *		 7	CLK
 *		15	SH/-LD
 *
 *	Outputs:
 *		13	QH
 *
 *	These parallel-in or serial-in, serial-out shift registers have a complexity of
 *	77 equivalent gates on a monolithic chip.
 *
 *	They feature gated clock inputs and an overriding clear input.
 *
 *	The parallel-in or serial-in modes are established by the shift/load input.
 *
 *	When high, this input enables the serial data input and couples the eight
 *	flip-flops for serial shifting with each clock pulse.
 *
 *	When low, the parallel (broadside) data inputs are enabled and synchronous
 *	loading occurs on the next clock pulse.
 *
 *	During parallel loading, serial data flow is inhibited.
 *
 *	Clocking is accomplished on the low-to-high-level edge of the clock pulse
 *	through a two-input positive NOR gate permitting one input to be used as a
 *	clock-enable or clock-inhibit function.
 *
 *	Holding either of the clock inputs high inhibits clocking; holding either low
 *	enables the other clock input.
 *
 *	This, of course, allows the system clock to be free-running and the register
 *	can be stopped on command with the other clock inputs.
 *
 *	The clock inhibit input should be changed to the high level only while the
 *	clock input is high.
 *
 *	A buffered, direct clear input overrides all other inputs, including the clock,
 *	and sets all flip-flops to zero.
*/

bool
test_74166 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 2, 3, 4, 5, 10, 11, 12, 14, 9, 6, 7, 15 };	// ordered { SER, A..H, -CLR, CLKINH, CLK, SH/-LD }
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum { O_SER, O_A, O_B, O_C, O_D, O_E, O_F, O_G, O_H, O_CLR, O_CLKINH, O_CLK, O_SHLD };

	uint8_t inputs [] = { 13 };							// only QH
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	// initialize -clear, shift/-load, clock inhibit, clock, and serial
	dip_set_output (&dip, outputs [O_CLR], false);		// device is currently cleared
	dip_set_output (&dip, outputs [O_SHLD], false);		// set to load
	dip_set_output (&dip, outputs [O_CLKINH], false);	// enable clock
	dip_set_output (&dip, outputs [O_CLK], false);		// clock active on rising edge
	dip_set_output (&dip, outputs [O_SER], false);		// initial serial data zero

	// test 1, output should be low while clear is low
	if (dip_get_input (&dip, inputs [0])) {
		if (sniff) return false;
		printf ("FAIL 1: output is high when clear is asserted\n");
		pass = false;
	}
	dip_set_output (&dip, outputs [O_CLR], true);		// release clear condition

//printf ("\n");

	// test 2, pick 16 random 8-bit words and clock them through
	for (int i = 0; i < 16; i++) {
		uint8_t v = rand() & 0xff;
		bool data [8];
//printf ("%02X (", v);
		dip_set_output (&dip, outputs [O_SHLD], false);		// set to load mode
		for (int bit = 0; bit < 8; bit++) {
			data [bit] = v & (1 << bit);
			dip_set_output (&dip, outputs [O_A + bit], data [bit]);
//printf ("%d", data [bit]);
		}
//printf (") => ");

		// clock data into shift registeres
		dip_set_output (&dip, outputs [O_CLK], true);
		dip_set_output (&dip, outputs [O_CLK], false);
		dip_set_output (&dip, outputs [O_SHLD], true);		// set to shift mode

		for (int clocks = 0; clocks < 8; clocks++) {
			bool qh = dip_get_input (&dip, inputs [0]);
//printf ("%d", qh);
			if (qh != data [7 - clocks]) {
				if (sniff) return false;
				printf ("FAIL 2: output at clock %d in pattern %02X is %d\n", clocks, v, qh);
				pass = false;
			}
			dip_set_output (&dip, outputs [O_CLK], true);	// clock data into the shift register
			dip_set_output (&dip, outputs [O_CLK], false);	// reset clock for next pulse
		}
//printf ("\n");
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

