
/*
 *	24_eeprom.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 24Cxxx EEPROM tester module
 *
 *	2025 11 21	R. Krten		created
*/

#include "main.h"

/*
 *	24Cxxx EEPROM
 *
 *	Various size I2C EEPROM modules.
 *
 *	Inputs:
 *		1	A0
 *		2	A1
 *
 *	I/O:
 *		5	SDA
 *		6	SCL
 *		7	WP
 *
 *	These devices provide serial electrically erasable and programmable read only memor (EEPROM).
 *	The device's cascadable feature allows up to 4 devices to share a common 2-wire bus.
 *	The device is optimized for use in many industrial and commercial applications where low power and low voltage operation are essential.
*/

static bool
test_24_common (dip_t *dip, int kilobits)
{
	return false;
}

bool
test_24c256 (void)
{
	dip_t dip;
	dip_init (&dip, 8, -1);

	bool pass = false;
	pass = test_24_common (&dip, 256);

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

