
/*
 *	74595.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 74595 test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74595
 *
 *	8-bit shift registers with 3-state output registers
 *
 *	Inputs:
 *		10	-SRCLR
 *		11	SRCLK
 *		12	RCLK
 *		13	-OE
 *		14	SER
 *
 *	Outputs:
 *		 1	QB
 *		 2	QC
 *		 3	QD
 *		 4	QE
 *		 5	QF
 *		 6	QG
 *		 7	QH
 *		 9	QH'
 *		15	QA
 *
 *	These devices are 8-bit serial-in parallel-out shift registers.
 *	The shift register is cleared when -SRCLR is low.
 *	Data is clocked from SER on the rising edge of SRCLK into the first stage of the shift regiser, and all other stages get the state of the previous stage.
 *	Data is clocked from the shift register to the storage register (output) on the rising edge.
*/

bool
test_74595 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

#define	SRCLR	10
#define	SRCLK	11
#define	RCLK	12
#define	OE		13
#define	SER		14

	uint8_t outputs [] = { SRCLR, SRCLK, RCLK, OE, SER };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	// reset chip inputs to known state
	dip_set_output (&dip, SRCLR, false);
	dip_set_output (&dip, SRCLK, false);
	dip_set_output (&dip, RCLK, false);
	dip_set_output (&dip, OE, false);
	dip_set_output (&dip, SER, false);

#define	QA	15
#define	QB	 1
#define	QC	 2
#define	QD	 3
#define	QE	 4
#define	QF	 5
#define	QG	 6
#define	QH	 7
#define	QHP	 9

	uint8_t inputs [] = { QA, QB, QC, QD, QE, QF, QG, QH, QHP };
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));
	dip_name_pin (&dip, QA, "QA");
	dip_name_pin (&dip, QB, "QB");
	dip_name_pin (&dip, QC, "QC");
	dip_name_pin (&dip, QD, "QD");
	dip_name_pin (&dip, QE, "QE");
	dip_name_pin (&dip, QF, "QF");
	dip_name_pin (&dip, QG, "QG");
	dip_name_pin (&dip, QH, "QH");
	dip_name_pin (&dip, QHP, "QH'");

	bool pass = true;

	// test 1, disable output enable and verify that all outputs are tristate
	dip_set_output (&dip, OE, true);					// negative logic; true means "output disabled"
	for (int i = 0; i < NELEMENTS (inputs); i++) {
		if (inputs [i] == QHP) continue;				// QH' is *not* affected by -OE
		if (!dip_is_tristate (&dip, inputs [i])) {
			if (sniff) return false;
			printf ("FAIL 1: -OE is true, but output %s is not tri-state (it's stuck %s)\n", dip_pin_name (&dip, inputs [i]), dip_get_input (&dip, inputs [i]) ? "high" : "low");
			pass = false;
		}
	}

	// test 2, enable output enable and verify that the outputs are not tristate
	dip_set_output (&dip, OE, false);					// negative logic; false means "output enabled"
	for (int i = 0; i < NELEMENTS (inputs); i++) {
		if (dip_is_tristate (&dip, inputs [i])) {
			if (sniff) return false;
			printf ("FAIL 2: -OE is false, but output %s is tri-state\n", dip_pin_name (&dip, inputs [i]));
			pass = false;
		}
	}

	// test 3, reset the device so that all outputs are off
	dip_set_output (&dip, SRCLR, false);				// clear
	dip_set_output (&dip, SRCLR, true);					// restore
	dip_set_output (&dip, RCLK, true);					// shift register data is stored in the storage register on the rising edge
	dip_set_output (&dip, RCLK, false);
	for (int i = 0; i < NELEMENTS (inputs); i++) {
		if (dip_get_input (&dip, inputs [i])) {
			if (sniff) return false;
			printf ("FAIL 3: %s is high after reset\n", dip_pin_name (&dip, inputs [i]));
			pass = false;
		}
	}

	// test 4, shift data through, one bit at a time, clock both the shift register and the storage register, and verify data appears as expected
	dip_set_output (&dip, SER, true);					// set initial input bit to high
	dip_set_output (&dip, SRCLR, false);				// clear
	dip_set_output (&dip, SRCLR, true);					// restore
	for (int i = 0; i < 8; i++) {
		dip_set_output (&dip, SRCLK, true);				// clocks on rising edge (shift register)
		dip_set_output (&dip, SRCLK, false);
		dip_set_output (&dip, SER, false);				// all subsequent inputs are low
		dip_set_output (&dip, RCLK, true);				// clocks on rising edge (shift register -> storage register)
		dip_set_output (&dip, RCLK, false);
		sleep_us (1);

//		printf ("A B C D E F G H H' => ");
		for (int bit = 0; bit < NELEMENTS (inputs); bit++) {
			bool value = dip_get_input (&dip, inputs [bit]);
//			printf ("%d ", value);
			if (bit == i) {
				if (!value) {
					if (sniff) return false;
					printf ("FAIL 4: expected output %s to be high for shift count %d\n", dip_pin_name (&dip, inputs [bit]), i);
					pass = false;
				}
			} else {
				if (i == 7 && inputs [bit] == QHP) {
					if (!value) {
						if (sniff) return false;
						printf ("FAIL 5: expected output %s to be high for shift count %d\n", dip_pin_name (&dip, inputs [bit]), i);
						pass = false;
					}
				} else {
					if (value) {
						if (sniff) return false;
						printf ("FAIL 6: expected output %s to be low for shift count %d\n", dip_pin_name (&dip, inputs [bit]), i);
						pass = false;
					}
				}
			}
		}
//		printf ("\n");
	}

	// one could add more tests, but this at least verifies basic functionality

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

