
/*
 *	74259.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74259
 *
 *	8-bit addressable latch
 *
 *	Inputs:
 *		 1	S0
 *		 2	S1
 *		 3	S2
 *		13	D
 *		14	-G
 *		15	-CLR
 *
 *	Outputs:
 *		 4	Q0
 *		 5	Q1
 *		 6	Q2
 *		 7	Q3
 *		 9	Q4
 *		10	Q5
 *		11	Q6
 *		12	Q7
 *
 *	These 8-bit addressable latches are designed for general purpose storage applications in digital
 *	systems. Specific uses include working registers, serial-holding registers, and active-high
 *	decoders or demultiplexers. They are multifunctional devices capable of storing single-line data in
 *	eight addressable latches, and being a 1-of-8 decoder or demultiplexer with active-high outputs.
 *
 *	Four distinct modes of operation are selectable by controlling the clear (CLR) and enable (G)
 *	inputs as enumerated in the function table. In the addressable-latch mode, data at the data-in
 *	terminal is written into the addressed latch. The addressed latch will follow the data input with
 *	all unaddressed latches remaining in their previous states. In the memory mode, all latches remain
 *	in their previous states and are unaffected by the data or address inputs. To eliminate the
 *	possibility of entering erroneous data in the latches, enable G should be held high (inactive)
 *	while the address lines are changing. In the 1-of-8 decoding or demultiplexing mode, the addressed
 *	output will follow the level of the D input with all other outputs low. In the clear mode, all
 *	outputs are low and unaffected by the address and data inputs.
*/

bool
test_74259 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 2, 3, 13, 14, 15 };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum { O_S0, O_S1, O_S2, O_D, O_G, O_CLR };

	uint8_t inputs [] = { 4, 5, 6, 7, 9, 10, 11, 12};	// ordered Q0..7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;


	// test 1, with clear active and enable inactive, all outputs should be low regardless of D
	dip_set_output (&dip, outputs [O_CLR], false);		// assert clear
	dip_set_output (&dip, outputs [O_G], true);			// deassert enable
	for (int d = 0; d < 2; d++) {
		dip_set_output (&dip, outputs [O_D], d);		// set data to desired value
		for (int i = 0; i < NELEMENTS (inputs); i++) {
			if (dip_get_input (&dip, inputs [i])) {
				if (sniff) return false;
				printf ("FAIL 1: with clear asserted, enable deasserted, and D=%d, Q%d is high\n", d, i);
				pass = false;
			}
		}
	}

	// test 2, with clear and enable both active, we have a 3-to-8 line demultiplexer, all outputs low except addressed one, which follows D
	dip_set_output (&dip, outputs [O_CLR], false);		// assert clear
	dip_set_output (&dip, outputs [O_G], false);		// assert enable

	for (int d = 0; d < 2; d++) {
		dip_set_output (&dip, outputs [O_D], d);		// set data to desired value
		for (int a = 0; a < 8; a++) {
			dip_set_outputs (&dip, outputs + O_S0, a, 3);
			for (int q = 0; q < 8; q++) {
				if (q == a) {
					if (dip_get_input (&dip, inputs [q]) != d) {
						if (sniff) return false;
						printf ("FAIL 2: with clear and enable asserted, the selected Q%d should have been %d\n", q, d);
						pass = false;
					}
				} else {
					if (dip_get_input (&dip, inputs [q])) {
						if (sniff) return false;
						printf ("FAIL 3: with clear and enable asserted, the unselected Q%d should have been 0\n", q);
						pass = false;
					}
				}
			}
		}
	}

	// test 3, with clear disabled, enable controls latching of data into output; data is immutable when enable is disabled.
	dip_set_output (&dip, outputs [O_CLR], true);		// deassert clear
	for (int i = 0; i < 10; i++) {
		uint8_t r = rand() & 0xff;
		// write random pattern into memory

		dip_set_output (&dip, outputs [O_G], true);		// disable

		for (int q = 0; q < 8; q++) {
			dip_set_outputs (&dip, outputs + O_S0, q, 3);	// set up address
			// write data
			dip_set_output (&dip, outputs [O_G], false);	// enable
			bool d = r & (1 << q);
			dip_set_output (&dip, outputs [O_D], d);
			if (dip_get_input (&dip, inputs [q]) != d) {
				if (sniff) return false;
				printf ("FAIL 4: with clear disabled, chip enabled, writing %d to latch %d failed\n", d, q);
				pass = false;
			}
			dip_set_output (&dip, outputs [O_G], true);	// disable, this makes the data sticky in that location
		}

		// now verify that the data is correct for all latch outputs
		for (int q = 0; q < 8; q++) {
			dip_set_outputs (&dip, outputs + O_S0, q, 3);	// set up address
			bool d = r & (1 << q);
			if (dip_get_input (&dip, inputs [q]) != d) {
				if (sniff) return false;
				printf ("FAIL 5: with clear and chip disabled, latch %d no longer contains expected value %d\n", q, d);
				pass = false;
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

