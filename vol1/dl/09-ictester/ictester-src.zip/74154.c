
/*
 *	74154.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 4028 test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74154
 *
 *	4-line to 16-line decoders / demultiplexers
 *
 *	Inputs:
 *		18	-G1
 *		19	-G2
 *		23	A
 *		22	B
 *		21	C
 *		20	D

 *	Outputs:
 *		 1	0
 *		 2	1
 *		 3	2
 *		 4	3
 *		 5	4
 *		 6	5
 *		 7	6
 *		 8	7
 *		 9	8
 *		10	9
 *		11	10
 *		13	11
 *		14	12
 *		15	13
 *		16	14
 *		17	15
 *
 *	Each of these 4-line-to-16-line decoders utilizes TTL circuitry to decode four
 *	binary-coded inputs into one of sixteen mutually exclusive outputs when both
 *	the strobe inputs, G1 and G2, are LOW.
 *	The demultiplexing function is performed by using the 4 input lines to address
 *	the output line, passing data from one of the strobe inputs with the other
 *	strobe input LOW.
 *	When either strobe input is HIGH, all outputs are HIGH.
 *	These demultiplexers are ideally suited for implementing high-performance
 *	memory decoders.
 *	All inputs are buffered and input clamping diodes are provided to minimize
 *	transmission-line effects and thereby simply system design.
*/

bool
test_74154 (void)
{
	dip_t dip;
	dip_init (&dip, 24, -1);

	uint8_t outputs [] = { 23, 22, 21, 20, 18, 19 };				// ordered A, B, C, D, G1, G2
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A		0
	#define	O_B		1
	#define	O_C		2
	#define	O_D		3
	#define	O_G1	4
	#define	O_G2	5

	uint8_t inputs [] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17 };	// ordered Y0 .. Y15
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;
	for (int g1 = 0; g1 < 2; g1++) {
		dip_set_output (&dip, outputs [O_G1], g1);
		for (int g2 = 0; g2 < 2; g2++) {
			dip_set_output (&dip, outputs [O_G2], g2);
			for (int i = 0; i < 16; i++) {
				dip_set_outputs (&dip, outputs + O_A, i, 4);
				sleep_us (10);

				// read back outputs
				bool values [NELEMENTS (inputs)];
				int which = -1;
				for (int j = 0; j < NELEMENTS (inputs); j++) {
					values [j] = !dip_get_input (&dip, inputs [j]);	// apply negative logic for simplicity
					if (values [j]) {
						if (which == -1) {
							which = j;
						} else {
							if (pass) {
								if (sniff) return false;
								printf ("FAIL 1:  input pattern G1 %d==0 G2 %d==0 %d%d%d%d results in more than one output active (%d and %d are both on)\n",
										g1, g2, !!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8), which, j);
								pass = false;
							} else {
								if (sniff) return false;
								printf ("FAIL 2:  input pattern G1 %d==1 G2 %d==0 G2B %d==0 %d%d%d%d results in more than one output active (%d is also on)\n",
										g1, g2, !!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8), j);
							}
						}
					}
				}

				// if we don't have any, it might be ok -- after all, there are two enable bits (both must be low)
				if (g1 || g2) {
					if (which != -1) {
						if (sniff) return false;
						printf ("FAIL 3:  input pattern G1 %d==0 G2 %d==0 %d%d%d%d results in an output (%d) being active when we expected none.\n",
								g1, g2, !!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8), which);
						pass = false;
					}
				} else {
					if (pass) {
						if (i != which) {
							if (sniff) return false;
							if (which == -1) {
								printf ("FAIL 4:  input pattern G1 %d==0 G2 %d==0 %d%d%d%d doesn't result in any output, expected %d\n",
										g1, g2, !!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8), i);
							} else {
								printf ("FAIL 5:  input pattern G1 %d==0 G2 %d==0 %d%d%d%d results in %d, expected %d\n",
										g1, g2, !!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8), which, i);
							}
							pass = false;
						}
					}
				}
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

