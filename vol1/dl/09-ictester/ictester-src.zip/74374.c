
/*
 *	74374.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74374
 *
 *	Octal d-type edge-triggered flip-flops
 *
 *	Inputs:
 *		 3	1D
 *		 4	2D
 *		 7	3D
 *		 8	4D
 *		13	5D
 *		14	6D
 *		17	7D
 *		18	8D
 *		 1	-OC
 *		11	CLK
 *
 *	Outputs:
 *		 2	1Q
 *		 5	2Q
 *		 6	3Q
 *		 9	4Q
 *		12	5Q
 *		15	6Q
 *		16	7Q
 *		19	8Q
 *
 *	These 8-bit registers feature 3-state outputs designed specifically for driving highly capacitive
 *	or relatively low-impedance loads.
 *	The high-impedance 3-state and increased high-logic-level drive provide these registers with the
 *	capability of being connected directly to and driving the bus lines in a bus-organized system
 *	without need for interface or pullup components.
 *	These devices are particularly attractive for implementing buffer registers, I/O ports, bidirectional
 *	bus drivers, and working registers.
 *
 *	The eight flip-flops of the 'LS374 and 'S374 are edge-triggered D-type flip-flops.
 *	On the positive transition of the clock, the Q outputs are set to the logic states that were set up
 *	at the D inputs.
*/

bool
test_74374 (void)
{
	dip_t dip;
	dip_init (&dip, 20, -1);

	uint8_t outputs [] = { 3, 4, 7, 8, 13, 14, 17, 18, 1, 11 };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum {  O_1D, O_2D, O_3D, O_4D, O_5D, O_6D, O_7D, O_8D, O_OC, O_CLK };

	uint8_t inputs [] = { 2, 5, 6, 9, 12, 15, 16, 19 };	// ordered Q0..7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	dip_set_output (&dip, outputs [O_OC], false);		// enable outputs, @@@ we don't test tristate yet
	dip_set_output (&dip, outputs [O_CLK], false);		// clock is rising edge

	bool pass = true;

	// test 1, write random patterns into the flip-flop and try to alter them post latch
	for (int p = 0; p < 20; p++) {
		uint8_t r = rand() & 0xff;
		dip_set_outputs (&dip, outputs, r, 8);
		dip_set_output (&dip, outputs [O_CLK], true);	// clock data into outputs
		dip_set_output (&dip, outputs [O_CLK], false);	// rearm clock for next loop
		for (int bit = 0; bit < 8; bit++) {
			bool v = r & (1 << bit);
			if (dip_get_input (&dip, inputs [bit]) != v) {
				if (sniff) return false;
				printf ("FAIL 1: unable to write pattern %02X bit %d into Q%d\n", r, v, bit);
				pass = false;
			}
		}

		// now write anti-pattern, original should not change
		for (int bit = 0; bit < 8; bit++) {
			bool v = r & (1 << bit);
			dip_set_output (&dip, outputs [bit], !v);
			if (dip_get_input (&dip, inputs [bit]) != v) {
				if (sniff) return false;
				printf ("FAIL 2: pattern %02X bit %d changed in Q%d\n", r, v, bit);
				pass = false;
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

