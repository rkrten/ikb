
/*
 *	io.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	I/O abstraction Layer
 *
 *	2025 11 08	R. Krten		created
*/

#include "main.h"

/*
 *	GPIO pin maps
*/

#define	GROUND	255
#define	VCC		254

static uint8_t gpio_primary_inputs [] = {
	// regular pins on the 40-pin ZIF
	P_PIN_A1,	P_PIN_A2,	P_PIN_A3,	P_PIN_A4,	P_PIN_A5,
	P_PIN_A6,	P_PIN_A7,	P_PIN_A8,	P_PIN_A9,	P_PIN_A10,
	P_PIN_B1,	P_PIN_B2,	P_PIN_B3,	P_PIN_B4,	P_PIN_B5,
	P_PIN_B6,	P_PIN_B7,	P_PIN_B8,	P_PIN_B9,	P_PIN_B10,
};

static uint8_t gpio_primary_spares [] = {
	// extra pins that should be inputs by default so that they're not driving
	P_26,		P_27,
};

static uint8_t gpio_secondary_inputs [] = {
	// regular pins on the 40-pin ZIF
	S_PIN_A11,	S_PIN_A12,	S_PIN_A13,	S_PIN_A14,	S_PIN_A15,
	S_PIN_A16,	S_PIN_A17,	S_PIN_A18,	S_PIN_A19,	S_PIN_B11,
	S_PIN_B12,	S_PIN_B13,	S_PIN_B14,	S_PIN_B15,	S_PIN_B16,
	S_PIN_B17,	S_PIN_B18,	S_PIN_B19,
};

static uint8_t gpio_secondary_spares [] = {
	// extra pins that should be inputs by default so that they're not driving
	S_20,		S_21,		S_22,		S_26,		S_27,
	S_28,
};

void
make_input (uint8_t pin)
{
	gpio_set_function (pin, GPIO_FUNC_SIO);
	gpio_set_dir (pin, GPIO_IN);
	gpio_disable_pulls (pin);
}

void
make_inputs (uint8_t *array, int n)
{
	for (int i = 0; i < n; i++) {
		make_input (array [i]);
	}
}

void
make_output (uint8_t pin)
{
	gpio_set_function (pin, GPIO_FUNC_SIO);
	gpio_set_dir (pin, GPIO_OUT);
}

void
make_outputs (uint8_t *array, int n)
{
	for (int i = 0; i < n; i++) {
		make_output (array [i]);
	}
}

bool
is_tristate (int p)
{
	gpio_pull_down (p);
	sleep_us (5);										// devices like the 4051 need more than the usual 1 us to "settle"
	if (gpio_get (p)) {
		gpio_disable_pulls (p);
		return false;									// we should have been able to pull it down
	}

	gpio_pull_up (p);
	sleep_us (5);
	if (!gpio_get (p)) {
		gpio_disable_pulls (p);
		return false;									// we should have been able to pull it up
	}

	return true;
}

/*
 *	write_byte_595 (byte)
 *	dclock (v)
 *
 *	Writes 1 byte in MSB order to the '595 shift register that controls the grounding pins.
*/

static void
dclock (bool v)
{
	// @@@ stolen from call processing
	if (v) {
		for (int i = 0; i < 8; i++) {					// 8 works
			gpio_put (P_CLOCK, 1);
		}
	} else {
		for (int i = 0; i < 5; i++) {					// 5 works
			gpio_put (P_CLOCK, 0);
		}
	}
}

static void
write_byte_595 (uint8_t value)
{
	for (int bit = 7; bit >= 0; bit--) {
		gpio_put (P_CLOCK, 0);
		gpio_put (P_DATA, !!(value & (1 << bit)));
		gpio_put (P_CLOCK, 1);
	}

	// we need a final clock to clock the data from the shift register to the output register
	gpio_put (P_CLOCK, 0);
	gpio_put (P_CLOCK, 1);
}

static void
gnd (uint8_t pin)
{
	switch (pin) {
	case	4:	pin = 0x80;	break;						// 8 pin
	case	7:	pin = 0x40;	break;						// 14 pin
	case	8:	pin = 0x20;	break;						// 16 pin
	case	9:	pin = 0x10;	break;						// 18 pin
	case	10:	pin = 0x08;	break;						// 20 pin
	case	12:	pin = 0x04;	break;						// 24 pin
	case	14:	pin = 0x02;	break;						// 28 pin
	case	16:	pin = 0x01;	break;						// 32 pin
	default:	pin = 0;	break;						// invalid or pin 20 (which is always ground); turn off drive
	}

	write_byte_595 (pin);
}

/*
 *	UART commands from primary to secondary
 *
 *	At 7.8M baud, 1 start bit, 8 data bits, no parity, and one stop bit (10 bits transmitted) we're at 1.28 us per byte.
 *	Measurements 2025-12-08 show that total TX/RX time is 20us, so we can do 50k transactions per second.
 *	And it's reliable!
*/

#define	BAUD_RATE	 7812500							// fastest speed possible (page 416 of RP2040 data sheet) -- 125e6 / 16

static uint8_t *
command (uint8_t *tx)
{
	for (int retry = 0; retry < 5; retry++) {
		int drain = SERIAL_MSG_SIZE * 8;
		while (drain-- && uart_is_readable (uart0)) {
			uint8_t ch = uart_getc (uart0);
			printf ("    drained %02X %c\n", ch, isprint (ch) ? ch : '.');
		}
		// write out the command; we're assuming it'll be buffered in the incoming FIFOs, so it's safe to write out all at once.
		for (int i = 0; tx [i]; i++) {
			uart_putc (uart0, tx [i]);
		}
		uart_putc (uart0, 0);								// write the framing byte
		uart_tx_wait_blocking (uart0);
		uint64_t final = time_us_64 () + 750;				// set timeout per retry

		while (time_us_64 () < final) {
			if (uart_is_readable (uart0)) {
				uint8_t ch = uart_getc (uart0);
				uint8_t *result = cobs_decode (ch);
				if (result) {
					return result;
				}
			}
		}
	}

	return NULL;										// timed out
}

bool
cmd_present (void)
{
	uint8_t tx [] = { 0x00, 'P', 'R', 'E', 'S', 0x00};
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	return rx && rx [0] == 2 && !memcmp (rx + 1, "OK", rx [0]);
}

bool
cmd_reset_hw_secondary (void)
{
	uint8_t tx [] = { 0x00, 'R', 'E', 'S', 'E', 'T', 0x00 };
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	return rx && rx [0] == 2 && !memcmp (rx + 1, "OK", rx [0]);
}

static bool
cmd_make_output (int gpio)
{
	uint8_t tx [] = { 0x00, 'M', 'K', 'O', gpio, 0x00};
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	return rx && rx [0] == 2 && !memcmp (rx + 1, "OK", rx [0]);
}

static bool
cmd_make_input (int gpio)
{
	uint8_t tx [] = { 0x00, 'M', 'K', 'I', gpio, 0x00};
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	return rx && rx [0] == 2 && !memcmp (rx + 1, "OK", rx [0]);
}

static bool
cmd_gpio_put (int gpio, bool val)
{
	uint8_t tx [] = { 0x00, 'S', 'E', gpio, val, 0x00 };
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	return rx && rx [0] == 2 && !memcmp (rx + 1, "OK", rx [0]);
}

static bool
cmd_gpio_get (int gpio)
{
	uint8_t tx [] = { 0x00, 'G', 'E', gpio, 0x00 };
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	if (rx && rx [0] == 3 && rx [1] == 'O' && rx [2] == 'K') {
		return rx [3];
	}

	printf ("Unable to get remote GPIO pin value %d\n", gpio);
	return false;
}

static bool
cmd_is_tristate (int gpio)
{
	uint8_t tx [] = { 0x00, 'T', 'S', gpio, 0x00 };
	tx [0] = sizeof (tx) - 2;
	cobs_encode (tx);

	uint8_t *rx = command (tx);

	if (rx && rx [0] == 3 && rx [1] == 'O' && rx [2] == 'K') {
		return rx [3];
	}

	printf ("Unable to get remote GPIO pin %d tri-state value\n", gpio);
	return false;
}

void
detect_secondary (void)
{
	printf ("Detecting secondary...\n");
	printf ("%d\n", cmd_present ());
}

/*
 *	Configuration Detection
 *
 *	Upon startup, we first call is_standalone() to detect if there's a secondary present.
 *	If so, we're done -- this is the "maximum" configuration.
 *
 *	If there's no secondary present, then we call is_loopback() to see if we have looped back the primary PICO to control a few of the pins from the secondary.
 *	Loopback detection is based on sending a few random characters out, and expecting them to come back (because RX and TX are shorted on the loopback connector).
*/

static bool
is_standalone (void)
{
	return !cmd_present ();								// send a presence detect command; if successful, then we're not stand alone
}

static bool
is_loopback (void)
{
	uint8_t values [4];

	for (int i = 0; i < NELEMENTS (values); i++) {
		values [i] = rand () & 0xff;					// we've determined that there's no secondary, so we can transmit anything we want
	}

	// clear out any RX characters that might be lurking
	for (int i = 0; i < 8 * SERIAL_MSG_SIZE; i++) {
		if (uart_is_readable (uart0)) {
			uint8_t v = uart_getc (uart0);
		} else {
			break;
		}
	}

	// write out the test pattern; we're assuming it'll be buffered in the incoming FIFOs, so it's safe to write out all at once.
	for (int i = 0; i < NELEMENTS (values); i++) {
		uart_putc (uart0, values [i]);
	}
	uart_tx_wait_blocking (uart0);

	// at this point, the data should be waiting for us
	bool pass = true;
	for (int i = 0; i < NELEMENTS (values); i++) {
		if (uart_is_readable (uart0)) {
			uint8_t v = uart_getc (uart0);
			if (v != values [i]) {
				pass = false;
				printf ("is_loopback [%d] read 0x%02X but expected %02X\n", i, v, values [i]);
			}
		} else {
			pass = false;
			break;
		}
	}

	return pass;
}

void
loopback_test (void)
{
	printf ("Loopback test result %d\n", is_loopback ());
}

/*
 *	zif_to_hal (pin)
 *
 *	The 40-pin ZIF socket is managed by a lone PICO or two PICOs working together.
 *	The zif_to_hal() function converts the ZIF pin to a hal_pin_t which tells us which PICO is
 *	responsible for managing the pin, and the GPIO number on that PICO.
 *
 *	Tables are provided to handle the supported configurations.
 *	The table is selected upon first use (the configuration won't change during runtime).
*/

#define	INVALID	{PICO_INVALID, 0}						// returned when a pin is not used; should never happen
#define	L		PICO_LOCAL								// GPIO is based on primary PICO
#define	R		PICO_REMOTE								// GPIO is based on secondary PICO

hal_pin_t
zif_to_hal (int pin)
{
	// this is the preferred configuration: two PICOs; supports 40 pin devices
	static hal_pin_t mapping_dual [] =
	{
		{L, P_PIN_A1},  {L, P_PIN_A2},  {L, P_PIN_A3},  {L, P_PIN_B3},  {L, P_PIN_A5},	// pins  1.. 5
		{L, P_PIN_A6},  {L, P_PIN_A7},  {L, P_PIN_A8},  {L, P_PIN_A9},  {L, P_PIN_A10},	// pins  6..10
		{R, S_PIN_A11}, {R, S_PIN_A12}, {R, S_PIN_A13}, {R, S_PIN_A14}, {R, S_PIN_A15},	// pins 11..15
		{R, S_PIN_A16}, {R, S_PIN_A17}, {R, S_PIN_A18}, {R, S_PIN_A19}, INVALID,		// pins 16..20 (20 == GROUND)
		{R, S_PIN_B19}, {R, S_PIN_B18}, {R, S_PIN_B17}, {R, S_PIN_B16}, {R, S_PIN_B15},	// pins 21..25
		{R, S_PIN_B14}, {R, S_PIN_B13}, {R, S_PIN_B12}, {R, S_PIN_B11}, {L, P_PIN_B10},	// pins 26..30
		{L, P_PIN_B9},  {L, P_PIN_B8},  {L, P_PIN_B7},  {L, P_PIN_B6},  {L, P_PIN_B5},	// pins 31..35
		{L, P_PIN_B4},  {L, P_PIN_A4},  {L, P_PIN_B2},  {L, P_PIN_B1},  INVALID,		// pins 36..40 (40 == VCC)
	};

	// this is the economy version: one PICO, but with a loopback connector; supports 24 pin devices (note the P_26 and P_27 parts)
	static hal_pin_t mapping_standalone_with_loopback [] =
	{
		{L, P_PIN_A1},  {L, P_PIN_A2},  {L, P_PIN_A3},  {L, P_PIN_B3},  {L, P_PIN_A5},	// pins  1.. 5
		{L, P_PIN_A6},  {L, P_PIN_A7},  {L, P_PIN_A8},  {L, P_PIN_A9},  {L, P_PIN_A10},	// pins  6..10
		{L, P_26},      INVALID,        INVALID,        INVALID,        INVALID,		// pins 11..15
		INVALID,        INVALID,        INVALID,        INVALID,        INVALID,		// pins 16..20 (20 == GROUND)
		INVALID,        INVALID,        INVALID,        INVALID,        INVALID,		// pins 21..25
		INVALID,        INVALID,        INVALID,        {L, P_27},      {L, P_PIN_B10},	// pins 26..30
		{L, P_PIN_B9},  {L, P_PIN_B8},  {L, P_PIN_B7},  {L, P_PIN_B6},  {L, P_PIN_B5},	// pins 31..35
		{L, P_PIN_B4},  {L, P_PIN_A4},  {L, P_PIN_B2},  {L, P_PIN_B1},  INVALID,		// pins 36..40 (40 == VCC)
	};

	// this is the economy version where someone forgot to install the loopback connector; supports 20 pin devices
	static hal_pin_t mapping_standalone_no_loopback [] =
	{
		{L, P_PIN_A1},  {L, P_PIN_A2},  {L, P_PIN_A3},  {L, P_PIN_B3},  {L, P_PIN_A5},	// pins  1.. 5
		{L, P_PIN_A6},  {L, P_PIN_A7},  {L, P_PIN_A8},  {L, P_PIN_A9},  {L, P_PIN_A10},	// pins  6..10
		INVALID,        INVALID,        INVALID,        INVALID,        INVALID,		// pins 11..15
		INVALID,        INVALID,        INVALID,        INVALID,        INVALID,		// pins 16..20 (20 == GROUND)
		INVALID,        INVALID,        INVALID,        INVALID,        INVALID,		// pins 21..25
		INVALID,        INVALID,        INVALID,        INVALID,        {L, P_PIN_B10},	// pins 26..30
		{L, P_PIN_B9},  {L, P_PIN_B8},  {L, P_PIN_B7},  {L, P_PIN_B6},  {L, P_PIN_B5},	// pins 31..35
		{L, P_PIN_B4},  {L, P_PIN_A4},  {L, P_PIN_B2},  {L, P_PIN_B1},  INVALID,		// pins 36..40 (40 == VCC)
	};

	static hal_pin_t *mapping = NULL;

	if (!mapping) {
		if (is_standalone ()) {
			if (is_loopback ()) {
				mapping = mapping_standalone_with_loopback;
				mode = "Standalone with loopback";
			} else {
				mapping = mapping_standalone_no_loopback;
				mode = "Standalone, no loopback";
			}
		} else {
			mapping = mapping_dual;
			mode = "Dual PICO";
		}
	}

	// pin numbers start at 1, all arrays are the same size
	if (pin > 0 && pin <= NELEMENTS (mapping_dual)) {
		return mapping [pin - 1];
	}
	return (hal_pin_t) { PICO_INVALID, 0 };
}

/*
 *	init_hw ()
 *	reset_hw ()
 *
 *	The init_hw() function initializes the hardware and determines whether the board is acting as a primary or a secondary.
 *	The determination is made based on GP22 -- it's a pull-down on the secondary, and a pull-up on the primary (it's also
 *	used as the DATA pin feeding the 74HC595 on the primary, but that's configured later, once we sort things out).,
 *	The reset_hw() function resets the hardware between tests.
*/

void
reset_hw (void)
{
	// reset local hardware, whether on the primary or secondary
	if (primary) {
		make_inputs (gpio_primary_inputs, NELEMENTS (gpio_primary_inputs));
		if (!cmd_reset_hw_secondary ()) {
			printf ("Unable to reset secondary\n");
		}
		gnd (0);
	} else {
		make_inputs (gpio_secondary_inputs, NELEMENTS (gpio_secondary_inputs));
	}
}

void
init_hw (void)
{
	// determine if we are primary (GP22 pulled up) or secondary (GP22 pulled down)
	gpio_set_function (22, GPIO_FUNC_SIO);
	gpio_set_dir (22, GPIO_IN);
	gpio_disable_pulls (22);
	sleep_us (5);
	primary = gpio_get (22);

	if (primary) {
		// configure grounding logic
		gpio_set_function (P_CLOCK, GPIO_FUNC_SIO);
		gpio_set_function (P_DATA, GPIO_FUNC_SIO);
		gpio_set_dir (P_CLOCK, GPIO_OUT);
		gpio_set_dir (P_DATA, GPIO_OUT);
		make_inputs (gpio_primary_spares, NELEMENTS (gpio_primary_spares));
	} else {
		make_inputs (gpio_secondary_spares, NELEMENTS (gpio_secondary_spares));
	}

	uart_init (uart0, BAUD_RATE);
	uart_set_format (uart0, 8, 1, UART_PARITY_NONE);
	if (primary) {
		gpio_set_function (P_RX, GPIO_FUNC_UART);
		gpio_set_function (P_TX, GPIO_FUNC_UART);
	} else {
		gpio_set_function (S_RX, GPIO_FUNC_UART);
		secondary_disable_tx ();
	}

	reset_hw ();

	zif_to_hal (0);										// trigger detect of standalone / loopback
}

void
toggle (int pin)
{
	gnd (pin);											// turn on the grounding for the pin for 2 seconds
	sleep_ms (2000);									// the top of the caller's loop turns this back off, which is why we have to sleep here
}

void
dip_init (dip_t *dip, int npins, int ground_pin)
{
	memset (dip, 0, sizeof (*dip));
	dip -> npins = npins;
	if (ground_pin == -1) {
		gnd (npins / 2);
	} else {
		gnd (ground_pin);
	}
}

/*
 *	dip_to_zif (npins, dip)
 *
 *	Converts the DIP pin number to the ZIF pin number for a given chip size.
 *	For example, on an 8 pin DIP, the pins are mapped as follows:
 *
 *	DIP 8	ZIF 40
 *		1		 1
 *		2		 2
 *		3		 3
 *		4		 4
 *		5		37
 *		6		38
 *		7		39
 *		8		40
 *
 *	Pin numbers are 1..N based (not 0..N-1)
*/

static uint8_t
dip_to_zif (int npins, int pin)
{
	return pin <= npins / 2 ? pin : 40 - npins + pin;
}

void
dip_make_outputs (dip_t *d, const uint8_t *olist, int n)
{
	for (int i = 0; i < n; i++) {
		uint8_t zif = dip_to_zif (d -> npins, olist [i]);	// convert dip-centric pin number to zif-centric
		d -> halpin [zif] = zif_to_hal (zif);				// convert it to PICO/GPIO
		if (d -> halpin [zif].pico == PICO_LOCAL) {
			make_output (d -> halpin [zif].gpio);
		} else {
			cmd_make_output (d -> halpin [zif].gpio);
		}
	}
}

void
dip_make_inputs (dip_t *d, const uint8_t *ilist, int n)
{
	for (int i = 0; i < n; i++) {
		uint8_t zif = dip_to_zif (d -> npins, ilist [i]);	// convert dip-centric pin number to zif-centric
		d -> halpin [zif] = zif_to_hal (zif);				// convert it to PICO/GPIO
		if (d -> halpin [zif].pico == PICO_LOCAL) {
			make_input (d -> halpin [zif].gpio);
		} else {
			cmd_make_input (d -> halpin [zif].gpio);
		}
	}
}

void
dip_set_output (dip_t *d, uint8_t pin, bool val)
{
	uint8_t zif = dip_to_zif (d -> npins, pin);
	if (d -> halpin [zif].pico == PICO_LOCAL) {
		gpio_put (d -> halpin [zif].gpio, val);
	} else {
		cmd_gpio_put (d -> halpin [zif].gpio, val);
	}
}

void
dip_set_outputs (dip_t *d, uint8_t *pins, uint32_t value, int nbits)
{
	for (int i = 0; i < nbits; i++) {
		dip_set_output (d, pins [i], value & (1 << i));
	}
}

bool
dip_get_input (dip_t *d, uint8_t pin)
{
	uint8_t zif = dip_to_zif (d -> npins, pin);
	if (d -> halpin [zif].pico == PICO_LOCAL) {
		return gpio_get (d -> halpin [zif].gpio);
	}
	return cmd_gpio_get (d -> halpin [zif].gpio);
}

uint32_t
dip_get_inputs (dip_t *d, uint8_t *pin, int nbits)
{
	uint32_t r = 0;

	for (int i = 0; i < nbits; i++) {
		r |= dip_get_input (d, pin [i]) << i;
	}
	return r;
}

void
dip_name_pin (dip_t *d, uint8_t pin, const char *name)
{
	d -> name [dip_to_zif (d -> npins, pin)] = name;
}

const char *
dip_pin_name (dip_t *d, uint8_t pin)
{
	return d -> name [dip_to_zif (d -> npins, pin)];
}

bool
dip_is_tristate (dip_t *d, uint8_t pin)
{
	uint8_t zif = dip_to_zif (d -> npins, pin);
	if (d -> halpin [zif].pico == PICO_LOCAL) {
		return is_tristate (d -> halpin [zif].gpio);
	}
	return cmd_is_tristate (d -> halpin [zif].gpio);
}

