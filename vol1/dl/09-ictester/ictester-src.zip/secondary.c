
/*
 *	secondary.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the secondary processing module.
 *
 *	2025 12 04	R. Krten		created
*/

#include "main.h"

static void
blink (void)
{
	static bool init = false;
	const uint LED_PIN = 25;							// On-board LED is typically connected to GPIO 25 on the Pico

	if (!init) {
		init = true;
		gpio_init (LED_PIN);							// Initialize the GPIO pin
		gpio_set_dir (LED_PIN, GPIO_OUT);				// Set the pin as an output
	}

	static bool value = false;
	gpio_put (LED_PIN, value);
	value = !value;
}

void
secondary_disable_tx (void)
{
	gpio_set_function (S_TX, GPIO_FUNC_SIO);
	gpio_set_dir (S_TX, GPIO_IN);
	gpio_disable_pulls (S_TX);
}

void
secondary_enable_tx (void)
{
	gpio_set_function (S_TX, GPIO_FUNC_UART);
}

/*
 *	reply (buf)
 *	reply_string (str)
 *
 *	reply_string converts a NUL-terminated string to a COBS-compatible buffer, which is then sent to reply().
 *	reply () takes a COBS-compatible buffer, consisting of <length><payload><NUL>, COBS encodes it, and transmits it.
 *
 *	For example, reply_string ("OK") will construct:
 *
 *	+-----+-----+-----+-----+
 *	|  0  |  1  |  2  |  3  |
 *	+-----+-----+-----+-----+
 *	|  2  | 'O' | 'K' |  X  |
 *	+-----+-----+-----+-----+
 *     |     \_____/     +---------	NUL terminator (don't care content)
 *     |        ^
 *     |        +------------------	string payload
 *	   +---------------------------	payload length
 *
 *	Note that the NUL terminator does not need to be present (the first byte, payload length, tells us where the end
 *	of the string is), but there must be SUFFICIENT ROOM for it in the buffer, reply() transmits up to the NUL.
 *
 *	Taking the 4 byte output of reply_string ("OK"), the reply() function will COBS encode it:
 *
 *	+-----+-----+-----+-----+
 *	|  0  |  1  |  2  |  3  |
 *	+-----+-----+-----+-----+
 *	|  3  | 'O' | 'K' |  0  |
 *	+-----+-----+-----+-----+
 *     |     |     |     +---------	COBS NUL terminator (framing byte, "transmit up to here")
 *     |     \_____/
 *     |        ^
 *     |        +------------------	string payload
 *	   +---------------------------	COBS distance to first zero (at offset [3], which is also the end of the string)
 *
 *	A more interesting example is encoding a zero. The reply "OK\0" (e.g., the output of the GE<g> command), cannot
 *	be passed to reply_string (because reply_string expects a C NUL-terminator string, so it would only see "OK", not
 *	the three bytes "OK\0"), so it must be passed to reply() directly.
 *	This means we must construct a 5 byte buffer as follows:
 *
 *	+-----+-----+-----+-----+-----+
 *	|  0  |  1  |  2  |  3  |  4  |
 *	+-----+-----+-----+-----+-----+
 *	|  3  | 'O' | 'K' |  0  |  X  |
 *	+-----+-----+-----+-----+-----+
 *     |     |     |     |     +---	NUL terminator (don't care content)
 *     |     |     |     +---------	data payload ("\0" part)
 *     |     \_____/
 *     |        ^
 *     |        +------------------	string payload ("OK" part)
 *	   +---------------------------	payload length
 *
 *	After COBS encoding, this becomes:
 *
 *	+-----+-----+-----+-----+-----+
 *	|  0  |  1  |  2  |  3  |  4  |
 *	+-----+-----+-----+-----+-----+
 *	|  3  | 'O' | 'K' |  1  |  0  |
 *	+-----+-----+-----+-----+-----+
 *     |     |     |     |     +---	COBS NUL terminator (framing byte, "transmit up to here")
 *     |     |     |     +---------	data payload ("\0" part, encoded as distance to next zero, which is the framing byte)
 *     |     \_____/
 *     |        ^
 *     |        +------------------	string payload ("OK" part)
 *	   +---------------------------	COBS distance to first zero (at offset [3], which is the "\0" part of the payload)
*/

static void
reply (uint8_t *bytes)
{
	cobs_encode (bytes);
	secondary_enable_tx ();
	uart_putc (uart0, 0);								// write the framing byte
	for (int i = 0; bytes [i]; i++) {
		uart_putc (uart0, bytes [i]);
	}
	uart_putc (uart0, 0);								// write the framing byte
	uart_tx_wait_blocking (uart0);
	secondary_disable_tx ();
}

static void
reply_string (const char *str)
{
	uint8_t buffer [SERIAL_MSG_SIZE];					// must be big enough for payload and 2 bytes (size + framing)
	buffer [0] = strlen (str);
	if (buffer [0] + 2 > sizeof (buffer)) {
		str = "SIZE";									// return a size error instead
		buffer [0] = strlen (str);
	}
	memcpy (buffer + 1, str, buffer [0] + 1);			// copy the NUL terminator as well
	reply (buffer);
}

/*
 *	process_command ()
 *
 *	Commands are:
 *
 *		Length	Command			Meaning						Return
 *		-------	-----------		---------------------------	--------------------------
 *		3		GE<gpio>		Get <gpio>					OK<v> return value <v> for gpio <gpio>
 *		3		TS<gpio>		Is <gpio> tri-state?		OK<v> return true/false <v> if <gpio> is tri-state
 *
 *		4		MKI<gpio>		Make input <gpio>			OK -- make gpio an input
 *		4		MKO<gpio>		Make output <gpio>			OK -- make gpio an output
 *		4		PRES			Presence detect				OK -- indicates secondary is present
 *		4		SE<gpio><val>	Set <gpio> to value <val>	OK -- set gpio output value
 *
 *		5		RESET			Reset GPIOs to inputs		OK -- gpios have been reset to inputs
 *
 *	Note that the return values must fit within the limited encoding space.
*/

static void
process_command (uint8_t *c)
{
	switch (c [0]) {
	case	3:
		if (!memcmp (c + 1, "GE", 2)) {
			uint8_t r [] = { 0x00, 'O', 'K', gpio_get (c [3]), 0x00 };
			r [0] = sizeof (r) - 2;
			reply (r);
		} else if (!memcmp (c + 1, "TS", 2)) {
			uint8_t r [] = { 0x00, 'O', 'K', is_tristate (c [3]), 0x00 };
			r [0] = sizeof (r) - 2;
			reply (r);
		}
		break;

	case	4:
		if (!memcmp (c + 1, "PRES", *c)) {
			reply_string ("OK");
		} else if (!memcmp (c + 1, "MKO", 3)) {
			make_output (c [3]);
			reply_string ("OK");
		} else if (!memcmp (c + 1, "MKI", 3)) {
			make_input (c [3]);
			reply_string ("OK");
		} else if (!memcmp (c + 1, "SE", 2)) {
			gpio_put (c [3], c [4]);
			reply_string ("OK");
		}
		break;

	case	5:
		if (!memcmp (c + 1, "RESET", *c)) {
			reset_hw ();
			reply_string ("OK");
		}
		break;

	}
}

void
secondary (void)
{
	for (;;) {
		uint8_t *result = cobs_decode (uart_getc (uart0));
		if (result) {
			blink ();
			process_command (result);
		}
	}
}

