/*
 *	6850.c
 *
 *	(C) Copyright 2026 by Robert Krten, all rights reserved.
 *
 *	This is the MC6850 ACIA test module.
 *
 *	2026 03 28	R. Krten		Gemini created
*/

#include "main.h"

/*
 *	MC 6850 ACIA
 *
 *	Asynchronous Communications Interface Adapter
 *
 *	Note: This test requires a custom adapter to map pins for tester power compatibility:
 *		IC Pin 1  (GND)  -> Tester Pin 12
 *		IC Pin 12 (VCC)  -> Tester Pin 24
 *		IC Pin 24 (-CTS) -> Tester Pin 1
 *
 *	Inputs (from Tester's perspective):
 *		 1	-CTS (remapped from IC pin 24)
 *		 2	Rx Data
 *		 3	Rx CLK
 *		 4	Tx CLK
 *		 8	CS0
 *		 9	-CS2
 *		10	CS1
 *		11	RS
 *		13	R/-W
 *		14	E
 *		23	-DCD
 *
 *	I/O:
 *		15..22 D7..D0
 *
 *	Outputs (from Tester's perspective):
 *		 5	-RTS
 *		 6	Tx Data
 *		 7	-IRQ
*/

// *************************************************
// *** UNTESTED -- We don't actually have a 6850 ***
// *************************************************

#define P_CTS	 1
#define P_RXD	 2
#define P_RXCLK	 3
#define P_TXCLK	 4
#define P_RTS	 5
#define P_TXD	 6
#define P_IRQ	 7
#define P_CS0	 8
#define P_CS2N	 9
#define P_CS1	10
#define P_RS	11
#define P_RWN	13
#define P_E		14
#define P_DCD	23

// 6800-style Bus Write Cycle
static void
write_6850 (dip_t *dip, uint8_t *data_pins, bool rs, uint8_t val)
{
	dip_make_outputs (dip, data_pins, 8);
	dip_set_outputs (dip, data_pins, val, 8);

	dip_set_output (dip, P_RS, rs);
	dip_set_output (dip, P_RWN, 0);					// Write

	// Select chip (CS0=1, CS1=1, -CS2=0)
	dip_set_output (dip, P_CS0, 1);
	dip_set_output (dip, P_CS1, 1);
	dip_set_output (dip, P_CS2N, 0);
	sleep_us (1);

	// Pulse E clock
	dip_set_output (dip, P_E, 1);
	sleep_us (1);									// > 500ns requirement
	dip_set_output (dip, P_E, 0);
	sleep_us (1);

	// Deselect
	dip_set_output (dip, P_CS0, 0);
}

// 6800-style Bus Read Cycle
static uint8_t
read_6850 (dip_t *dip, uint8_t *data_pins, bool rs)
{
	dip_make_inputs (dip, data_pins, 8);

	dip_set_output (dip, P_RS, rs);
	dip_set_output (dip, P_RWN, 1);					// Read

	// Select chip (CS0=1, CS1=1, -CS2=0)
	dip_set_output (dip, P_CS0, 1);
	dip_set_output (dip, P_CS1, 1);
	dip_set_output (dip, P_CS2N, 0);
	sleep_us (1);

	// Pulse E clock and capture data
	dip_set_output (dip, P_E, 1);
	sleep_us (1);									// > 500ns requirement

	uint8_t val = dip_get_inputs (dip, data_pins, 8);

	dip_set_output (dip, P_E, 0);
	sleep_us (1);

	// Deselect
	dip_set_output (dip, P_CS0, 0);

	return val;
}

// Bit-bang the clock 16 times to shift exactly one bit in /16 mode
static void
pulse_clock_16 (dip_t *dip, int pin)
{
	for (int i = 0; i < 16; i++) {
		dip_set_output (dip, pin, 1);
		sleep_us (1);
		dip_set_output (dip, pin, 0);
		sleep_us (1);
	}
}

static bool
test_tx_shift_register (dip_t *dip, uint8_t *data_pins, uint8_t test_pattern)
{
	// Ensure Tx line is idle (High) before we start
	if (dip_get_input (dip, P_TXD) != 1) {
		if (sniff) return false;
		printf ("FAIL: TX1 - Tx line is not idle (High) before transmission\n");
		return false;
	}

	// Write pattern to Transmit Data Register
	write_6850 (dip, data_pins, 1, test_pattern);

	// 1. Check START Bit (Always 0)
	pulse_clock_16 (dip, P_TXCLK);
	if (dip_get_input (dip, P_TXD) != 0) {
		if (sniff) return false;
		printf ("FAIL: TX2 - Did not detect Start Bit (0) on Tx\n");
		return false;
	}

	// 2. Check 8 DATA Bits (LSB first)
	for (int bit = 0; bit < 8; bit++) {
		pulse_clock_16 (dip, P_TXCLK);
		bool expected_bit = !!(test_pattern & (1 << bit));
		bool actual_bit = dip_get_input (dip, P_TXD);

		if (actual_bit != expected_bit) {
			if (sniff) return false;
			printf ("FAIL: TX3 - Tx Bit %d mismatch. Expected %d, got %d\n", bit, expected_bit, actual_bit);
			return false;
		}
	}

	// 3. Check STOP Bit (Always 1)
	pulse_clock_16 (dip, P_TXCLK);
	if (dip_get_input (dip, P_TXD) != 1) {
		if (sniff) return false;
		printf ("FAIL: TX4 - Did not detect Stop Bit (1) on Tx\n");
		return false;
	}

	return true;
}

static bool
test_rx_shift_register (dip_t *dip, uint8_t *data_pins, uint8_t test_pattern)
{
	// 1. Send START Bit (0)
	dip_set_output (dip, P_RXD, 0);
	pulse_clock_16 (dip, P_RXCLK);

	// 2. Send 8 DATA Bits (LSB first)
	for (int bit = 0; bit < 8; bit++) {
		bool bit_val = !!(test_pattern & (1 << bit));
		dip_set_output (dip, P_RXD, bit_val);
		pulse_clock_16 (dip, P_RXCLK);
	}

	// 3. Send STOP Bit (1)
	dip_set_output (dip, P_RXD, 1);
	pulse_clock_16 (dip, P_RXCLK);

	// Check if Receive Data Register Full (RDRF, bit 0) flag is set
	uint8_t status = read_6850 (dip, data_pins, 0);
	if (!(status & 0x01)) {
		if (sniff) return false;
		printf ("FAIL: RX1 - RDRF flag not set after shifting in Rx data (Status: %02X)\n", status);
		return false;
	}

	// Read the received byte
	uint8_t actual_data = read_6850 (dip, data_pins, 1);
	if (actual_data != test_pattern) {
		if (sniff) return false;
		printf ("FAIL: RX2 - Rx data mismatch. Expected %02X, got %02X\n", test_pattern, actual_data);
		return false;
	}

	// Verify RDRF flag cleared after reading the data register
	status = read_6850 (dip, data_pins, 0);
	if (status & 0x01) {
		if (sniff) return false;
		printf ("FAIL: RX3 - RDRF flag did not clear after reading Rx Data Register\n");
		return false;
	}

	return true;
}

bool
test_6850 (void)
{
	dip_t dip;
	dip_init (&dip, 24, -1);

	uint8_t ctrl_pins [] = { P_CTS, P_RXD, P_RXCLK, P_TXCLK, P_CS0, P_CS2N, P_CS1, P_RS, P_RWN, P_E, P_DCD };
	dip_make_outputs (&dip, ctrl_pins, NELEMENTS (ctrl_pins));

	uint8_t out_pins [] = { P_RTS, P_TXD, P_IRQ };
	dip_make_inputs (&dip, out_pins, NELEMENTS (out_pins));

	// D0 to D7 (mapped specifically so that index 0 is D0, etc.)
	uint8_t data_pins [] = { 22, 21, 20, 19, 18, 17, 16, 15 };

	bool pass = true;

	// Establish initial safe idle state for control pins
	dip_set_output (&dip, P_E, 0);
	dip_set_output (&dip, P_CS0, 0);				// Deselected
	dip_set_output (&dip, P_CS1, 0);
	dip_set_output (&dip, P_CS2N, 1);
	dip_set_output (&dip, P_RXCLK, 0);
	dip_set_output (&dip, P_TXCLK, 0);
	dip_set_output (&dip, P_RXD, 1);				// Idle serial line
	dip_set_output (&dip, P_CTS, 0);				// Asserted (Low)
	dip_set_output (&dip, P_DCD, 0);				// Asserted (Low)

	// --- BASIC CONTROL TESTS ---

	// test 1: Master Reset
	write_6850 (&dip, data_pins, 0, 0x03);			// CR1=1, CR0=1 -> Master Reset

	uint8_t status = read_6850 (&dip, data_pins, 0);

	// After reset, IRQ (bit 7) should be 0, TDRE (bit 1) should be 1 if CTS is low
	if (!(status & 0x02)) {
		if (sniff) return false;
		printf ("FAIL 1: TDRE not set after Master Reset (Status: %02X)\n", status);
		pass = false;
	}

	// test 2: Check -RTS toggle via Control Register
	// CR = 0x15: Div 16 (CR1=0, CR0=1), 8N1 (CR4=1, CR3=0, CR2=1), RTS Low/TxInt Dis (CR6=0, CR5=0), RxInt Dis (0)
	write_6850 (&dip, data_pins, 0, 0x15);
	sleep_us (2);
	if (dip_get_input (&dip, P_RTS) != 0) {
		if (sniff) return false;
		printf ("FAIL 2: -RTS did not go low when requested\n");
		pass = false;
	}

	// Set RTS High: CR6=1, CR5=0 (0x40). 0x40 | 0x15 = 0x55
	write_6850 (&dip, data_pins, 0, 0x55);
	sleep_us (2);
	if (dip_get_input (&dip, P_RTS) != 1) {
		if (sniff) return false;
		printf ("FAIL 3: -RTS did not go high when requested\n");
		pass = false;
	}

	// test 3: Check Tx Data Register write clears the TDRE flag
	write_6850 (&dip, data_pins, 0, 0x15);			// Re-enable RTS Low to make sure we're active
	write_6850 (&dip, data_pins, 1, 0xAA);			// Write dummy byte to Tx Data Register
	status = read_6850 (&dip, data_pins, 0);
	if (status & 0x02) {
		if (sniff) return false;
		printf ("FAIL 4: TDRE did not clear after writing to Tx Data\n");
		pass = false;
	}

	// test 4: Check Modem Control Lines (-CTS and -DCD reflection in Status)
	dip_set_output (&dip, P_CTS, 1);				// -CTS Inactive
	sleep_us (2);
	status = read_6850 (&dip, data_pins, 0);
	if (!(status & 0x08)) {							// Bit 3 is -CTS
		if (sniff) return false;
		printf ("FAIL 5: CTS bit in status did not reflect pin state\n");
		pass = false;
	}
	dip_set_output (&dip, P_CTS, 0);

	dip_set_output (&dip, P_DCD, 1);				// -DCD Inactive
	sleep_us (2);
	status = read_6850 (&dip, data_pins, 0);
	if (!(status & 0x04)) {							// Bit 2 is -DCD
		if (sniff) return false;
		printf ("FAIL 6: DCD bit in status did not reflect pin state\n");
		pass = false;
	}
	dip_set_output (&dip, P_DCD, 0);

	// --- DATA SHIFT REGISTER TESTS ---

	// Test Transmit Shift Register
	if (pass && !test_tx_shift_register (&dip, data_pins, 0x5A)) {
		pass = false;
	}

	// Test Receive Shift Register
	if (pass && !test_rx_shift_register (&dip, data_pins, 0xA5)) {
		pass = false;
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

