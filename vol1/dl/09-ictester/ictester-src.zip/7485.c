
/*
 *	7485.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 7485 (16 pin)
 *
 *	Inputs
 *		10 A0
 *		12 A1
 *		13 A2
 *		15 A3
 *		 9 B0
 *		11 B1
 *		14 B2
 *		 1 B3
 *		 2 A<BIN
 *		 3 A=BIN
 *		 4 A>BIN
 *	Outputs
 *		 5 A>BOUT
 *		 6 A=BOUT
 *		 7 A<BOUT
 *
 *	These four-bit magnitude comparators perform comparison of straight binary and straight BCD
 *	(8-4-2-1) codes.
 *	Three fully decoded decisions about two 4-bit words (A, B) are made and are externally available at
 *	three outputs.
 *	These devices are fully expandable to any number of bits without external gates.
 *	Words of greater length may be compared by connecting comparators in cascade.
 *	The A>B, A<B and A=B outputs of a stage handling less-significant bits are connected to the
 *	corresponding A>B, A<B, and A=B inputs of the next stage handling more-significant bits.
 *	The stage handling the least significant bits must have a high-level voltage applied to the A=B
 *	input.
 *	The cascading paths of the '85, 'LS85, and 'S85 are implemented with only a two-gate-level delay to
 *	reduce overall comparison times for long words.
 *	An alternate method of cascading which further reduces the comparison time is shown in the typical
 *	application data.
*/

bool
test_7485 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	//						A0  A1  A2  A3  B0  B1  B2  B3  A<B A=B A>B
	uint8_t outputs [] = { 10, 12, 13, 15,  9, 11, 14,  1,  2,  3,  4 };
	//						 0   1   2   3   4   5   6   7   8   9  10
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A0		0
	#define	O_B0		4
	#define	O_ALTBIN	8
	#define	O_AEQBIN	9
	#define	O_AGTBIN	10

	uint8_t inputs [] = { 5, 6, 7 };	// ordered { A>B, A=B, A<B }
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));
	#define	I_GT		0
	#define	I_EQ		1
	#define	I_LT		2

	bool pass = true;

	// test all possible combinations
// printf ("\n");
	for (int a = 0; a < 16; a++) {
		bool A [4];
		for (int bit = 0; bit < 4; bit++) {
			A [bit] = a & (1 << bit);
			dip_set_output (&dip, outputs [O_A0 + bit], A [bit]);
		}
		for (int b = 0; b < 16; b++) {
			bool B [4];
			for (int bit = 0; bit < 4; bit++) {
				B [bit] = b & (1 << bit);
				dip_set_output (&dip, outputs [O_B0 + bit], B [bit]);
			}

//printf ("\nAAAA BBBB <=> <=>\n");
			for (int altb = 0; altb < 2; altb++) {
				dip_set_output (&dip, outputs [O_ALTBIN], altb);
				for (int aeqb = 0; aeqb < 2; aeqb++) {
					dip_set_output (&dip, outputs [O_AEQBIN], aeqb);
					for (int agtb = 0; agtb < 2; agtb++) {
						dip_set_output (&dip, outputs [O_AGTBIN], agtb);

						// now validate the outputs
						bool lt = dip_get_input (&dip, inputs [I_LT]);
						bool eq = dip_get_input (&dip, inputs [I_EQ]);
						bool gt = dip_get_input (&dip, inputs [I_GT]);
//printf ("%d%d%d%d %d%d%d%d %d%d%d %d%d%d\n", A [3], A [2], A [1], A [0], B [3], B [2], B [1], B [0], altb, aeqb, agtb, lt, eq, gt);

						// this is a transcription of the function table
						#define	AGTB	1
						#define	ALTB	2
						#define	AEQB	4
						int expected = -1;
						if (A [3] > B [3]) {
							expected = AGTB;
						} else if (A [3] < B [3]) {
							expected = ALTB;
						} else if (A [3] == B [3]) {
							if (A [2] > B [2]) {
								expected = AGTB;
							} else if (A [2] < B [2]) {
								expected = ALTB;
							} else if (A [2] == B [2]) {
								if (A [1] > B [1]) {
									expected = AGTB;
								} else if (A [1] < B [1]) {
									expected = ALTB;
								} else if (A [1] == B [1]) {
									if (A [0] > B [0]) {
										expected = AGTB;
									} else if (A [0] < B [0]) {
										expected = ALTB;
									} else if (A [0] == B [0]) {
										if (agtb && !altb && !aeqb) {
											expected = AGTB;
										} else if (!agtb && altb && !aeqb) {
											expected = ALTB;
										} else if (aeqb) {
											expected = AEQB;
										} else if (agtb && altb && !aeqb) {
											expected = 0;
										} else if (!agtb && !altb && !aeqb) {
											expected = AGTB | ALTB;
										}
									}
								}
							}
						}

						if (expected == -1) {
							printf ("-> unhandled case!\n");
						} else {
							if (!(expected & AGTB) ^ !gt) {
								if (sniff) return false;
								printf ("FAIL 1: expected A>B == %d\n", !gt);
								pass = false;
							}
							if (!(expected & ALTB) ^ !lt) {
								if (sniff) return false;
								printf ("FAIL 2: expected A<B == %d\n", !lt);
								pass = false;
							}
							if (!(expected & AEQB) ^ !eq) {
								if (sniff) return false;
								printf ("FAIL 2: expected A=B == %d\n", !eq);
								pass = false;
							}
						}
					}
				}
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

