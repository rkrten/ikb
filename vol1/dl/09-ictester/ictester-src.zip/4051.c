
/*
 *	4051.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 04	R. Krten		created
*/

#include "main.h"

/*
 *	CD 4051
 *
 *	Single 8-channel analog multiplexer / demultiplexer
 *
 *	Inputs:
 *		 1	Channel 4
 *		 2	Channel 6
 *		 3	Common
 *		 4	Channel 7
 *		 5	Channel 5
 *		 6	Inhibit
 *		 9	C
 *		10	B
 *		11	A
 *		12	Channel 3
 *		13	Channel 0
 *		14	Channel 1
 *		15	Channel 2
 *
 *	Additional Power:
 *		 7	VEE
 *
 *	The 4051 is an 8 channel analog multiplexer / demultiplexer.
 *	A common pin is connected to one of 8 channel pins under control of the A, B, and C inputs.
 *	No connection is made if the inhibit pin is high.
 *
 *	In this test program, we set VEE to zero and hope for the best.
 *
 *	The chip is bidirectional (that is, it acts like a switch, simply connecting two points together)
 *	so the test is done in two parts.
 *	The first part has the common as a value that gets propagated to one of the 8 output channels, and
 *	the second part has a value from the 8 input channel propagated to the common.
*/

static void
set_4051_vee (dip_t *dip)
{
	uint8_t vee [] = { 7 };
	dip_make_outputs (dip, vee, NELEMENTS (vee));
	dip_set_output (dip, vee [0], false);				// set VEE to ground
}

static void
set_4051_controls (dip_t *dip, int channel, bool inh)
{
	uint8_t controls [] = { 11, 10, 9, 6 };				// ordered A, B, C, Onhibit
	dip_make_outputs (dip, controls, NELEMENTS (controls));
	#define	O_A			0
	#define	O_B			1
	#define	O_C			2
	#define	O_Inhibit	3

	dip_set_output (dip, controls [O_A], !!(channel & 1));
	dip_set_output (dip, controls [O_B], !!(channel & 2));
	dip_set_output (dip, controls [O_C], !!(channel & 4));
	dip_set_output (dip, controls [O_Inhibit], inh);
}

// expect one of the 8 channel values to show up on the common
static bool
test_4051_as_inputs (dip_t *dip)
{
	uint8_t inputs [] = { 3 };							// pin 3 is the common
	dip_make_inputs (dip, inputs, NELEMENTS (inputs));

	uint8_t outputs [] = { 13, 14, 15, 12, 1, 5, 2, 4 };// ordered as Channels 0 .. 7
	dip_make_outputs (dip, outputs, NELEMENTS (outputs));

	bool pass = true;

	// test 1, attempt to write data to common via channels while inhibit is active
	for (int i = 0; i < 8; i++) {
		set_4051_controls (dip, i, true);				// inhibit is active

		// common should be tristate, even if channels are high
		for (int ch = 0; ch < NELEMENTS (outputs); ch++) {
			dip_set_output (dip, outputs [ch], true);
		}
		sleep_us (1);

		if (!dip_is_tristate (dip, inputs [0])) {
			if (sniff) return false;
			printf ("FAIL 1: inhibit is active, but with channels high and channel %d selected, common is not tristate, it's %s\n", i, dip_get_input (dip, inputs [0]) ? "high" : "low");
			pass = false;
		}

		// common should be tristate, even if channels are low
		for (int ch = 0; ch < NELEMENTS (outputs); ch++) {
			dip_set_output (dip, outputs [ch], false);
		}
		sleep_us (1);

		if (!dip_is_tristate (dip, inputs [0])) {
			if (sniff) return false;
			printf ("FAIL 2: inhibit is active, but with channels low and channel %d selected, common is not tristate, it's %s\n", i, dip_get_input (dip, inputs [0]) ? "high" : "low");
			pass = false;
		}
	}

	// test 2, write data to common via channels without inhibition
	for (int i = 0; i < 8; i++) {
		// select a channel source
		set_4051_controls (dip, i, false);

		// write a high to one channel at a time
		for (int ch = 0; ch < 8; ch++) {
			// set all channels to zero except channel "ch"
			for (int x = 0; x < 8; x++) {
				dip_set_output (dip, outputs [x], ch == x);
			}
			sleep_us (1);

			bool v = dip_get_input (dip, inputs [0]);
			if (i == ch) {
				if (!v) {
					if (sniff) return false;
					printf ("FAIL 3: selected channel %d as source for common, set to high, but common is low\n", ch);
					pass = false;
				}
			} else {
				if (v) {
					if (sniff) return false;
					printf ("FAIL 4: selected channel %d as source for common, set to low, but common is high\n", ch);
					pass = false;
				}
			}
		}

		// write a low to one channel at a time
		for (int ch = 0; ch < 8; ch++) {
			// set all channels to one except channel "ch"
			for (int x = 0; x < 8; x++) {
				dip_set_output (dip, outputs [x], ch != x);
			}
			sleep_us (1);

			bool v = dip_get_input (dip, inputs [0]);
			if (i == ch) {
				if (v) {
					if (sniff) return false;
					printf ("FAIL 5: selected channel %d as source for common, set to low, but common is high\n", ch);
					pass = false;
				}
			} else {
				if (!v) {
					if (sniff) return false;
					printf ("FAIL 6: selected channel %d as source for common, set to high, but common is low\n", ch);
					pass = false;
				}
			}
		}


	}

	return pass;
}

// expect the common value to show up on one of the 8 channels.
static bool
test_4051_as_outputs (dip_t *dip)
{
	uint8_t outputs [] = { 3 };							// pin 3 is the common
	dip_make_outputs (dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 13, 14, 15, 12, 1, 5, 2, 4 };	// ordered as Channels 0 .. 7
	dip_make_inputs (dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	// test 1, attempt to write data to channels via common while inhibit is active
	for (int i = 0; i < 8; i++) {
		// select a channel
		set_4051_controls (dip, i, true);				// inhibit is active

		// channels should be tristate, even if common is high
		dip_set_output (dip, outputs [0], true);
		sleep_us (1);

		for (int ch = 0; ch < NELEMENTS (inputs); ch++) {
			if (!dip_is_tristate (dip, inputs [ch])) {
				if (sniff) return false;
				printf ("FAIL 7: inhibit is active, but with common high and channel %d selected, channel is not tristate, it's %s\n", i, dip_get_input (dip, inputs [ch]) ? "high" : "low");
				pass = false;
			}
		}

		// channels should be tristate, even if common is low
		dip_set_output (dip, outputs [0], false);
		sleep_us (1);

		for (int ch = 0; ch < NELEMENTS (inputs); ch++) {
			if (!dip_is_tristate (dip, inputs [ch])) {
				if (sniff) return false;
				printf ("FAIL 8: inhibit is active, but with common low and channel %d selected, channel is not tristate, it's %s\n", i, dip_get_input (dip, inputs [ch]) ? "high" : "low");
				pass = false;
			}
		}
	}

	// test 2, write data to channels via common without inhibition
	for (int i = 0; i < 8; i++) {
		// select a channel
		set_4051_controls (dip, i, false);

		// write a high to the common
		dip_set_output (dip, outputs [0], true);
		sleep_us (1);

		// expect all channels except the selected one to be tristate; the selected one should be high
		for (int ch = 0; ch < NELEMENTS (inputs); ch++) {
			if (ch == i) {
				if (!dip_get_input (dip, inputs [ch])) {
					if (sniff) return false;
					printf ("FAIL 9: selected channel %d is not high while writing a high to common\n", ch);
					pass = false;
				}
			} else {
				if (!dip_is_tristate (dip, inputs [ch])) {
					if (sniff) return false;
					printf ("FAIL 10: unselected channel %d is not tristate (it's %s) while writing a high to common\n", ch, dip_get_input (dip, inputs [ch]) ? "high" : "low");
					pass = false;
				}
			}
		}

		// write a low to the common
		dip_set_output (dip, outputs [0], false);
		sleep_us (1);

		// expect all channels except the selected one to be tristate; the selected one should be low
		for (int ch = 0; ch < NELEMENTS (inputs); ch++) {
			if (ch == i) {
				if (dip_get_input (dip, inputs [ch])) {
					if (sniff) return false;
					printf ("FAIL 11: selected channel %d is not low while writing a low to common\n", ch);
					pass = false;
				}
			} else {
				if (!dip_is_tristate (dip, inputs [ch])) {
					if (sniff) return false;
					printf ("FAIL 12: unselected channel %d is not tristate (it's %s) while writing a low to common\n", ch, dip_get_input (dip, inputs [ch]) ? "high" : "low");
					pass = false;
				}
			}
		}
	}

	return pass;
}

bool
test_4051 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	set_4051_vee (&dip);

	bool pass = true;

	if (!test_4051_as_inputs (&dip)) {
		if (sniff) return false;
		pass = false;
	}

	if (!test_4051_as_outputs (&dip)) {
		if (sniff) return false;
		pass = false;
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

