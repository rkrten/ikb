
/*
 *	74175.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74175
 *
 *	Quadruple d-type flip-flops with clear
 *
 *	Inputs:
 *		1				-CLR
 *		9				CLK
 *		4	5	12	13	D1..4
 *
 *	Outputs:
 *		2	7	10	15	Q1..4
 *		3	6	11	14	-Q1..4
 *
 *	These monolithic, positive-edge-triggered flip-flops utilize TTL circuitry to implement D-type
 *	flip-flop logic. They have a direct clear input and feature complementary outputs from each
 *	flip-flop.
 *
 *	Information at the D inputs meeting the setup time requirements is transferred to the Q outputs on
 *	the positive-going edge of the clock pulse. Clock triggering occurs at a particular voltage level
 *	and is not directly related to the transition time of the positive-going pulse. When the clock
 *	input is at either the high or low level, the D input signal has no effect at the output.
*/

typedef struct
{
	int	d;
	int	q;
	int	notq;
} ff_t;

// pin numbers common to all flip-flops
static int clear;
static int clock;

bool
test_74175_unit (dip_t *dip, ff_t *f, int unit)
{
	bool pass = true;

	dip_set_output (dip, clock, false);					// clock operates on rising edge
	dip_set_output (dip, f -> d, false);				// set D to zero

	// test 1, see if clearing gives us the expected Q and -Q values
	dip_set_output (dip, clear, false);					// assert clear
	if (dip_get_input (dip, f -> q)) {
		if (sniff) return false;
		printf ("FAIL 1%c: clear failed to clear Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}
	if (!dip_get_input (dip, f -> notq)) {
		if (sniff) return false;
		printf ("FAIL 2%c: clear failed to set -Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}
	dip_set_output (dip, clear, true);					// deassert clear

	// test 2, see if clocking in a one gives us the expected Q and -Q values
	dip_set_output (dip, f -> d, true);					// set D to one
	dip_set_output (dip, clock, true);					// clock
	dip_set_output (dip, clock, false);					// pulse
	if (!dip_get_input (dip, f -> q)) {
		if (sniff) return false;
		printf ("FAIL 3%c: clocking in true failed to set Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}
	if (dip_get_input (dip, f -> notq)) {
		if (sniff) return false;
		printf ("FAIL 4%c: clocking in true failed to clear -Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}

	// test 3, see if clocking in a zero gives us the expected Q and -Q values
	dip_set_output (dip, f -> d, false);				// set D to zero
	dip_set_output (dip, clock, true);					// clock
	dip_set_output (dip, clock, false);					// pulse
	if (dip_get_input (dip, f -> q)) {
		if (sniff) return false;
		printf ("FAIL 5%c: clocking in false failed to clear Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}
	if (!dip_get_input (dip, f -> notq)) {
		if (sniff) return false;
		printf ("FAIL 6%c: clocking in false failed to set -Q%d\n", 'A' + unit, unit + 1);
		pass = false;
	}

	return pass;
}

bool
test_74175 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	clear = 1;
	clock = 9;
	uint8_t outputs [] = { clear, 4, 5, clock, 12, 13 };// pin order
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 2, 3, 6, 7, 10, 11, 14, 15 };	// pin order
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	ff_t units [4] =
	{
	//	   D   Q  -Q
		{  4,  2,  3},
		{  5,  7,  6},
		{ 12, 10, 11},
		{ 13, 15, 14}
	};

	// let's test them independently for now
	bool pass = true;
	for (int i = 0; i < NELEMENTS (units); i++) {
		if (!test_74175_unit (&dip, &units [i], i)) {
			if (sniff) return false;
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

