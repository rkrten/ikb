
/*
 *	74279.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74279
 *
 *	Quadruple S/R latches
 *
 *	Inputs:
 *		1	5	10	14	-R
 *		2	6	11	15	-S (or -S1 for latches 1 and 3)
 *		3	N/A	12	N/A	-S2 (only on latches 1 and 3)
 *
 *	Outputs:
 *		4	7	9	13	Q
 *
 *	The '279 offers 4 basic S/R flip-flop latches in one 16-pin package.
 *	Under conventional operation, the S/R inputs are normally held high.
 *	When the S input is pulsed low, the Q output will be set high.
 *	When the R input is pulsed low, the Q output will be reset low.
 *	Normally, the S/R inputs should not be taken low simultaneously.
 *	The Q output will be unpredictable in this condition.
*/

typedef struct
{
	int	r;
	int	s;
	int	s2;
	int	q;
} latch_t;

bool
test_74279_unit (dip_t *dip, latch_t *l, int unit)
{
	dip_set_output (dip, l -> r, true);
	dip_set_output (dip, l -> s, true);
	dip_set_output (dip, l -> s2, true);

	bool pass = true;

	for (int i = 0; i < 2; i++) {
		for (int phase = 0; phase < 3; phase++) {
			bool expected = false;
			switch (phase) {
			case	0:
				dip_set_output (dip, l -> r, false);
				dip_set_output (dip, l -> s, true);
				dip_set_output (dip, l -> s2, true);
				expected = false;
				break;

			case	1:
				dip_set_output (dip, l -> r, true);
				dip_set_output (dip, l -> s, false);
				dip_set_output (dip, l -> s2, true);
				expected = true;
				break;

			case	2:
				if (unit & 1 == 0) {
					continue;
				}
				dip_set_output (dip, l -> r, true);
				dip_set_output (dip, l -> s, true);
				dip_set_output (dip, l -> s2, false);
				expected = true;
				break;

			}

			bool q = dip_get_input (dip, l -> q);
			if (q != expected) {
				if (sniff) return false;
				printf ("FAIL 1: Q%d is not %d after %s\n", unit, expected, phase == 0 ? "reset" : phase == 1 ? "set 1" : "set 2");
				pass = false;
			}

			dip_set_output (dip, l -> r, true);
			dip_set_output (dip, l -> s, true);
			dip_set_output (dip, l -> s2, true);

			if (q != expected) {
				if (sniff) return false;
				printf ("FAIL 2: Q%d did not persist at %d (after %s cleared)\n", unit, expected, phase == 0 ? "reset" : phase == 1 ? "set 1" : "set 2");
				pass = false;
			}
		}
	}

	return pass;
}

bool
test_74279 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 2, 3, 5, 6, 10, 11, 12, 14, 15 };	// pin order, not particularly useful
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 4, 7, 9, 13 };						// also in pin order
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	latch_t units [4] =
	{
	//	   R   S  S2   Q
		{  1,  2,  3,  4 },								// units 1 and 3 have s2
		{  5,  6, -1,  7 },								// units 2 and 4 don't
		{ 10, 11, 12,  9 },								// unit 3, with
		{ 14, 15, -1, 13 }								// unit 4, without
	};

	// let's test them independently for now
	bool pass = true;
	for (int i = 0; i < NELEMENTS (units); i++) {
		if (!test_74279_unit (&dip, &units [i], i)) {
			if (sniff) return false;
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

