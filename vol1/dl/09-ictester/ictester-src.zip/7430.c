
/*
 *	7430.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

bool
test_7430 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 1, 2, 3, 4, 5, 6, 11, 12 };	// ordered A..H
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 8 };							// just the one output
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 256; i++) {
		dip_set_outputs (&dip, outputs, i, 8);

		bool y = dip_get_input (&dip, inputs [0]);
		if (i == 255) {
			if (y) {
				if (sniff) return false;
				printf ("FAIL 1:  Y is on when all inputs are on\n");
				pass = false;
			}
		} else {
			if (!y) {
				if (sniff) return false;
				printf ("FAIL 2:  Y is not on when not all inputs are on\n");
				pass = false;
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

