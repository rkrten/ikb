
/*
 *	74280.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74280
 *
 *	9-bit odd/even parity generator/checker
 *
 *	Inputs:
 *		 8	A
 *		 9	B
 *		10	C
 *		11	D
 *		12	E
 *		13	F
 *		 1	G
 *		 2	H
 *		 4	I
 *
 *	Outputs:
 *		 5	SUMEVEN
 *		 6	SUMODD
 *
 *	These universal, monolithic, nine-bit parity generators/checkers utilize Schottky-clamped TTL
 *	high-performance circuitry and feature odd/even outputs to facilitate operation of either odd or
 *	even parity application. The word-length capability is easily expanded by cascading as shown under
 *	typical application data.
 *
 *	Series 54LS/74LS and Series 54S/74S parity generators/checkers offer the designer a trade-off
 *	between reduced power consumption and high performance. These devices can be used to upgrade the
 *	performance of most systems utilizing the '180 parity generator/checker. Although the 'LS280 and
 *	'S280 are implemented without expander inputs, the corresponding function is provided by the
 *	availability of an input at pin 4 and the absence of any internal connection at pin 3. This permits
 *	the 'LS280 and 'S280 to be substituted for the '180 in existing designs to produce an identical
 *	function even if 'LS280's and 'S280's are mixed with existing '180's.
*/

bool
test_74280 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 8, 9, 10, 11, 12, 13, 1, 2, 4 };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 5, 6 };
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));
	enum { I_EVEN, I_ODD };

	bool pass = true;
	for (int t = 0; t < 1 << NELEMENTS (outputs); t++) {
		bool odd = false;

		for (int bit = 0; bit < NELEMENTS (outputs); bit++) {
			bool v = !!(t & (1 << bit));
			dip_set_output (&dip, outputs [bit], v);
			odd ^= v;
		}

		if (dip_get_input (&dip, inputs [I_EVEN]) == odd) {
			if (sniff) return false;
			printf ("FAIL 1:  input pattern %d%d%d%d%d%d%d%d%d does not produce expected EVEN parity %d\n",
				!!(t & 0x001), !!(t & 0x002), !!(t & 0x004), !!(t & 0x008), !!(t & 0x010), !!(t & 0x020), !!(t & 0x040), !!(t & 0x080), !!(t & 0x100), !odd);
			pass = false;
		}

		if (dip_get_input (&dip, inputs [I_ODD]) != odd) {
			if (sniff) return false;
			printf ("FAIL 2:  input pattern %d%d%d%d%d%d%d%d%d does not produce expected ODD parity %d\n",
				!!(t & 0x001), !!(t & 0x002), !!(t & 0x004), !!(t & 0x008), !!(t & 0x010), !!(t & 0x020), !!(t & 0x040), !!(t & 0x080), !!(t & 0x100), odd);
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

