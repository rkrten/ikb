
/*
 *	7439x.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 7439x test module; it tests the '390 and '393 dual counters.
 *	Note that the 749x series of counters have funky VCC; it's not on the last pin so we don't test those.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74390 (16 pin)
 *
 *	Inputs
 *		 1	15	CKA
 *		 2	14	CLR
 *		 4	12	CKB
 *	Outputs
 *		 3	13	QA
 *		 5	11	QB
 *		 6	10	QC
 *		 7	 9	QD
*/

bool
test_74390 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [2][3] = { { 1, 2, 4 }, { 15, 14, 12 } };		// ordered units [2] { ClockA, Clear, ClockB }
	dip_make_outputs (&dip, outputs [0], NELEMENTS (outputs [0]));
	dip_make_outputs (&dip, outputs [1], NELEMENTS (outputs [1]));
	#define	O_CLKA		0
	#define	O_CLEAR		1
	#define	O_CLKB		2

	uint8_t inputs [2][4] = { { 3, 5, 6, 7 }, { 13, 11, 10, 9 } };	// ordered units [2] { QA, QB, QC, QD }
	dip_make_inputs (&dip, inputs [0], NELEMENTS (inputs [0]));
	dip_make_inputs (&dip, inputs [1], NELEMENTS (inputs [1]));

	bool pass = true;

	for (int unit = 0; unit < 2; unit++) {
		// test 1, clear resets counts to zero
		dip_set_output (&dip, outputs [unit][O_CLEAR], 1);			// assert clear
		dip_set_output (&dip, outputs [unit][O_CLKA], 0);			// deassert clock A
		dip_set_output (&dip, outputs [unit][O_CLKB], 0);			// deassert clock B
		for (int i = 0; i < 4; i++) {
			bool val = dip_get_input (&dip, inputs [unit][i]);
			if (val) {
				if (sniff) return false;
				printf ("FAIL 1: unit %d, with CLEAR asserted, read a high on Q%c\n", unit, i + 'A');
				pass = false;
			}
		}

		// test 2, count clock A
		dip_set_output (&dip, outputs [unit][O_CLEAR], 0);			// deassert clear
		sleep_us (1);
		for (int c = 0; c < 4; c++) {
			bool val = dip_get_input (&dip, inputs [unit][0]);
			if (val != (c & 1)) {
				if (sniff) return false;
				printf ("FAIL 2: unit %d, CLKA count %d expected QA=%d\n", unit, c, c & 1);
				pass = false;
			}
			for (int i = 1; i < 4; i++) {
				bool val = dip_get_input (&dip, inputs [unit][i]);
				if (val) {
					if (sniff) return false;
					printf ("FAIL 3: unit %d, CLKA has affected 2nd counter Q%c\n", unit, i + 'A');
					pass = false;
				}
			}
			dip_set_output (&dip, outputs [unit][O_CLKA], 1);		// count up
			sleep_us (1);
			dip_set_output (&dip, outputs [unit][O_CLKA], 0);		// release
			sleep_us (1);
		}

		// test 3, count clock B
		for (int c = 0; c < 20; c++) {
			uint8_t quinary = c % 5;								// these are bi-quinary counters, after all :-)
			for (int i = 1; i < 4; i++) {
				bool val = dip_get_input (&dip, inputs [unit][i]);
				if (!!(quinary & (1 << (i - 1))) != val) {
					if (sniff) return false;
					printf ("FAIL 4: unit %d, quinary count %d, Q%c is %d\n", unit, quinary, i + 'A', val);
					pass = false;
				}
			}
			dip_set_output (&dip, outputs [unit][O_CLKB], 1);		// count up
			sleep_us (1);
			dip_set_output (&dip, outputs [unit][O_CLKB], 0);		// release
			sleep_us (1);
		}
	}


	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;

	#undef O_CLKA
	#undef O_CLEAR
	#undef O_CLKB
}

/*
 *	SN 74393 (14 pin)
 *
 *	Inputs
 *		 1	13	A
 *		 2	12	CLR
 *	Outputs
 *
 *		 3	11	QA
 *		 4	10	QB
 *		 5	 9	QC
 *		 6	 8	QD
*/

bool
test_74393 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [2][2] = { { 1, 2 }, { 13, 12 } };				// ordered units [2] { Clock, Clear }
	dip_make_outputs (&dip, outputs [0], NELEMENTS (outputs [0]));
	dip_make_outputs (&dip, outputs [1], NELEMENTS (outputs [1]));
	#define	O_CLK		0
	#define	O_CLEAR		1

	uint8_t inputs [2][4] = { { 3, 4, 5, 6 }, { 11, 10, 9, 8 } };	// ordered units [2] { QA, QB, QC, QD }
	dip_make_inputs (&dip, inputs [0], NELEMENTS (inputs [0]));
	dip_make_inputs (&dip, inputs [1], NELEMENTS (inputs [1]));

	bool pass = true;

	for (int unit = 0; unit < 2; unit++) {
		// test 1, clear resets counts to zero
		dip_set_output (&dip, outputs [unit][O_CLEAR], 1);			// assert clear
		dip_set_output (&dip, outputs [unit][O_CLK], 0);			// deassert clock
		for (int i = 0; i < 4; i++) {
			bool val = dip_get_input (&dip, inputs [unit][i]);
			if (val) {
				if (sniff) return false;
				printf ("FAIL 1: unit %d, with CLEAR asserted, read a high on Q%c\n", unit, i + 'A');
				pass = false;
			}
		}
		dip_set_output (&dip, outputs [unit][O_CLEAR], 0);			// deassert clear

		// test 2, count clock
		for (int c = 0; c < 32; c++) {
			for (int i = 0; i < 4; i++) {
				bool val = dip_get_input (&dip, inputs [unit][i]);
				if (!!(c & (1 << i)) != val) {
					if (sniff) return false;
					printf ("FAIL 4: unit %d, count %d, Q%c is %d\n", unit, c, i + 'A', val);
					pass = false;
				}
			}
			dip_set_output (&dip, outputs [unit][O_CLK], 1);		// count up
			sleep_us (1);
			dip_set_output (&dip, outputs [unit][O_CLK], 0);		// release
			sleep_us (1);
		}
	}


	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;

	#undef	O_CLK
	#undef	O_CLEAR
}

