
/*
 *	7474.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

/*
 *	SN 7474
 *
 *	Dual D-type positive edge triggered flip flops with preset and clear
 *
 *	Inputs:
 *		4	10	-PRESET
 *		1	13	-CLEAR
 *		3	11	CLOCK
 *		2	12	DATA
 *
 *	Outputs:
 *		5	 9	Q
 *		6	 8	-Q
 *
 *	These devices contain two independent D-type positive-edge-triggered flip-flops.
 *	A low level at the preset or clear inputs sets or resets the outputs regardless
 *	of the levels of the other inputs.
 *
 *	When preset and clear are inactive (high), data at the D input meeting the
 *	setup time requirements are transferred to the outputs on the positive-going
 *	edge of the clock pulse.
 *
 *	Clock triggering occurs at a voltage level and is not directly related to the
 *	rise time of the clock pulse.
 *
 *	Following the hold time interval, data at the D input may be changed without
 *	affecting the levels at the outputs.
*/

typedef struct
{
	int	preset;
	int	clear;
	int	clock;
	int	data;
	int	q;
	int	nq;
} flip_flop_t;

bool
test_7474_unit (dip_t *dip, flip_flop_t *f, int unit)
{
	// set flip flop to known states
	dip_set_output (dip, f -> preset, true);
	dip_set_output (dip, f -> clear, true);
	dip_set_output (dip, f -> clock, false);
	dip_set_output (dip, f -> data, false);

	bool pass = true;

	// test 1, clear the flip flop, verify that Q and -Q are as expected
	dip_set_output (dip, f -> clear, false);
	sleep_us (5);
	int q = dip_get_input (dip, f -> q);
	int n = dip_get_input (dip, f -> nq);
	if (q || !n) {
		if (sniff) return false;
		printf ("FAIL: Q%d (%d) or -Q%d (%d) are incorrect after CLEAR\n", unit, q, unit, n);
		pass = false;
	}
	dip_set_output (dip, f -> clear, true);

	// test 2, preset the flip flop, verify that Q and -Q are as expected
	dip_set_output (dip, f -> preset, false);
	sleep_us (5);
	q = dip_get_input (dip, f -> q);
	n = dip_get_input (dip, f -> nq);
	if (!q || n) {
		if (sniff) return false;
		printf ("FAIL: Q%d (%d) or -Q%d (%d) are incorrect after PRESET\n", unit, q, unit, n);
		pass = false;
	}
	dip_set_output (dip, f -> preset, true);

	// test 3, clock in a zero
	dip_set_output (dip, f -> clock, true);
	sleep_us (5);
	q = dip_get_input (dip, f -> q);
	n = dip_get_input (dip, f -> nq);
	if (q || !n) {
		if (sniff) return false;
		printf ("FAIL: Q%d (%d) or -Q%d (%d) are incorrect after clocking in a zero\n", unit, q, unit, n);
		pass = false;
	}
	dip_set_output (dip, f -> clock, false);

	// test 4, clock in a one
	dip_set_output (dip, f -> data, true);
	dip_set_output (dip, f -> clock, true);
	sleep_us (5);
	q = dip_get_input (dip, f -> q);
	n = dip_get_input (dip, f -> nq);
	if (!q || n) {
		if (sniff) return false;
		printf ("FAIL: Q%d (%d) or -Q%d (%d) are incorrect after clocking in a one\n", unit, q, unit, n);
		pass = false;
	}
	dip_set_output (dip, f -> clock, false);
	dip_set_output (dip, f -> data, false);

	return pass;
}

bool
test_7474 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 1, 2, 3, 4, 10, 11, 12, 13 };	// pin number order; not particularly useful
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 5, 6, 8, 9 };						// also in pin order
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	flip_flop_t units [2] =
	{
		{  4,  1,  3,  2, 5, 6 },
		{ 10, 13, 11, 12, 9, 8 }
	};

	// let's test them independently for now
	bool pass = true;
	for (int i = 0; i < NELEMENTS (units); i++) {
		if (!test_7474_unit (&dip, &units [i], i)) {
			if (sniff) return false;
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

