
/*
 *	74_hex_gates.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 7404, 7414, etc. test module.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

static bool
common (bool (*func) (bool a, bool y, int unit))
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 1, 3, 5, 9, 11, 13 };		// ordered A1, A2, A3, A4, A5, A6
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 2, 4, 6, 8, 10, 12 };			// ordered Y1, Y2, Y3, Y4, Y5, Y6
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	for (int i = 0; i < 64; i++) {
		bool a1 = !!(i & 0x01);
		bool a2 = !!(i & 0x02);
		bool a3 = !!(i & 0x04);
		bool a4 = !!(i & 0x08);
		bool a5 = !!(i & 0x10);
		bool a6 = !!(i & 0x20);

		dip_set_outputs (&dip, outputs, i, 6);
		sleep_us (1);

		if (!func (a1, dip_get_input (&dip, inputs [0]), 0)) pass = false;
		if (!func (a2, dip_get_input (&dip, inputs [1]), 1)) pass = false;
		if (!func (a3, dip_get_input (&dip, inputs [2]), 2)) pass = false;
		if (!func (a4, dip_get_input (&dip, inputs [3]), 3)) pass = false;
		if (!func (a5, dip_get_input (&dip, inputs [4]), 4)) pass = false;
		if (!func (a6, dip_get_input (&dip, inputs [5]), 5)) pass = false;

		if (sniff && !pass) {
			return false;
		}
	}

	return pass;
}

static bool
test_invert (bool a, bool y, int unit)
{
	if (y != !a) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != -A%d (%d)\n", unit, y, unit, a);
		return false;
	}
	return true;
}

static bool
test_true (bool a, bool y, int unit)
{
	if (y != a) {
		if (sniff) return false;
		printf ("FAIL:  Y%d (%d) != A%d (%d)\n", unit, y, unit, a);
		return false;
	}
	return true;
}

bool
test_7404 (void)
{
	bool pass = common (test_invert);
	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

bool
test_7407 (void)
{
	bool pass = common (test_true);
	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

// to the tester, these all look the same
// bool test_7405 (void) { return test_7404 (); }	// not tested yet, requires pullup (open collector)
bool test_7414 (void) { return test_7404 (); }
