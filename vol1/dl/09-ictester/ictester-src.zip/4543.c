
/*
 *	4543.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 04	R. Krten		created
*/

#include "main.h"

/*
 *	CD 4543
 *
 *	BCD to Seven Segment Latch / Deocder / Driver
 *
 *	Inputs:
 *		 5	A
 *		 3	B
 *		 2	C
 *		 4	D
 *		 1	latch disable
 *		 6	phase
 *		 7	blanking
 *
 *	Outputs:
 *		 9	a
 *		10	b
 *		11	c
 *		12	d
 *		13	e
 *		15	f
 *		14	g
 *
 *	Presents the 7 segment decode of { A, B, C, D }.
 *	Valid values are 0 .. 9; values 10 .. 15 produce a blank.
 *	Latch disable can be high for direct operation -- what's presented on A, B, C, and D is immediately shown on a, b, c, d, e, f and g.
 *	When latch disable goes low, the last value of A, B, C and D is captured, and the inputs are ignored.
 *	Phase inverts the output when high.
 *	Blanking forces a .. g low (or high if phase is true).
*/

static void
print (bool *values, int n)
{
	for (int i = 0; i < n; i++) {
		printf ("%d ", *values++);
	}
	printf ("\n");
}

static void
capture (dip_t *dip, uint8_t *inputs, bool *values, int n)
{
	for (int i = 0; i < n; i++) {
		*values++ = dip_get_input (dip, *inputs++);
	}
//	print (values - n, n);
}

static bool seven_segments [16][7] =
{
	// a b c d e f g		   digit
	{  1,1,1,1,1,1,0 },		// 0
	{  0,1,1,0,0,0,0 },		// 1
	{  1,1,0,1,1,0,1 },		// 2
	{  1,1,1,1,0,0,1 },		// 3
	{  0,1,1,0,0,1,1 },		// 4
	{  1,0,1,1,0,1,1 },		// 5
	{  1,0,1,1,1,1,1 },		// 6
	{  1,1,1,0,0,0,0 },		// 7
	{  1,1,1,1,1,1,1 },		// 8
	{  1,1,1,1,0,1,1 },		// 9
	{  0,0,0,0,0,0,0 },		// (blank)
	{  0,0,0,0,0,0,0 },		// (blank)
	{  0,0,0,0,0,0,0 },		// (blank)
	{  0,0,0,0,0,0,0 },		// (blank)
	{  0,0,0,0,0,0,0 },		// (blank)
	{  0,0,0,0,0,0,0 },		// (blank)
};

bool
test_4543 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 5, 3, 2, 4, 1, 6, 7 };				// ordered A, B, C, D, Latch, Phase, Blank
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A		0
	#define	O_B		1
	#define	O_C		2
	#define	O_D		3
	#define	O_Latch	4
	#define	O_Phase	5
	#define	O_Blank	6

	uint8_t inputs [] = { 9, 10, 11, 12, 13, 15, 14 };			// ordered a, b, c, d, e, f, g
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool values [NELEMENTS (inputs)];

	// set outputs to a known state
	dip_set_output (&dip, outputs [O_A], false);
	dip_set_output (&dip, outputs [O_B], false);
	dip_set_output (&dip, outputs [O_C], false);
	dip_set_output (&dip, outputs [O_D], false);
	dip_set_output (&dip, outputs [O_Latch], false);
	dip_set_output (&dip, outputs [O_Phase], false);
	dip_set_output (&dip, outputs [O_Blank], false);
	sleep_us (1);

	bool pass = true;

	// test 1, verify blanking
	dip_set_output (&dip, outputs [O_Blank], true);
	sleep_us (1);
	capture (&dip, inputs, values, NELEMENTS (values));
	for (int s = 0; s < NELEMENTS (values); s++) {
		if (values [s]) {
			if (sniff) return false;
			printf ("FAIL:  with blanking enabled, segment %d (%c) is ON\n", s, s + 'a');
			pass = false;
		}
	}
	dip_set_output (&dip, outputs [O_Blank], false);

	// test 2, verify blanking with antiphase
	dip_set_output (&dip, outputs [O_Blank], true);
	dip_set_output (&dip, outputs [O_Phase], true);
	sleep_us (1);
	capture (&dip, inputs, values, NELEMENTS (values));
	for (int s = 0; s < NELEMENTS (values); s++) {
		if (!values [s]) {
			if (sniff) return false;
			printf ("FAIL:  with blanking and phase enabled, segment %d (%c) is OFF\n", s, s + 'a');
			pass = false;
		}
	}
	dip_set_output (&dip, outputs [O_Phase], false);
	dip_set_output (&dip, outputs [O_Blank], false);

	// test 3, verify expected decode outputs
	dip_set_output (&dip, outputs [O_Latch], true);					// allow A, B, C, and D to flow through immediately
	for (int i = 0; i < 16; i++) {
		bool a = !!(i & 1);
		bool b = !!(i & 2);
		bool c = !!(i & 4);
		bool d = !!(i & 8);
		dip_set_output (&dip, outputs [O_A], a);
		dip_set_output (&dip, outputs [O_B], b);
		dip_set_output (&dip, outputs [O_C], c);
		dip_set_output (&dip, outputs [O_D], d);
		sleep_us (1);

		capture (&dip, inputs, values, NELEMENTS (values));
		for (int s = 0; s < NELEMENTS (values); s++) {
			if (seven_segments [i][s] != values [s]) {
				if (sniff) return false;
				printf ("FAIL:  output %d segment %d expected %d\n", i, s, seven_segments [i][s]);
				pass = false;
			}
		}
	}

	// test 4, verify expected inverted decode outputs
	dip_set_output (&dip, outputs [O_Phase], true);					// invert
	for (int i = 0; i < 16; i++) {
		bool a = !!(i & 1);
		bool b = !!(i & 2);
		bool c = !!(i & 4);
		bool d = !!(i & 8);
		dip_set_output (&dip, outputs [O_A], a);
		dip_set_output (&dip, outputs [O_B], b);
		dip_set_output (&dip, outputs [O_C], c);
		dip_set_output (&dip, outputs [O_D], d);
		sleep_us (1);

		capture (&dip, inputs, values, NELEMENTS (values));
		for (int s = 0; s < NELEMENTS (values); s++) {
			if (seven_segments [i][s] == values [s]) {
				if (sniff) return false;
				printf ("FAIL:  output %d segment %d expected inverted value %d\n", i, s, !seven_segments [i][s]);
				pass = false;
			}
		}
	}
	dip_set_output (&dip, outputs [O_Phase], false);

	// test 5, verify that latch latches value prior to changing
	dip_set_output (&dip, outputs [O_A], true);						// set up value "7"
	dip_set_output (&dip, outputs [O_B], true);
	dip_set_output (&dip, outputs [O_C], true);
	dip_set_output (&dip, outputs [O_D], false);
	sleep_us (1);
	dip_set_output (&dip, outputs [O_Latch], false);				// capture the value
	sleep_us (1);
	capture (&dip, inputs, values, NELEMENTS (values));
	for (int s = 0; s < NELEMENTS (values); s++) {
		if (seven_segments [7][s] != values [s]) {		// expect decode for value "7"
			if (sniff) return false;
			printf ("FAIL:  fixed value 7 segment %d expected %d\n", s, seven_segments [7][s]);
			pass = false;
		}
	}

	dip_set_output (&dip, outputs [O_A], true);						// set up value "3"
	dip_set_output (&dip, outputs [O_B], true);
	dip_set_output (&dip, outputs [O_C], false);
	dip_set_output (&dip, outputs [O_D], false);
	sleep_us (1);

	capture (&dip, inputs, values, NELEMENTS (values));
	for (int s = 0; s < NELEMENTS (values); s++) {
		if (seven_segments [7][s] != values [s]) {		// expect decode for value "7"
			if (sniff) return false;
			printf ("FAIL:  latched value 7 segment %d expected %d\n", s, seven_segments [7][s]);
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

