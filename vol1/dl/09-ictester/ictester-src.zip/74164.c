
/*
 *	74164.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74164
 *
 *	8-bit parallel-out serial shift registers
 *
 *	Inputs:
 *		 9	-CLR
 *		 8	CLK
 *		 1	A
 *		 2	B
 *
 *	Outputs:
 *		 3	QA
 *		 4	QB
 *		 5	QC
 *		 6	QD
 *		10	QE
 *		11	QF
 *		12	QG
 *		13	QH
 *
 *	These 8-bit shift registers feature gated serial inputs and an asynchronous clear.
 *	The gated serial inputs (A and B) permit complete control over incoming data as a low at either
 *	input inhibits entry of the new data and resets the first flip-flop to the low level at the next
 *	clock pulse.
 *	A high-level input enables the other input which will then determine the state of the first
 *	flip-flop.
 *	Data at the serial inputs may be changed while the clock is high or low, but only information
 *	meeting the setup-time requirements will be entered.
 *	Clocking occurs on the low-to-high-level transition of the clock input.
*/

bool
test_74164 (void)
{
	dip_t dip;
	dip_init (&dip, 14, -1);

	uint8_t outputs [] = { 9, 8, 1, 2 };		// ordered { -CLR, CLK, A, B }
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum { O_CLR, O_CLK, O_A, O_B };

	uint8_t inputs [] = { 3, 4, 5, 6, 10, 11, 12, 13 };	// ordered { QA..H }
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

//printf ("\n");
	// initialize clock, A, B
	dip_set_output (&dip, outputs [O_CLK], false);		// clock is active on rising edge
	dip_set_output (&dip, outputs [O_A], true);			// A and B must both be high for QA's input to be high, or either low for QA's input to be low
	dip_set_output (&dip, outputs [O_B], true);

	// test 1, all outputs should be zero when clear is low
	dip_set_output (&dip, outputs [O_CLR], false);
	for (int bit = 0; bit < 8; bit++) {
		if (dip_get_input (&dip, inputs [bit])) {
			if (sniff) return false;
			printf ("FAIL 1: output Q%c is not low when CLEAR is low\n", bit + 'A');
			pass = false;
		}
	}
	dip_set_output (&dip, outputs [O_CLR], true);		// release clear condition

	// test 2, clock in 8 ones, you should see the ones ripple through
	for (int clocks = 0; clocks < 8; clocks++) {
//printf ("clock %d: ", clocks);
		dip_set_output (&dip, outputs [O_CLK], true);
		for (int bit = 0; bit < 8; bit++) {
			bool value = dip_get_input (&dip, inputs [bit]);
//printf ("%d ", value);
			sleep_us (1);
			if (bit <= clocks) {
				if (!value) {
					if (sniff) return false;
					printf ("FAIL 2: output Q%c is not high after clocking in %d ones\n", bit + 'A', clocks);
					pass = false;
				}
			} else {
				if (value) {
					if (sniff) return false;
					printf ("FAIL 3: output Q%c is not low after clocking in only %d ones\n", bit + 'A', clocks);
					pass = false;
				}
			}
		}
		dip_set_output (&dip, outputs [O_CLK], false);
//printf ("\n");
	}

	// test 3, clock in 8 zeros, you should see them ripple through
	bool zeroes [3][2] = { { 0, 0 }, { 0, 1 }, { 1, 0 }} ;	// these three combinatiosn of A and B yield a zero

	int rotor = 0;
	for (int clocks = 0; clocks < 8; clocks++) {
		dip_set_output (&dip, outputs [O_A], zeroes [rotor][0]);		// A and B must both be high for QA's input to be high, or either low for QA's input to be low
		dip_set_output (&dip, outputs [O_B], zeroes [rotor][1]);
		rotor = (rotor + 1) % 3;							// cycle through zero {A, B} sets
//printf ("clock %d: ", clocks);
		dip_set_output (&dip, outputs [O_CLK], true);
		for (int bit = 0; bit < 8; bit++) {
			bool value = dip_get_input (&dip, inputs [bit]);
//printf ("%d ", value);
			if (bit <= clocks) {
				if (value) {
					if (sniff) return false;
					printf ("FAIL 4: output Q%c is not low after clocking in %d zeros\n", bit + 'A', clocks);
					pass = false;
				}
			} else {
				if (!value) {
					if (sniff) return false;
					printf ("FAIL 5: output Q%c is not high after clocking in only %d zeros\n", bit + 'A', clocks);
					pass = false;
				}
			}
		}
		dip_set_output (&dip, outputs [O_CLK], false);
//printf ("\n");
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

