
/*
 *	74153.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74153
 *
 *	Dual 4-line to 1-line data selectors / demultiplexers
 *
 *	Inputs:
 *		14	A
 *		 2	B
 *		 1	1G
 *		15	2G
 *		 6	1C0
 *		 5	1C1
 *		 4	1C2
 *		 3	1C3
 *		10	2C0
 *		11	2C1
 *		12	2C2
 *		13	2C3
 *
 *	Outputs:
 *		 7	1Y
 *		 9	2Y
 *
 *	Each of these monolithic, data selectors/multiplexers contains inverters and drivers to supply
 *	fully complementary, on-chip, binary encoding data selection to the AND-OR gates.
 *	Separate strobe inputs are provided for each of the two four-line sections.
*/

bool
test_74153 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 14, 2, 1, 15, 6, 5, 4, 3, 10, 11, 12, 13 };		// ordered { A, B, 1G, 2G, 1C0..3, 2C0..3 }
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A		 0
	#define	O_B		 1
	#define	O_1G	 2
	#define	O_2G	 3
	#define	O_1C0	 4
	#define	O_1C1	 5
	#define	O_1C2	 6
	#define	O_1C3	 7
	#define	O_2C0	 8
	#define	O_2C1	 9
	#define	O_2C2	10
	#define	O_2C3	11

	uint8_t inputs [] = { 7, 9 };	// ordered { 1Y, 2Y }
	#define	I_1Y	0
	#define	I_2Y	1
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

//printf ("\n");
	bool pass = true;
	for (int t = 0; t < 1 << NELEMENTS (outputs); t++) {
		bool c1 [4];
		bool c2 [4];
		for (int bit = 0; bit < 4; bit++) {
			dip_set_output (&dip, outputs [O_1C0 + bit], c1 [bit] = !!(t & (1 << (bit + O_1C0))));
			dip_set_output (&dip, outputs [O_2C0 + bit], c2 [bit] = !!(t & (1 << (bit + O_2C0))));
		}
		bool a = t & (1 << O_A);
		bool b = t & (1 << O_B);
		bool g1 = t & (1 << O_1G);
		bool g2 = t & (1 << O_2G);
		dip_set_output (&dip, outputs [O_A], a);
		dip_set_output (&dip, outputs [O_B], b);
		dip_set_output (&dip, outputs [O_1G], g1);
		dip_set_output (&dip, outputs [O_2G], g2);

		bool y1 = dip_get_input (&dip, inputs [I_1Y]);
		bool y2 = dip_get_input (&dip, inputs [I_2Y]);

		int selected = a + 2 * b;

//printf ("%d%d (%d) %d x {%d %d %d %d}, %d x {%d %d %d %d} => {%d, %d}\n", a, b, selected, g1, c1 [0], c1 [1], c1 [2], c1 [3], g2, c2 [0], c2 [1], c2 [2], c2 [3], y1, y2);

		// according to the function table ...
		if (g1) {
			if (y1) {
				if (sniff) return false;
				printf ("FAIL 1: strobe G1 is high, but Y1 not low\n");
				pass = false;
			}
			continue;
		}

		if (y1 != c1 [selected]) {
			if (sniff) return false;
			printf ("FAIL 2: selected input 1C%d (%d) does not match value on Y1\n", selected, c1 [selected]);
			pass = false;
		}

		if (g2) {
			if (y2) {
				if (sniff) return false;
				printf ("FAIL 3: strobe G2 is high, but Y2 not low\n");
				pass = false;
			}
			continue;
		}

		if (y2 != c2 [selected]) {
			if (sniff) return false;
			printf ("FAIL 4: selected input 2C%d (%d) does not match value on Y2\n", selected, c2 [selected]);
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

