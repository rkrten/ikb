
/*
 *	main.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 02	R. Krten		created
 *	2025 12 10	R. Krten		placed one-line declarations inline, instead of including a header which had just one line of code
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "librk/cobs.h"

#define	KILO			1000
#define	NELEMENTS(_x)	(sizeof ((_x)) / sizeof ((_x) [0]))
#define	CP				{ printf ("[%s:%d]\n", __FILE__, __LINE__); }

#include "io.h"
#include "secondary.h"

bool test_2112 (void);

bool test_24c256 (void);

bool test_2316 (void);
bool test_2764 (void);

bool test_4016 (void);
bool test_4028 (void);
bool test_4051 (void);
bool test_4543 (void);

bool test_6830 (void);
bool test_6850 (void);

bool test_7400 (void);
bool test_7402 (void);
bool test_7404 (void);
bool test_7405 (void);
bool test_7407 (void);
bool test_7408 (void);
bool test_7410 (void);
bool test_7414 (void);
bool test_7430 (void);
bool test_7432 (void);
bool test_7474 (void);
bool test_7485 (void);
bool test_7486 (void);
bool test_74138 (void);
bool test_74151 (void);
bool test_74153 (void);
bool test_74154 (void);
bool test_74164 (void);
bool test_74166 (void);
bool test_74169 (void);
bool test_74175 (void);
bool test_74257 (void);
bool test_74259 (void);
bool test_74279 (void);
bool test_74279 (void);
bool test_74280 (void);
bool test_74374 (void);
bool test_74390 (void);
bool test_74393 (void);
bool test_74595 (void);
bool test_74688 (void);

#define	SERIAL_MSG_SIZE		8							// this is the largest packet we transmit; it fits within the FIFOs (32 bytes!) nicely.

// pins on production primary PICO
#define	P_PIN_A1	0
#define	P_PIN_B1	1
#define	P_PIN_A2	2
#define	P_PIN_B2	3
#define	P_PIN_A3	4
#define	P_PIN_B3	5
#define	P_PIN_A4	6
#define	P_PIN_B4	7
#define	P_PIN_A5	8
#define	P_PIN_B5	9
#define	P_PIN_A6	10
#define	P_PIN_B6	11
#define	P_PIN_A7	12
#define	P_PIN_A8	13
#define	P_PIN_A9	14
#define	P_PIN_A10	15
#define	P_TX		16
#define	P_RX		17
#define	P_PIN_B10	18
#define	P_PIN_B9	19
#define	P_PIN_B8	20
#define	P_PIN_B7	21
#define	P_DATA		22
#define	P_26		26
#define	P_27		27
#define	P_CLOCK		28

// pins on production secondary PICO
#define	S_PIN_A11	0
#define	S_PIN_B11	1
#define	S_PIN_A12	2
#define	S_PIN_B12	3
#define	S_PIN_A13	4
#define	S_PIN_B13	5
#define	S_PIN_A14	6
#define	S_PIN_B14	7
#define	S_PIN_A15	8
#define	S_PIN_B15	9
#define	S_PIN_A16	10
#define	S_PIN_B16	11
#define	S_PIN_A17	12
#define	S_PIN_B17	13
#define	S_PIN_A18	14
#define	S_PIN_A19	15
#define	S_TX		16
#define	S_RX		17
#define	S_PIN_B19	18
#define	S_PIN_B18	19
#define	S_20		20
#define	S_21		21
#define	S_22		22
#define	S_26		26
#define	S_27		27
#define	S_28		28

/*
 *	GPIO Map
 *
 *	Pin		GPIO	UART	I2C		SPI		ADC			----- Function ------
 *														Primary		Secondary
 *	---		----	----	-----	------	------		-----------	---------
 *	 1		 0											PIN_A1		PIN_A11
 *	 2		 1											PIN_B1		PIN_B11
 *	 4		 2											PIN_A2		PIN_A12
 *	 5		 3											PIN_B2		PIN_B12
 *	 6		 4											PIN_A3		PIN_A13
 *	 7		 5											PIN_B3		PIN_B13
 *	 9		 6											PIN_A4		PIN_A14
 *	10		 7											PIN_B4		PIN_B14
 *	11		 8											PIN_A5		PIN_A15
 *	12		 9											PIN_B5		PIN_B15
 *	14		 10											PIN_A6		PIN_A16
 *	15		 11											PIN_B6		PIN_B16
 *	16		 12											PIN_A7		PIN_A17
 *	17		 13											PIN_A8		PIN_B17
 *	19		 14											PIN_A9		PIN_A18
 *	20		 15											PIN_A10		PIN_A19
 *	21		 16		TX0									P_TX		S_TX
 *	22		 17		RX0									P_RX		S_RX
 *	24		 18											PIN_B10		PIN_B19
 *	25		 19											PIN_B9		PIN_B18
 *	26		 20											PIN_B8		S20
 *	27		 21											PIN_B7		S21
 *	29		 22											DATA		S22
 *	31		 26											P26			S26
 *	32		 27											P27			S27
 *	34		 28											CLOCK		S28
*/

extern	bool	primary;								// main.c, indicates if the software is running as a primary (true) or secondary (false)
extern	bool	sniff;									// main.c, don't print results and stop immediately on failure
extern	const char *mode;								// main.c, the detected operating mode
