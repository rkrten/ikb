
/*
 *	74257.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 74257 test module.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74257
 *
 *	Quadruple 2-line to 1-line data selectors / demultiplexers
 *
 *	Inputs:
 *		 1				A/-B
 *		15				-G
 *		 2	 5	11	14	An
 *		 3	 6	10	13	Bn
 *
 *	Outputs:
 *		 4	 7	 9	12	Yn
 *
 *	These devices are designed to multiplex signals from four-bit data sources to four-output data
 *	lines in bus-oriented systems. The 3-state outputs will not load the data lines when the -G output
 *	control pin is at a high-logic level.
*/

bool
test_74257 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 15, 2, 3, 5, 6, 11, 10, 14, 13 };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum { O_AB, O_G, O_A1, O_B1, O_A2, O_B2, O_A3, O_B3, O_A4, O_B4 };

	uint8_t inputs [] = { 4, 7, 9, 12 };
	enum { I_Y1, I_Y2, I_Y3, I_Y4 };
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;

	dip_set_output (&dip, outputs [O_G], false);		// enable outputs (@@@ we don't test for tristate yet)

	for (int ab = 0; ab < 2; ab++) {
		dip_set_output (&dip, outputs [O_AB], ab);		// select input source
		for (int t = 0; t < 16; t++) {					// 4 input bits
			bool i [4];
			bool o [4];
			for (int bit = 0; bit < 4; bit++) {
				// A and B are staggered:  A1, B1, A2, B2, A3, B3, A4, B4
				dip_set_output (&dip, outputs [O_A1 + 2 * bit], i [bit] = !!(t & (1 << bit)));
				dip_set_output (&dip, outputs [O_B1 + 2 * bit], !i [bit]);	// set B input to be opposite of A input
				o [bit] = dip_get_input (&dip, inputs [bit]);
				if (ab) {
					if (o [bit] == i [bit]) {
						if (sniff) return false;
						printf ("FAIL 1: selecting B but Y%c has A value %d\n", bit + 'A', o [bit]);
						pass = false;
					}
				} else {
					if (o [bit] != i [bit]) {
						if (sniff) return false;
						printf ("FAIL 2: selecting A but Y%c has B value %d\n", bit + 'A', o [bit]);
						pass = false;
					}
				}
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

