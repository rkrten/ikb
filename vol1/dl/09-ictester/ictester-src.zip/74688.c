
/*
 *	74688.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 10	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74688 (20 pin)
 *
 *	Inputs
 *		 1	-G
 *		 2	P0
 *		 3	Q0
 *		 4	P1
 *		 5	Q1
 *		 6	P2
 *		 7	Q2
 *		 8	P3
 *		 9	Q3
 *		11	P4
 *		12	Q4
 *		13	P5
 *		14	Q5
 *		15	P6
 *		16	Q6
 *		17	P7
 *		18	Q7
 *
 *	Outputs
 *		19	P=Q
*/

bool
test_74688 (void)
{
	dip_t dip;
	dip_init (&dip, 20, -1);

	uint8_t outputs [] = { 2, 4, 6, 8, 11, 13, 15, 17, 3, 5, 7, 9, 12, 14, 16, 18, 1 };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	enum {  O_P0, O_P1, O_P2, O_P3, O_P4, O_P5, O_P6, O_P7, O_Q0, O_Q1, O_Q2, O_Q3, O_Q4, O_Q5, O_Q6, O_Q7, O_G };

	uint8_t inputs [] = { 19 };							// just -P=Q
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;
	dip_set_output (&dip, outputs [O_G], false);		// enable outputs

	// test all possible combinations
	for (int t = 0; t < 1 << 16; t++) {
		uint8_t P = t & 0xff;
		uint8_t Q = (t >> 8) & 0xff;
		dip_set_outputs (&dip, outputs + O_P0, P, 8);
		dip_set_outputs (&dip, outputs + O_Q0, Q, 8);

		if (P == Q) {
			if (dip_get_input (&dip, inputs [0])) {
				if (sniff) return false;
				printf ("FAIL 1: Comparing %02X vs %02X claims unequal\n", P, Q);
				pass = false;
			}
		} else {
			if (!dip_get_input (&dip, inputs [0])) {
				if (sniff) return false;
				printf ("FAIL 1: Comparing %02X vs %02X claims equal\n", P, Q);
				pass = false;
			}
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

