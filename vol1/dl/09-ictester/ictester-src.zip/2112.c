
/*
 *	2112.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 06	R. Krten		created
*/

#include "main.h"

/*
 *	MF 2112
 *
 *	256 x 4 Static RAM
 *
 *	Inputs:
 *		 4 A0
 *		 3 A1
 *		 2 A2
 *		 1 A3
 *		15 A4
 *		 5 A5
 *		 6 A6
 *		 7 A7
 *
 *		13 -CE
 *		14 -WE
 *
 *	I/O:
 *		 9 D1
 *		10 D2
 *		11 D3
 *		12 D4
 *
 *	Each memory is implemented as 256 words by 4 bits per word.
 *	This organization allows efficient design of small memory systems and permits finer resolution of incremental memory word size relative to 1024 by 1 devices.
 *	The input and output data signals are internally bussed togeher and share 4 common I/O pins.
 *	This feature keeps the package size small and provides a simplified interface to bus-oriented systems
*/

bool
test_2112 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 4, 3, 2, 1, 15, 5, 6, 7, 13, 14 };	// ordered A0..A7, -CE, -WE
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_A0	0
	#define	O_A1	1
	#define	O_A2	2
	#define	O_A3	3
	#define	O_A4	4
	#define	O_A5	5
	#define	O_A6	6
	#define	O_A7	7
	#define	O_CE	8
	#define	O_WE	9

	uint8_t io [] = { 9, 10, 11, 12 };					// ordered D1..D3

	bool pass = true;

/*
	// test 1, disable chip and verify that data pins are tri-state
	dip_make_inputs (&dip, io, NELEMENTS (io));
	dip_set_output (&dip, outputs [O_CE], 1);
	dip_set_output (&dip, outputs [O_WE], 1);
	sleep_us (10);
	for (int i = 0; i < NELEMENTS (io); i++) {
		if (!dip_is_tristate (&dip, io [i])) {
			if (sniff) return false;
			printf ("FAIL 1: D%d (pin %d) is not tristate, it's %s\n", i + 1, io [i], dip_get_input (&dip, io [1]) ? "high" : "low");
			pass = false;
		}
	}
*/

	// test 2, write a test pattern, verify contents
	dip_make_outputs (&dip, io, NELEMENTS (io));
	uint8_t memory [256] = { 0 };
	if (!sniff) {
		printf ("STORING PATTERN:\n");
	}

	for (int i = 0; i < sizeof (memory); i++) {
		memory [i] = rand () & 0x0f;

		dip_set_outputs (&dip, outputs, i, 8);			// set up 8 address bits
		dip_set_outputs (&dip, io, memory [i], 4);		// set up 4 data bits

		if (!sniff) {
			if ((i % 32) == 0) {
				printf ("%02X ", i);
			}
			printf ("%X", memory [i]);
			if ((i % 32) == 31) {
				printf ("\n");
			}
		}

		// write pulse >250ns
		dip_set_output (&dip, outputs [O_WE], 0);		// enable write
		dip_set_output (&dip, outputs [O_CE], 0);		// enable chip
		sleep_us (1);									// it needs about a 250ns write pulse
		dip_set_output (&dip, outputs [O_WE], 1);		// disable write
		dip_set_output (&dip, outputs [O_CE], 1);		// disable chip
		sleep_us (1);
	}

	dip_make_inputs (&dip, io, NELEMENTS (io));
	dip_set_output (&dip, outputs [O_WE], 1);			// disable write
	dip_set_output (&dip, outputs [O_CE], 0);			// enable chip

	if (!sniff) {
		printf ("VERIFYING PATTERN\n");
	}
	for (int i = 0; i < sizeof (memory); i++) {

		dip_set_outputs (&dip, outputs, i, 8);			// set up 8 address bits

		sleep_us (1);									// data is stable > 250ns post address change

		uint8_t data = dip_get_inputs (&dip, io, 4);	// read 4 data bits

		if (data != memory [i]) {
			if (sniff) return false;
			printf ("FAIL 2: Data mismatch, address %02X read %X, expected %X\n", i, data, memory [i]);
			pass = false;
		}

		if (!sniff) {
			if ((i % 32) == 0) {
				printf ("%02X ", i);
			}
			printf ("%X", data);
			if ((i % 32) == 31) {
				printf ("\n");
			}
		}

		sleep_us (1);
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

