
/*
 *	74169.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74169 (16 pin)
 *
 *	Inputs
 *		 1	U/-D
 *		 2	CLK
 *		 3	A
 *		 4	B
 *		 5	C
 *		 6	D
 *		 7	-ENP
 *		 9	-LOAD
 *		10	-ENT

 *	Outputs
 *		14	QA
 *		13	QB
 *		12	QC
 *		11	QD
 *		15	-RCO
 *
 *	These synchronous presettable counters feature an internal carry look-ahead for cascading in high
 *	speed counting applications. The 'LS169B and 'S169 are 4-bit binary counters. Synchronous operation
 *	is provided by having all flip-flops clocked simultaneously so that the outputs change coincident
 *	with each other when so instructed by the count-enable inputs and internal gating. This mode of
 *	operation helps eliminate the output counting spikes that are normally associated with asynchronous
 *	(ripple-clock) counters. A buffered clock input triggers the four master-slave flip-flops on the
 *	rising (positive-going) edge of the clock waveform.
 *
 *	These counters are fully programmable; that is the outputs may each be preset to either level. The
 *	load input circuitry allows loading with the carry-enable output of cascaded counters. As loading
 *	is synchronous, setting up a low level at the load input disables the counter and causes the
 *	outputs to agree with the data inputs after the next clock pulse.
 *
 *	The carry look-ahead circuitry provides for cascading counters for n-bit synchronous applications
 *	without additional gating. Instrumental in accomplishing this function are two count-enable inputs
 *	(ENP and ENT) and a carry output. Both count enable inputs (ENP, ENT) must be low to count; the
 *	direction of the count is determined by the level of the up/down input. When the input is high, the
 *	counter counts up; when low, it counts down. Input ENT is fed forward to enable the carry output.
 *	The carry output thus enabled will produce a low-level output pulse with a duration approximately
 *	equal to the high portion of the QA output when counting up and approximately equal to the low
 *	portion of the QA output when counting down. This low-level overflow carry pulse can be used to
 *	enable successive cascaded stages. Transitions at the ENP or ENT inputs are allowed regardless of
 *	the level of the clock input. All inputs are diode-clamped to minimize transmission-line effects,
 *	thereby simplifying system design.
 *
 *	These counters feature a fully independent clock circuit. Changes at control inputs (ENP, ENT,
 *	LOAD, U/D) that will modify the operating mode have no effect until clocking occurs. The function
 *	of the counter (whether enabled, disabled, loading, or counting) will be dictated solely by the
 *	conditions meeting the stable setup and hold times.
*/

bool
test_74169 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 1, 2, 3, 4, 5, 6, 7, 9, 10 };
	enum {  O_UD, O_CLK, O_A, O_B, O_C, O_D, O_ENP, O_LOAD, O_ENT };
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));

	uint8_t inputs [] = { 14, 13, 12, 11, 15 };
	enum { I_A, I_B, I_C, I_D, I_RCO };
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	bool pass = true;
	dip_set_output (&dip, outputs [O_LOAD], true);		// inhibit loading
	dip_set_output (&dip, outputs [O_CLK], false);		// clock is active on the rising edge
	dip_set_output (&dip, outputs [O_UD], true);		// count up
	dip_set_output (&dip, outputs [O_ENT], false);		// enable ENT
	dip_set_output (&dip, outputs [O_ENP], false);		// enable ENP

	// test 1, load values 0..15 into the counter
	dip_set_output (&dip, outputs [O_LOAD], false);		// enable loading
	for (int i = 0; i < 16; i++) {
		bool v [4];
		dip_set_output (&dip, outputs [O_A], v [0] = !!(i & 1));
		dip_set_output (&dip, outputs [O_B], v [1] = !!(i & 2));
		dip_set_output (&dip, outputs [O_C], v [2] = !!(i & 4));
		dip_set_output (&dip, outputs [O_D], v [3] = !!(i & 8));
		dip_set_output (&dip, outputs [O_CLK], true);	// clock data in
		dip_set_output (&dip, outputs [O_CLK], false);
		for (int bit = 0; bit < 4; bit++) {
			if (dip_get_input (&dip, inputs [I_A + bit]) != v [bit]) {
				if (sniff) return false;
				printf ("FAIL 1: loaded value %c=%d not present on output\b", 'A' + bit, v [bit]);
				pass = false;
			}
		}
	}

	// test 2, count 0..15..0
	dip_set_output (&dip, outputs [O_LOAD], true);		// inhibit loading
	dip_set_output (&dip, outputs [O_CLK], true);		// clock data in
	dip_set_output (&dip, outputs [O_CLK], false);
	dip_set_outputs (&dip, outputs + O_A, 0, 4);
	for (int clocks = 0; clocks < 16; clocks++) {
		uint8_t value = dip_get_inputs (&dip, inputs + I_A, 4);
		if (value != clocks) {
			if (sniff) return false;
			printf ("FAIL 2: counting up expected value %X, got %X\n", clocks, value);
			pass = false;
		}
		if (clocks < 15) {								// don't clock last one
			dip_set_output (&dip, outputs [O_CLK], true);	// clock data in
			dip_set_output (&dip, outputs [O_CLK], false);
		}
	}

	dip_set_output (&dip, outputs [O_UD], false);		// count down
	for (int clocks = 15; clocks >= 0; clocks--) {
		uint8_t value = dip_get_inputs (&dip, inputs + I_A, 4);
		if (value != clocks) {
			if (sniff) return false;
			printf ("FAIL 3: counting down expected value %X, got %X\n", clocks, value);
			pass = false;
		}
		dip_set_output (&dip, outputs [O_CLK], true);	// clock data in
		dip_set_output (&dip, outputs [O_CLK], false);
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

