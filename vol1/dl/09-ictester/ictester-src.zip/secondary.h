
/*
 *	secondary.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 04	R. Krten		created
*/

void secondary (void);
void secondary_disable_tx (void);
void secondary_enable_tx (void);

