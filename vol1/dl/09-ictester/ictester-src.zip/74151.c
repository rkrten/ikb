
/*
 *	74151.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the 74151 test module.
 *
 *	2025 12 09	R. Krten		created
*/

#include "main.h"

/*
 *	SN 74151
 *
 *	1-of-8 data selectors / demultiplexers
 *
 *	Inputs:
 *		 4	D0
 *		 3	D1
 *		 2	D2
 *		 1	D3
 *		15	D4
 *		14	D5
 *		13	D6
 *		12	D7
 *		 7	-G
 *		11	A
 *		10	B
 *		 9	C
 *
 *	Outputs:
 *		 6	W
 *		 5	Y
 *
 *	This monolithic data selector / multiplexer contains full on-chip binary decoding to select the desired data source.
 *	It selects one-of-eight data sources.
 *	It has a strobe input which must be at a low logic level to enable the device.
 *	A high level at the strobe forces the W output high, and the Y output low.
*/


bool
test_74151 (void)
{
	dip_t dip;
	dip_init (&dip, 16, -1);

	uint8_t outputs [] = { 4, 3, 2, 1, 15, 14, 13, 12, 7, 11, 10, 9 };		// ordered { D0..7 -G, A, B, C }
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_D0	0
	#define	O_G		8
	#define	O_A		9
	#define	O_B		10
	#define	O_C		11

	uint8_t inputs [] = { 6, 5 };	// ordered { W, Y }
	#define	I_W		0
	#define	I_Y		1
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

//printf ("\n");
	bool pass = true;
	for (int t = 0; t < 1 << 12; t++) {
		bool d [8];
		for (int bit = 0; bit < 8; bit++) {
			dip_set_output (&dip, outputs [O_D0 + bit], d [bit] = !!(t & (1 << bit)));
		}
		bool a = t & (1 << O_A);
		bool b = t & (1 << O_B);
		bool c = t & (1 << O_C);
		bool g = t & (1 << O_G);
		dip_set_output (&dip, outputs [O_A], a);
		dip_set_output (&dip, outputs [O_B], b);
		dip_set_output (&dip, outputs [O_C], c);
		dip_set_output (&dip, outputs [O_G], g);

		bool w = dip_get_input (&dip, inputs [I_W]);
		bool y = dip_get_input (&dip, inputs [I_Y]);

		int selected = a + 2 * b + 4 * c;

//printf ("%d%d%d (%d) %d [%d %d %d %d %d %d %d %d] => %d / -%d\n", a, b, c, selected, g, d [0], d [1], d [2], d [3], d [4], d [5], d [6], d [7], y, w);
		// according to the function table ...
		if (g) {
			if (y || !w) {
				if (sniff) return false;
				printf ("FAIL 1: strobe G is high, but Y is %d and W is %d\n", y, w);
				pass = false;
			}
			continue;
		}

		if (w == d [selected]) {
			if (sniff) return false;
			printf ("FAIL 2: selected input %d value %d does not match W (inverted value)\n", selected, d [selected]);
			pass = false;
		}
		if (y != d [selected]) {
			if (sniff) return false;
			printf ("FAIL 2: selected input %d value %d does not match Y (true value)\n", selected, d [selected]);
			pass = false;
		}
	}

	if (!sniff && pass) {
		printf ("PASS\n");
	}
	return pass;
}

