
/*
 *	io.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 11 08	R. Krten		created
*/

typedef enum {
	PICO_LOCAL,
	PICO_REMOTE,
	PICO_INVALID										// error condition
} pico_id_t;

// Opaque handle for GPIO operations
typedef struct {
	pico_id_t	pico;
	uint8_t		gpio;
} hal_pin_t;

#define	NZIF	40

typedef struct {
	hal_pin_t	halpin [NZIF];
	const char *name [NZIF];
	int			npins;
} dip_t;

void dip_init (dip_t *dip, int npins, int ground_pin);
void dip_make_outputs (dip_t *, const uint8_t *olist, int n);
void dip_make_inputs (dip_t *, const uint8_t *ilist, int n);
void dip_set_output (dip_t *, uint8_t pin, bool val);
void dip_set_outputs (dip_t *, uint8_t *pins, uint32_t value, int nbits);
bool dip_get_input (dip_t *, uint8_t pin);
uint32_t dip_get_inputs (dip_t *, uint8_t *pin, int nbits);
void dip_name_pin (dip_t *, uint8_t pin, const char *name);
const char *dip_pin_name (dip_t *, uint8_t pin);
bool dip_is_tristate (dip_t *, uint8_t pin);

// raw gpio functions
bool is_tristate (int pin);
void make_output (uint8_t pin);
void make_input (uint8_t pin);

void init_hw (void);
void reset_hw (void);
void loopback_test (void);
void detect_secondary (void);

