
/*
 *	27_eprom.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 06	R. Krten		created
*/

#include "main.h"
#include "hardware/sha256.h"

/*
 *	27xxx series EPROM tester
 *
 *	This is the test framework for 2716..27512 EPROMs.
 *	"Test" is a strong word, in that we don't program them, we just read back the data and verify that it reads back the same each time.
*/

/*
 *	2316 Mask programmable ROM, such as used in Heathkit ET3400A trainer p/n 444-76
 *
 *	Inputs:
 *		 8	A0
 *		 7	A1
 *		 6	A2
 *		 5	A3
 *		 4	A4
 *		 3	A5
 *		 2	A6
 *		 1	A7
 *		23	A8
 *		22	A9
 *		19	A10
 *
 *		18	-CS2
 *		20	-CS1
 *		21	CS0
 *
 *	Outputs:
 *		 9	D0
 *		10	D1
 *		11	D2
 *		13	D3
 *		14	D4
 *		15	D5
 *		16	D6
 *		17	D7
*/

#define	Initialize	-1
#define	Flush		-2

static uint8_t *
hasher (int v)
{
	static uint8_t hashdata [64];
	static uint8_t sha256 [256 / 8];
	static uint64_t bits = 0;

	if (v == Initialize) {
		sha256_set_bswap (true);
		sha256_start ();
		memset (hashdata, 0, sizeof (hashdata));
		bits = 0;
		return NULL;
	}

	const uint32_t *w = (const uint32_t *) hashdata;

	if (v != Flush) {
		int posh = (bits >> 3) & 63;
		hashdata [posh] = v;
		bits += 8;
		if (posh == 63) {
			sha256_wait_ready_blocking ();
			for (int i = 0; i < 16; i++) sha256_put_word (w [i]);
		}
		return NULL;
	}

	// Flush: emit SHA-256 padding (0x80, zeros, 64-bit big-endian bit length).
	int posh = (bits >> 3) & 63;
	hashdata [posh++] = 0x80;

	if (posh > 56) {
		while (posh < 64) hashdata [posh++] = 0;
		sha256_wait_ready_blocking ();
		for (int i = 0; i < 16; i++) sha256_put_word (w [i]);
		posh = 0;
	}
	while (posh < 56) hashdata [posh++] = 0;

	uint64_t len = bits;
	for (int i = 7; i >= 0; i--) {
		hashdata [56 + i] = len & 0xff;
		len >>= 8;
	}

	sha256_wait_ready_blocking ();
	for (int i = 0; i < 16; i++) sha256_put_word (w [i]);

	while (!sha256_is_sum_valid ()) ;
	sha256_get_result ((sha256_result_t *) sha256, SHA256_BIG_ENDIAN);
	return sha256;
}

typedef struct
{
	char hash [256 / 8 * 2 + 1];							// hash as ASCII digits
	const char *id;
} HashData;

static HashData hash_db [] =
{
	// Mitel SX-20 Generic 503-02
	{ "7A5A792A3B4A6EB3A0985712FFD544C7358DF0097DFFF22721802F58EB8ADCD6", "Mitel SX-20 Generic 503-02 U19 [04000-05FFF]" },
	{ "85A890DD3455A3E9BE5883D560FD46CD632D420FDBC32ABFF6B456CB987E72B2", "Mitel SX-20 Generic 503-02 U20 [06000-07FFF]" },
	{ "0DC2936D7F86E6C0EE240FD541095806700F31853562EF059CC393D9F960C792", "Mitel SX-20 Generic 503-02 U21 [08000-09FFF]" },
	{ "CC76125BCA5A802E1DAA47173A8242E161AE1C0A38AA7A36277E948DA401BA10", "Mitel SX-20 Generic 503-02 U22 [0A000-0BFFF]" },
	{ "AA1A4CE26D7B48DB8EF5F35B8300184EFB1374C233F73872585FA75BAD99DE20", "Mitel SX-20 Generic 503-02 U23 [0C000-0DFFF]" },
	{ "6F4A96219D1897C3891CD44AB0CD25F50AE13C462FD66FCCF1AB321FD27F3C7A", "Mitel SX-20 Generic 503-02 U24 [0E000-0FFFF]" },
	{ "9FBF4E9823B64B157DB48A1D32178C3674FD6CC4391A4554C05827223CAFFD33", "Mitel SX-20 Generic 503-02 U27 [14000-15FFF]" },
	{ "628C7871ED992A856B4E88D34E321456854045A7D195BDEC9E335626DF90BB87", "Mitel SX-20 Generic 503-02 U28 [16000-17FFF]" },
	{ "07C87FBECB1DC6649A8FE84ED544C7C9E3DE83DAB2D2BF5B96B53BC083203267", "Mitel SX-20 Generic 503-02 U29 [18000-19FFF]" },
	{ "372630D242E596016ABB5CB1E1917571B8E0BF2544D62DC1C18406DAF4C8A780", "Mitel SX-20 Generic 503-02 U30 [1A000-1BFFF]" },
	{ "7AC37C17A9E42C14CB79E38A23A99F5A3F7953486AB91AD9C5893D896C8C030C", "Mitel SX-20 Generic 503-02 U31 [1C000-1DFFF]" },
	{ "C6F74368EEA76432D37DC0AF4E4F555254408ED4C02F2F7FA5CCED652ACEC020", "Mitel SX-20 Generic 503-02 U32 [1E000-1FFFF]" },

	// Mitel SX-20 Generic 503-06
	{ "5605B4928DEE6CABDE00772DD703AEE85281609281A1CFC6D1B9A6D51367ABCD", "Mitel SX-20 Generic 503-06 U19 [04000-05FFF]" },
	{ "A1F8B735FFC2E854FF00CD46CCCF31B6A5459ADF1216E0ACD064D23E5B35A2DD", "Mitel SX-20 Generic 503-06 U27 [14000-15FFF]" },
	{ "166CF43118077580E2E53804C51D315544FD0F6216CE82D6F23C36E052B792F5", "Mitel SX-20 Generic 503-06 U28 [16000-17FFF]" },
	{ "C090D8E5EA9A70BD61DEB2D6A3FFACDC57CE9233606211B3F7AFB7729286E82E", "Mitel SX-20 Generic 503-06 U29 [18000-19FFF]" },
	{ "88885BE295FF1F4E286CB8B6FA15CD1CDBA0365E45B7D0496E07ABFADA9A8385", "Mitel SX-20 Generic 503-06 U30 [1A000-1BFFF]" },
	{ "5B41AAE6F416F0B49B4675289AA4C71D2702A99835C28A2DEEA5A791603A6171", "Mitel SX-20 Generic 503-06 U31 [1C000-1DFFF]" },
	{ "541FA9A3EB89ABB72008B08E3446C338EFCE80760C59C5EF152DE0CB2BF3CB6B", "Mitel SX-20 Generic 503-06 U32 [1E000-1FFFF]" },

	// Mitel SX-20 Generic 503-07
	{ "0DE7932A5C24147F88388F43E1356488D2BD5504746FF07B9656181EF8B69801", "Mitel SX-20 Generic 503-07 U19 [04000-05FFF]" },
	{ "147AFC4CAAD4C7CE37E114477B2B7CAD047C8FF2709781CF02FF6732C30DA227", "Mitel SX-20 Generic 503-07 U27 [14000-15FFF]" },
	{ "AA499163AA3F9DD09D8C0A30987CB99D912B5A4BE7306FBC34C4BA044D49E42A", "Mitel SX-20 Generic 503-07 U28 [16000-17FFF]" },
	{ "4FF02DC2CF15165EB899A15D2D19043C4A5D69EBCC2128858805C59E435EB27A", "Mitel SX-20 Generic 503-07 U29 [18000-19FFF]" },
	{ "812E38AEB3A30DB14F6FAAE80DEA943D19AD4D79CEB86FFE76354B9EFF84EA2B", "Mitel SX-20 Generic 503-07 U30 [1A000-1BFFF]" },
	{ "5049D5227E2C9331CAFA4F0737DAA86A01612961CEA38F9BBA7B661DB132114C", "Mitel SX-20 Generic 503-07 U31 [1C000-1DFFF]" },
	{ "46BD1F1108A0051389D08B79FFE69CBEA35B19CFC8796E49876129D9FE3937DD", "Mitel SX-20 Generic 503-07 U32 [1E000-1FFFF]" },

	// Mitel SX-20 Common to both 503-06 and 503-07
	{ "CFB123A8EF160795C6B19F3BD5B419E86E1EE94C74CCB2B8EF9BFEB5F9270B09", "Mitel SX-20 Generic 503-06/07 U20 [06000-07FFF]" },
	{ "8BCEE142D16F2FAFB0C28CB578D8AAE7BCE80DA02BD747AFC9546BF693BCB936", "Mitel SX-20 Generic 503-06/07 U21 [08000-09FFF]" },
	{ "2FE97F582162B601513FF985436756EA97A72EFD02504BEEE9D02133900F62AF", "Mitel SX-20 Generic 503-06/07 U22 [0A000-0BFFF]" },
	{ "F03014BDFB100DBBF4208D39BCE696335C853BD92F42F8C0B72DCFD389A7939D", "Mitel SX-20 Generic 503-06/07 U23 [0C000-0DFFF]" },
	{ "6A9411760FD3B7347534C0A858C7D905F7B53655C3F864827C2693EDA5A08243", "Mitel SX-20 Generic 503-06/07 U24 [0E000-0FFFF]" },

	// Heathkit
	{ "9F3CAA287E367E90388DCC6014A7BD2DF77831F052B4A1E9FB7E578AC1D5510E", "Heathkit 444-76 Prom for EWT3400A" },
};

static const char *
match_hash (uint8_t *h, bool sniff)
{
	char hstring [256 / 8 * 2 + 1];
	for (int i = 0; i < 256 / 8; i++) {
		sprintf (hstring + i * 2, "%02X", h [i]);
	}
	// sprintf automatically plops a nul terminator at hstring [64] for us

	if (!sniff) {
		printf ("%s\n", hstring);
	}

	for (int i = 0; i < NELEMENTS (hash_db); i++) {
		bool found = true;
		for (int b = 0; b < 256 / 8 * 2; b++) {
			if (hash_db [i].hash [b] != hstring [b]) {
				found = false;
				break;
			}
		}
		if (found) {
			return hash_db [i].id;
		}
	}

	return NULL;
}

static void
byte16 (int v)
{
	static char content [17] = { 0 };					// nul termination at [16]
	static uint16_t addr = 0;

	if (v == Initialize) {
		memset (content, 0, sizeof (content));
		addr = 0;
		return;
	}

	int pos = addr & 15;

	if (v != Flush) {
		if (!pos) {
			printf ("%04X ", addr);
		}

		content [pos] = isprint (v) ? v : '.';
		printf ("%02X ", v);

		if (pos == 7) {
			printf (" ");
		}

		addr++;
	}

	if (v == Flush || pos == 15) {
		printf (" %s\n", content);
		memset (content, 0, sizeof (content));
	}
}

bool
test_2316 (void)
{
	dip_t dip;
	dip_init (&dip, 24, -1);

	//						0  1  2  3  4  5  6  7   8   9  10  11  12  13
	uint8_t outputs [] = {  8, 7, 6, 5, 4, 3, 2, 1, 23, 22, 19, 18, 20, 21};	// ordered A0..10, -CS2 -CS1, CS0
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_NCS2	11
	#define	O_NCS1	12
	#define	O_CS0	13

	uint8_t inputs [] = { 9, 10, 11, 13, 14, 15, 16, 17 };		// ordered D0..D7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	// test 1, disable chip and verify that data pins are tri-state
	dip_set_output (&dip, outputs [O_NCS2], 1);
	dip_set_output (&dip, outputs [O_NCS1], 1);
	dip_set_output (&dip, outputs [O_CS0],  0);

	sleep_us (10);
	for (int i = 0; i < NELEMENTS (inputs); i++) {
		if (!dip_is_tristate (&dip, inputs [i])) {
			if (!sniff) {
				printf ("FAIL 1: D%d (pin %d) is not tristate, it's %s\n", i, inputs [i], dip_get_input (&dip, inputs [1]) ? "high" : "low");
			}
		}
	}

	// test 2, read some contents
	dip_set_output (&dip, outputs [O_NCS2], 0);			// negative logic
	dip_set_output (&dip, outputs [O_NCS1], 0);
	dip_set_output (&dip, outputs [O_CS0], 1);			// positive logic

	if (!sniff) {
		byte16 (Initialize);
	}
	hasher (Initialize);
	if (!sniff) {
		printf ("\n");
	}
	for (int i = 0; i < 2048; i++) {
		// set up address
		dip_set_outputs (&dip, outputs, i, 11);			// there are 13 address bits

		sleep_us (1);
		uint8_t data = dip_get_inputs (&dip, inputs, 8);
		if (!sniff) {
			byte16 (data);
		}
		hasher (data);
	}
	// we don't need to call byte16 (Flush) because we ended on a divisible by 16 boundary

	const char *id = match_hash (hasher (Flush), sniff);

	if (id) {
		if (!sniff) {
			printf ("PASS: ");
		}
		printf ("2316 PROM %s\n", id);
		return true;
	}
	return false;

	#undef O_NCS2
	#undef O_NCS1
	#undef O_CS0
}

/*
 *	2764
 *	Inputs:
 *		10	A0
 *		 9	A1
 *		 8	A2
 *		 7	A3
 *		 6	A4
 *		 5	A5
 *		 4	A6
 *		 3	A7
 *		25	A8
 *		24	A9
 *		21	A10
 *		23	A11
 *		 2	A12
 *
 *		20	-E
 *		22	-G
 *		27	-P
 *
 *	Outputs:
 *		11	Q0
 *		12	Q1
 *		13	Q2
 *		15	Q3
 *		16	Q4
 *		17	Q5
 *		18	Q6
 *		19	Q7
*/

bool
test_2764 (void)
{
	dip_t dip;
	dip_init (&dip, 28, -1);

	//						0  1  2  3  4  5  6  7   8   9  10  11 12  13  14  15 16
	uint8_t outputs [] = { 10, 9, 8, 7, 6, 5, 4, 3, 25, 24, 21, 23, 2, 20, 22, 27, 1 };	// ordered A0..A12, -E, -G, -P, VPP
	dip_make_outputs (&dip, outputs, NELEMENTS (outputs));
	#define	O_E	13
	#define	O_G	14
	#define	O_P	15
	#define	O_VPP 16

	uint8_t inputs [] = { 11, 12, 13, 15, 16, 17, 18, 19 };		// ordered Q0..Q7
	dip_make_inputs (&dip, inputs, NELEMENTS (inputs));

	dip_set_output (&dip, outputs [O_VPP], 1);
	dip_set_output (&dip, outputs [O_P], 1);			// disable programming

	// test 1, disable chip and verify that data pins are tri-state
	dip_set_output (&dip, outputs [O_E], 0);
	dip_set_output (&dip, outputs [O_G], 1);

	sleep_us (10);
	for (int i = 0; i < NELEMENTS (inputs); i++) {
		if (!dip_is_tristate (&dip, inputs [i])) {
			if (!sniff) {
				printf ("FAIL 1: Q%d (pin %d) is not tristate, it's %s\n", i, inputs [i], dip_get_input (&dip, inputs [1]) ? "high" : "low");
			}
		}
	}

	// test 2, read some contents
	dip_set_output (&dip, outputs [O_E], 0);			// enable device
	dip_set_output (&dip, outputs [O_G], 1);			// disable output gate

	hasher (Initialize);
	if (!sniff) {
		byte16 (Initialize);
		printf ("\n");
	}

	for (int i = 0; i < 8192; i++) {
		// set up address
		dip_set_outputs (&dip, outputs, i, 13);			// there are 13 address bits

		dip_set_output (&dip, outputs [O_G], 0);		// enable output gate
		sleep_us (1);
		uint8_t data = dip_get_inputs (&dip, inputs, 8);
		dip_set_output (&dip, outputs [O_G], 1);		// disable output gate
		sleep_us (1);

		if (!sniff) {
			byte16 (data);
		}
		hasher (data);
	}
	// we don't need to call byte16 (Flush) because we ended on a divisible by 16 boundary

	const char *id = match_hash (hasher (Flush), sniff);

	if (id) {
		if (!sniff) {
			printf ("PASS: ");
		}
		printf ("2764 EPROM %s\n", id);
		return true;
	}
	return false;

	#undef	O_E
	#undef	O_P
	#undef	O_G
	#undef	O_VPP
}

