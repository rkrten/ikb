
/*
 *	main.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This is the IC tester.
 *
 *	2025 11 02	R. Krten		created
*/

#include "main.h"

bool	primary;										// indicates if the software is running as a primary (true) or secondary (false)
bool	sniff;											// if true, the test doesn't print anything, just returns pass/fail
const char *mode;										// the detected operating mode

void toggle (int);										// diagnostic

static struct
{
	const char *part;
	const char *description;
	bool (*func) (void);
} database [] =
{
	{ "2112",	"256 x 4 static RAM",															test_2112 },
//	{ "24C256",	"2-wire serial EEPROM (256kbit)",												test_24c256 },
	{ "2316",	"2k x 8 Mask programmed ROM",													test_2316 },
	{ "2764",	"8k x 8 UV EPROM",																test_2764 },
	{ "4016",	"Quad bilateral switch",														test_4016 },
	{ "4028",	"BCD to decimal decoder",														test_4028 },
	{ "4051",	"Single 8-channel analog multiplexer / demultiplexer",							test_4051 },
	{ "4543",	"BCD to seven segment latch / decoder / driver",								test_4543 },
	{ "6830",	"512-byte MIKBUG PROM",															test_6830 },
	{ "6850",	"Asynchronous Communications Interface Adapter (ACIA)",							test_6850 },
	{ "7400",	"Quadruple 2 input NAND gates",													test_7400 },
	{ "7402",	"Quadruple 2 input NOR gates",													test_7402 },
	{ "7404",	"Hex inverters",																test_7404 },
//	{ "7405",	"Hex inverters with OC outputs",												test_7405 },
//	{ "7407",	"Hex buffers with OC high voltage outputs",										test_7407 },
	{ "7408",	"Quadruple 2 input AND gates",													test_7408 },
	{ "7410",	"Triple 3-input NAND gates",													test_7410 },
	{ "7414",	"Hex Schmitt trigger inverters",												test_7414 },
	{ "7430",	"8-input positive NAND gate",													test_7430 },
	{ "7432",	"Quadruple 2 input OR gates",													test_7432 },
	{ "7474",	"Dual d-type positive edge triggered flip flops with preset and clear",			test_7474 },
	{ "7485",	"4-bit magnitude comparator",													test_7485 },
	{ "7486",	"Quadruple 2 input XOR gates",													test_7486 },
	{ "74390",	"Dual 4-bit decade counters",													test_74390 },
	{ "74393",	"Dual 4-bit binary counters",													test_74393 },
	{ "74138",	"3-line to 8-line decoder",														test_74138 },
	{ "74151",	"1-of-8 data selector / multiplexer",											test_74151 },
	{ "74153",	"Dual 4-line to 1-line data selector / multiplexer",							test_74153 },
	{ "74154",	"4-line to 16-line decoder",													test_74154 },
	{ "74164",	"8-bit parallel-out / serial shift register",									test_74164 },
	{ "74166",	"8-bit parallel-in / serial-out shift register",								test_74166 },
	{ "74169",	"Synchronous 4-bit up/down binary counters",									test_74169 },
	{ "74175",	"Quadruple d-type flip-flops with clear",										test_74175 },
	{ "74257",	"Quadruple 2-line to 1-line data selector / multiplexer",						test_74257 },
	{ "74259",	"8-bit addressable latch",														test_74259 },
	{ "74279",	"Quadruple S/R latches",														test_74279 },
	{ "74280",	"9-bit odd/even parity generator/checker",										test_74280 },
	{ "74374",	"Octal d-type edge-triggered flip flop",										test_74374 },
	{ "74595",	"8-bit shift register with 3-state output registers",							test_74595 },
	{ "74688",	"8-bit identity comparator",													test_74688 },
};

static void
autodetect (void)
{
	sniff = true;
	bool any = false;
	for (int i = 0; i < NELEMENTS (database); i++) {
		if (database [i].func ()) {
			printf ("%s (%s) detected\n", database [i].part, database [i].description);
			any = true;
		}
	}
	if (!any) {
		printf ("Could not auto-detect chip\n");
	}
	sniff = false;
}

static void
menu (void)
{
	bool printed = false;

	for (;;) {
		reset_hw ();									// reset hardware at the start of each test
		if (!printed) {
			printf ("\n");
			printf ("IKCH55 PICO IC tester (%s)\n", mode);
			printf ("---------------------\n");
			printf ("Select device:\n");
			for (int i = 0; i < NELEMENTS (database); i++) {
				char selector = i < 10 ? '0' + i : 'a' + i - 10;
				printf ("  %c %6.6s %s\n", selector, database [i].part, database [i].description);
			}

			printf ("  A autodetect\n");
/*
			printf ("  D detect secondary test\n");
			printf ("  L loopback test\n");
			printf ("  S toggle pin  4 gnd\n");
			printf ("  T toggle pin  7 gnd\n");
			printf ("  U toggle pin  8 gnd\n");
			printf ("  V toggle pin  9 gnd\n");
			printf ("  W toggle pin 10 gnd\n");
			printf ("  X toggle pin 12 gnd\n");
			printf ("  Y toggle pin 14 gnd\n");
			printf ("  Z toggle pin 16 gnd\n");
*/
		}

		printf ("> ");
		int c = getc (stdin);
		printf ("%c\n", c);
		printed = false;

		if (isdigit (c) || islower (c)) {
			int index = c <= '9' ? c - '0' : c - 'a' + 10;
			if (index < NELEMENTS (database)) {
				printf ("TESTING %s ... ", database [index].part);
				database [index].func ();
				printed = true;
			} else {
				printf ("*** Invalid selection\n");
			}
		} else {
			switch (c) {
			case	'A': autodetect();			break;
/*
			case	'D': detect_secondary();	break;
			case	'L': loopback_test();		break;
			case	'S': toggle (4);			break;
			case	'T': toggle (7);			break;
			case	'U': toggle (8);			break;
			case	'V': toggle (9);			break;
			case	'W': toggle (10);			break;
			case	'X': toggle (12);			break;
			case	'Y': toggle (14);			break;
			case	'Z': toggle (16);			break;
*/
			case	'\n':
			case	'\r':
				// ignore RK's nervous tick of hitting return all the time
				printed = true;
				break;

			default:
				printf ("*** Invalid selection\n");
				break;
			}
		}
	}
}

int main ()
{
	stdio_init_all ();
	stdio_set_translate_crlf (&stdio_usb, false);
	while (getchar_timeout_us (1) != PICO_ERROR_TIMEOUT) ;	// clear out any junk

	init_hw ();
	sniff = false;

	if (primary) {
		menu ();										// drive processing via the menu
	} else {
		secondary ();									// wait for commands from the primary
	}
}

