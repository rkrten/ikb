
/*
 *	cobs.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This library module contains the COBS encode/decode routines.
 *
 *	2025 12 05	R. Krten		created
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/*
 *	COBS -- Consistent Overhead Byte Stuffing.
 *
 *	See:
 *		http://conferences.sigcomm.org/sigcomm/1997/papers/p062.pdf
 *
 *	I stashed a copy of the paper as "cobs.pdf" in the library source directory.
 *
 *	This module consists of an encoder and a byte-by-byte decoder.
*/

/*
 *	cobs_encode (uint8_t *ptr)
 *
 *	The encoder encodes the buffer ptr, in place.
 *	Data of size N (N <= 253) is stored at ptr [1...N], and ptr [0] = N.
 *	The following code encodes the four byte sequence { 0xff, 0x23, 0x00, 0x01 }:
 *
 *		uint8_t array [] = { 0x00, 0xff, 0x23, 0x00, 0x01 };
 *		array [0] = sizeof (array) - 1;
 *		cobs_encode (array);
 *
 *	The encoding function transforms the array to:
 *
 *		0x03, 0xff, 0x23, 0x02, 0x01
 *
 *	This can be interpreted as:
 *
 *		[0] 0x03 - the next 0 valued byte is 3 bytes from the current position (so at array [3])
 *		[1] 0xff - data byte
 *		[2] 0x23 - data byte
 *		[3] 0x02 - data byte, converted to a zero byte; the next 0 valued byte is 2 bytes from the current position (so at array [5])
 *		[4] 0x01 - data byte
 *
 *	Note that the 0x02 at array [3] implied a zero byte past the end of the array (array [5] is not valid).
 *	That means that encoding is complete.
 *
 *	We're intending that the COBS encoding will be used with NUL terminated transports, so the on-wire data is actually:
 *
 *		0x03 0xff 0x23 0x02 0x01 0x00
 *
 *	Notice how the final zero is at the [5] position, even though it's not stored in the array.
*/

void
cobs_encode (uint8_t *in)
{
	int size = *in;
	uint8_t *code_ptr = in++;							// we arranged to start our data at in [1], not in [0]
	uint8_t code = 0x01;

	while (size--) {
		if (*in == 0) {
			*code_ptr = code;
			code_ptr = in;
			code = 0;
		}
		code++;
		in++;
	}
	*code_ptr = code;
}

/*
 *	uint8_t *cobs_decode (uint8_t byte)
 *
 *	This is a decoder for COBS that accumulates packets and returns a non-NULL
 *	pointer once a complete packet has been decoded.
 *
 *	The packet is allocated from a static memory location.
 *
 *	Just like the cobs_encode() function, the first element of the stream is
 *	the length, and data follows at offset 1.
 *	The streaming decoder operates as a state machine, with the following
 *	states:
 *
 *		START
 *			This is the initial state; the decoder is waiting for the "code"
 *			character (indicating the count of additional characters expected).
 *			If there are characters already in the buffer, then a zero is
 *			added to the buffer contents. If the character received is not a
 *			code character (that is, it is the NUL framing character), then
 *			the buffer is returned to the caller. Otherwise, the state changes
 *			to CAPTURE.
 *
 *		CAPTURE
 *			In this state, the decoder accumulates one character less than the
 *			number given by the code character. When all characters have been
 *			captured, we transit back to the START state.
 *
 *		SKIP
 *			In this state, we're waiting for the next NUL character so that we
 *			can resynchronize.
*/

enum cobs_rx_states {
	S_START,											// initial state; what we are about to receive is a code telling us how many bytes follow
	S_CAPTURE,											// in this state, we're receiving those bytes
	S_SKIP												// something bad happened, and we're skipping until the next NUL in order to resynchronize
};

uint8_t *
cobs_decode (uint8_t ch)
{
	static uint8_t buffer [256];						// single packet COBS packing implies less than 256 bytes
	static int index = 0;								// where we can write next character (note that buffer [0] contains the size)
	static enum cobs_rx_states state = S_START;			// state we are in
	static uint8_t nleft;								// number of bytes expected

	switch (state) {
	case	S_CAPTURE:									// we're copying "nleft" bytes
//printf ("CA%02XNL%02X ", ch, nleft); fflush (stdout);
		if (nleft > 0) {
			if (!ch) {									// we're not expecting a nul, so something bad must have happened
				index = 0;								// restart the stream processing
				state = S_START;
				return (NULL);							// nothing to see, move along
			}
			buffer [index++] = ch;						// copy the character
			nleft--;
			break;
		}
		state = S_START;
		// fall through

	case	S_START:									// we are waiting for a code or NUL
//printf ("ST%02XIN%02X ", ch, index); fflush (stdout);
		if (!ch) {										// end of packet
			if (!index) return NULL;					// ignore empty frames
			buffer [0] = index - 1;
			index = 0;
			return (buffer);
		}
		if (index) {									// if there are already characters in the buffer...
			buffer [index] = 0;							// ... then add the implied zero to the buffer
		}
		index++;
		nleft = ch - 1;									// and indicate how many characters we are expecting
		state = S_CAPTURE;
		break;

	case	S_SKIP:										// if we're waiting for the next NUL
//printf ("SK%02X ", ch); fflush (stdout);
		if (!ch) {										// and we found it
			index = 0;
			state = S_START;							// then proceed to state START on the next character
		}
		return (NULL);
	}

	if (index >= sizeof (buffer)) {						// if the next character that we write would overflow, then we've gotten too far
//printf ("OV "); fflush (stdout);
		state = S_SKIP;									// so wait it out
	}

	return (NULL);
}

#ifdef	SELFTEST										// this is enabled automatically in the Makefile

int
main (int argc, char **argv)
{
//	uint8_t array [] = { 0x00, 0xff, 0x23, 0x00, 0x01 };
//	uint8_t array [] = { 0x00, 'P', 'R', 'E', 'S' };
//	array [0] = sizeof (array) - 1;						// in general, we automatically compute the size of the array as the first element
	uint8_t array [] = { 3, 'O', 'K', 0, 0x00 };		// in this test case, we want a particular size, because we've made room for the framing terminator

	printf ("Input is   ");
	for (int i = 0; i < sizeof (array); i++) {
		printf ("%02X ", array [i]);
	}
	printf ("\n");

	cobs_encode (array);

	printf ("Output is  ");
	for (int i = 0; i < sizeof (array); i++) {
		printf ("%02X ", array [i]);
	}
	printf ("\n");

	printf ("Decoding %ld bytes...\n", sizeof (array));

	for (int i = 0; i <= sizeof (array); i++) {
		uint8_t value = i == sizeof (array) ? 0 : array [i];
		printf ("[%d] = %02X ", i + 1, value);
		uint8_t *result = cobs_decode (value);
		if (result) {
			printf ("DECODED %d bytes!\n", result [0]);
			printf ("Decoded is ");
			for (int j = 0; j <= result [0]; j++) {
				printf ("%02X ", result [j]);
			}
			printf ("\n");
			break;
		} else {
			printf ("incomplete\n");
		}
	}
}

#endif	// SELFTEST

