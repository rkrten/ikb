
/*
 *	cobs.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 12 05	R. Krten		created
*/

#ifndef	_cobs_h_
#define	_cobs_h_

#include <stdint.h>

void cobs_encode (uint8_t *in);
uint8_t *cobs_decode (uint8_t ch);

#endif	/* _cobs_h_ */

