
2025 06 29
Corrections from 50A:
	- changed "48 element" to "32 element"
	- changed component side copper text to "-C" instead of "-S"
	- added ground via to fill top of component side
