
/*
 *	utils.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 27	R. Krten		created
*/

#include "main.h"

/*
 *	digits_with_comma (dest, len, value, leader)
 *
 *	Prints a right-justified string representation of value into dest.
 *	Output will not overflow len bytes.
 *	No nul terminator is provided, so as not to clobber existing data past the numerical area.
 *	At least leader digits will be printed, with leading zeros if required.
 *
 *	Examples:
 *
 *	len		value		leader		output (no nul terminator)
 *									012345678911234567892
 *	-------	-----------	-----------	-------------------------
 *	1		1			0			1
 *	16		123			0			             123
 *	16		123			6			         000,123
 *	16		123			7			       0,000,123
 *	4		123456		8			,456						Pathological case; output area is too small
*/

const char *
digits_with_comma (char *dest, size_t len, uint32_t value, int leader)
{
	memset (dest, ' ', len);

	enum { Printing, Comma, Done } state = Printing;

	int pos = 0;
	while (len-- && state != Done) {
		switch (state) {
		case	Printing:
			dest [len] = value % 10 + '0';
			pos++;
			value /= 10;

			if (value || pos < leader) {
				if (pos % 3 == 0) {
					state = Comma;
				}
			} else {
				state = Done;
			}
			break;

		case	Comma:
			dest [len] = ',';
			state = Printing;
			break;

		}
	}
	return dest;
}

#ifdef	SELF_TEST
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int
main (int argc, char **argv)
{
	int value = atoi (argv [1]);
	int	len = atoi (argv [2]);
	int leader = atoi (argv [3]);

	char buf [64];

	memset (buf, '.', sizeof (buf));
	buf [63] = 0;

	printf ("[%s]\n", digits_with_comma (buf, len, value, leader));
}
#endif
