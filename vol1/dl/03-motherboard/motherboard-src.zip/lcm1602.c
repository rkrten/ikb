
/*
 *	lcm1602.c
 *
 *	(C) Copyright 2014 by Robert Krten, all rights reserved.
 *
 *	This is the driver for the LCM-1602 based 4x20 LCD display.
 *	Note that the LCM-1602 has a parallel interface; this driver
 *	interfaces to it using the PFC8574 I2C I/O expander, so there are two
 *	sets of protocols herein -- one to talk to the '8574, and another to talk
 *	through that to the '1602.
 *
 *	2014 12 01	R. Krten		created
 *	2025 10 16	R. Krten		ported to PICO/JBUSW driver infra, removed delays
 *	2025 10 21	R. Krten		IB lives on! wti/wwl solution for slow hardware
*/

#include "main.h"
#include <string.h>

#define	PCF8574_I2C_ADDRESS		0x27

typedef struct
{
	int column;
	int extent;
} flash_t;

typedef struct
{
	bool		backlight;
	bool		enabled;
	bool		cursor;
	bool		blink;
	int			cursor_row, cursor_column;
	char		content [NROWS][NCOLUMNS + 1];			// we store nul-terminated strings
	flash_t		flash [NROWS];
	bool		dirty [NROWS];							// in the WWL, does this row need to be refresed?
} lcm1602_t;

static lcm1602_t wti;									// what there is -- the hardware is actually set to these values
static lcm1602_t wwl;									// what we'd like -- when the poller gets around to it, this should be spilled to the hardware
static i2c_inst_t *i2c;									// global I2C controller that we're using

static void lcm1602_set_cursor_hw (int row, int column);
static void lcm1602_cursor_visible_hw (bool visible);
static void lcm1602_cursor_blink_hw (bool blink);

static void
cmd1 (uint8_t cmd)
{
	if (i2c_write_blocking_until (i2c, PCF8574_I2C_ADDRESS, &cmd, sizeof (cmd), false, make_timeout_time_us (10000)) != sizeof (cmd)) {
		printf ("Failed writing command 0x%02X\n", cmd);
	}
}

// See: http://forum.arduino.cc/index.php?topic=158312.0
// and: https://dawes.wordpress.com/2010/01/05/hd44780-instruction-set/
#define	RS(_b)					((_b) << 0)				// register select (0 == instruction, 1 == data)
#define	RW(_b)					((_b) << 1)				// read / write (0 == write, 1 == read)
#define	EN(_b)					((_b) << 2)				// starts data read/write
#define	BL(_b)					((_b) << 3)				// pin 3 (backlight)

static void
cmd_4bit (uint8_t val4)
{
	cmd1 (EN(0) | RS(0) | RW(0) | BL(wti.backlight) | (val4 << 4));
	cmd1 (EN(1) | RS(0) | RW(0) | BL(wti.backlight) | (val4 << 4));
}

static void
cmd_8bit (uint8_t val8)
{
	cmd1 (EN(0) | RS(0) | RW(0) | BL(wti.backlight) | (val8 & 0xf0));
	cmd1 (EN(1) | RS(0) | RW(0) | BL(wti.backlight) | (val8 & 0xf0));
	cmd1 (EN(0) | RS(0) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
	cmd1 (EN(1) | RS(0) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
	cmd1 (EN(0) | RS(0) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
}

static void
data_8bit (uint8_t val8)
{
	cmd1 (EN(0) | RS(1) | RW(0) | BL(wti.backlight) | (val8 & 0xf0));
	cmd1 (EN(1) | RS(1) | RW(0) | BL(wti.backlight) | (val8 & 0xf0));
	cmd1 (EN(0) | RS(1) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
	cmd1 (EN(1) | RS(1) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
	cmd1 (EN(0) | RS(1) | RW(0) | BL(wti.backlight) | ((val8 & 0x0f) << 4));
}

static void lcm1602_write_line_hw (int, const char *);

void
init_lcm1602 (void)
{
	memset (&wti, 0, sizeof (wti));
	wti.cursor_row = wti.cursor_column = -1;	// not visible

	i2c = i2c0;

	i2c_init (i2c, 40 * 1000);
	gpio_set_function (LCM1602_SDA, GPIO_FUNC_I2C);
	gpio_set_function (LCM1602_SCL, GPIO_FUNC_I2C);

	cmd_4bit (3);
	sleep_us (4200);									// > 4.1ms is what the spec says
	cmd_4bit (3);
	sleep_us (110);										// > 100us is what the spec says

	cmd_8bit (0x32);									// 001D-NFxx = 0011 0010 D==1 (8 bits), N==0 (1 line), F==0 (5x8 dots)
	cmd_8bit (0x28);									// 001D-NFxx = 0010 1000 D==0 (4 bits), N==1 (2 lines), F==0 (5x8 dots)
	cmd_8bit (0x0c);									// 0000-1DCB = 0000 1100 D==1 (display on), C==0 (cursor off), B==0 (blink off)
	cmd_8bit (0x06);									// 0000-01IS = 0000 0110 I==1 (increment), S==0 (no scroll)
	cmd_8bit (0x01);									// 0000-0001 clear display

//#define	TEST_PATTERN
#ifdef	TEST_PATTERN
	lcm1602_backlight (true);
	lcm1602_display_enabled (true);
	for (;;) {
		for (int offset = 0; offset < 256 - 80; offset += 80) {
			for (int r = 0; r < 4; r++) {
				char line [21];
				line [20] = 0;
				for (int c = 0; c < 20; c++) {
					if (r == 0 && (c < 3)) {
						sprintf (line, "%03d", offset);
					} else {
						line [c] = r * 20 + c + offset;
					}
				}
				lcm1602_write_line_hw (r, line);
			}
			sleep_ms (5000);
		}
	}
#endif	// TEST_PATTERN
}

void
lcm1602_write_line (int line, const char *str)
{
	line %= NROWS;

	wwl.content [line][NCOLUMNS] = 0;					// ensure string is nul terminated

	bool fill = false;									// correct for blanks after a nul
	for (int c = 0; c < NCOLUMNS; c++) {
		if (fill) {
			wwl.content [line][c] = ' ';
		} else {
			if (*str) {
				wwl.content [line][c] = *str;
			} else {
				wwl.content [line][c] = ' ';
				fill = true;
			}
		}
		str++;
	}
}

void
lcm1602_write_line_at (int line, int column, const char *str)
{
	line %= NROWS;

	while (column < NCOLUMNS && *str) {
		wwl.content [line][column++] = *str++;
	}
}

static void
before_write (void)
{
	// temporarily turn off cursor while we write the data
	if (wti.cursor) {
		lcm1602_cursor_visible_hw (false);
	}

	if (wti.blink) {
		lcm1602_cursor_blink_hw (false);
	}
}

static void
after_write (void)
{
	// restore cursor if it's supposed to be on
	if (wwl.cursor || wwl.blink) {
		lcm1602_set_cursor_hw (wwl.cursor_row, wwl.cursor_column);
		if (wwl.cursor) {
			lcm1602_cursor_visible_hw (wwl.cursor);
		}
		if (wwl.blink) {
			lcm1602_cursor_blink_hw (wwl.blink);
		}
	}
}

static uint8_t regaddr [4] = { 0x80, 0xc0, 0x94, 0xd4 };

static void
lcm1602_write_line_hw (int line, const char *str)
{
	before_write ();

	line &= 3;											// there are only four lines
	cmd_8bit (regaddr [line]);
	int nwritten = 0;
	while (*str) {
		wti.content [line][nwritten] = *str;
		data_8bit ((uint8_t) *str);
		str++;
		nwritten++;
	}

	for (; nwritten < 20; nwritten++) {
		data_8bit (' ');								// don't store this in the wti
	}

	after_write ();
}

static void
lcm1602_flash_hw (int row, bool sense)
{
	before_write ();

	cmd_8bit (regaddr [row] + wwl.flash [row].column);
	for (int i = 0; i < wwl.flash [row].extent; i++) {
		if (sense) {
			data_8bit (' ');
		} else {
			data_8bit ((uint8_t) wwl.content [row][wwl.flash [row].column + i]);
		}
	}

	after_write ();
}

static void
lcm1602_write_DCB_hw (void)
{
	uint8_t dcb = 0x08;
	dcb |= wti.enabled * 0x04;
	dcb |= wti.cursor * 0x02;
	dcb |= wti.blink * 0x01;
	cmd_8bit (dcb);
}

static void
lcm1602_cursor_blink_hw (bool blink)
{
	wti.blink = blink;
	lcm1602_write_DCB_hw ();
}

void
lcm1602_cursor_blink (bool blink)
{
	wwl.blink = blink;
}

static void
lcm1602_cursor_visible_hw (bool visible)
{
	wti.cursor = visible;
	lcm1602_write_DCB_hw ();
}

void
lcm1602_cursor_visible (bool visible)
{
	wwl.cursor = visible;
}

void
lcm1602_display_enabled (bool enabled)
{
	wti.enabled = enabled;
}

void
lcm1602_backlight (bool enabled)
{
	wti.backlight = enabled;
}

static void
lcm1602_set_cursor_hw (int row, int column)
{
	wti.cursor_row = row;
	wti.cursor_column = column;
	cmd_8bit (regaddr [row & 3] + (column % 20));
}

void
lcm1602_set_cursor (int row, int column)
{
	wwl.cursor_row = row;
	wwl.cursor_column = column;
}

void
lcm1602_flash (int row, int column, int n)
{
	wwl.flash [row].column = column;
	wwl.flash [row].extent = n;
	wwl.dirty [row] = true;
}

// called insanely fast from the foreground main() loop
#define	FLASH_TIME	(100 * KILO)

void
lcm1602_drive (void)
{
	static uint64_t last = 0;
	static uint64_t last_flash = 0;
	static int flash_duty_rotor = 0;
	static bool flash_value = false;

	if (now - last < 500) return;						// do not poll hardware faster than this rate
	last = now;

	bool flash_change = false;
	if (now - last_flash > FLASH_TIME) {
		flash_duty_rotor = (flash_duty_rotor + 1) % 10;
		if (flash_duty_rotor > 7) {
			if (!flash_value) {
				flash_value = true;
				flash_change = true;
			}
		} else {
			if (flash_value) {
				flash_value = false;
				flash_change = true;
			}
		}
		last_flash = now;
	}

	for (int i = 0; i < 4; i++) {
		if (wwl.dirty [i] || memcmp (wti.content [i], wwl.content [i], sizeof (wti.content [i]))) {
//printf ("[%s] != [%s]\n", wti.content [i], wwl.content [i]);
			lcm1602_write_line_hw (i, wwl.content [i]);
			wwl.dirty [i] = false;
		}
	}

	if (flash_change) {
		for (int i = 0; i < 4; i++) {
			if (wwl.flash [i].extent) {
				lcm1602_flash_hw (i, flash_value);
			}
		}
	}

	if (wwl.cursor_row != wti.cursor_row || wwl.cursor_column != wti.cursor_column) {
		lcm1602_set_cursor_hw (wwl.cursor_row, wwl.cursor_column);
	}

	if (wwl.blink != wti.blink) {
		lcm1602_cursor_blink_hw (wwl.blink);
	}

	if (wwl.cursor != wti.cursor) {
		lcm1602_cursor_visible_hw (wwl.cursor);
	}
}

