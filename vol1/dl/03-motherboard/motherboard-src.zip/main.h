
/*
 *	main.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 09	R. Krten		created
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "pico/multicore.h"

#include "encoder.h"
#include "fgen.h"
#include "fcount.h"
#include "lcm1602.h"
#include "utils.h"

#define	KILO			1000
#define	MEGA			(KILO * KILO)
#define	GIGA			(MEGA * KILO)
#define	NELEMENTS(_x)	(sizeof ((_x)) / sizeof ((_x) [0]))
#define CP { printf ("[%s:%d]\n", __FILE__, __LINE__); }

#define	ENCODER_SWITCH_SENSE	 0
#define	ENCODER_PHASE1_SENSE	 1
#define	ENCODER_PHASE2_SENSE	 2
#define	ENCODER_ADDR0			16
#define	ENCODER_ADDR1			17
#define	ENCODER_ADDR2			18
#define	ENCODER_ADDR3			 3

#define	LCM1602_SDA				 8						// also used for 24C256 NVRAM
#define	LCM1602_SCL				13						// also used for 24C256 NVRAM
#define	FGEN1_GPIO				15
#define	FGEN2_GPIO				14
#define	FGEN3_GPIO				19
#define	ROP_DATA_GPIO			20
#define	ROP_CLOCK_GPIO			21
#define	SAMPLE1_GPIO			22
#define	SAMPLE2_GPIO			10
#define	SAMPLE3_GPIO			 9

// @@@ new with IKCH56BA board manufactured 2025-12-28
#define	IKCH55_RX				 4						// these are on UART1
#define	IKCH55_TX				 5						// "
#define	IKCH50_OE				 6
#define	IKCH50_CLOCK			 7
#define	VFD_SERIAL				12						// this is on UART0
#define	IKCH50_DIN_0			11


extern uint64_t now;									// main.c, current us time snapshot at top of polling loop
extern uint32_t system_clock;							// main.c, system clock speed in Hz
extern uint32_t system_period;							// main.c, system clock period in ns

/*
 *	GPIO Map
 *
 *	Pin		GPIO	UART	I2C		SPI		ADC			Function
 *	---		----	----	-----	------	------		------------------------------------------
 *	 1		 0											Encoder switch sense (RJ-45 pin 3)
 *	 2		 1											Encoder phase 1 sense (RJ-45 pin 1)
 *	 4		 2											Encoder phase 2 sense (RJ-45 pin 2)
 *	 5		 3											Encoder address bit D (extra pin on encoder board)
 *	 6		 4		TX 1								IKCH55_RX
 *	 7		 5		RX 1								IKCH55_TX
 *	 9		 6											IKCH50_OE
 *	10		 7											IKCH50_CLOCK
 *	11		 8				SDA 0						I2C data for LCM-1602 and NVRAM
 *	12		 9											Frequency sample 3 input
 *	14		 10											Frequency sample 2 input
 *	15		 11											IKCH50_DIN_0
 *	16		 12		TX 0								TTL Serial for VFD
 *	17		 13				SCL 0						I2C clock for LCM-1602 and NVRAM
 *	19		 14											Frequency generator 2 output
 *	20		 15											Frequency generator 1 output
 *	21		 16											Encoder address bit A (RJ-45 pin 4)
 *	22		 17											Encoder address bit B (RJ-45 pin 5)
 *	24		 18											Encoder address bit C (RJ-45 pin 6)
 *	25		 19											Frequency generator 3 output
 *	26		 20											ROP Data
 *	27		 21											ROP Clock
 *	29		 22											Frequency sample 1 input
 *	31		 26				SDA 1			ADC 0		** AVAILABLE **
 *	32		 27				SCL 1			ADC 1		** AVAILABLE **
 *	34		 28								ADC 2		** AVAILABLE **
*/

