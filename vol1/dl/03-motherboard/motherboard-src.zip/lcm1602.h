
/*
 *	lcm1602.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 09	R. Krten		created
*/

#define	NCOLUMNS				20						// hardware
#define	NROWS					4

void init_lcm1602 (void);
void lcm1602_write_line (int line, const char *str);
void lcm1602_write_line_at (int line, int column, const char *str);
void lcm1602_cursor_blink (bool blink);
void lcm1602_cursor_visible (bool visible);
void lcm1602_display_enabled (bool enabled);
void lcm1602_set_cursor (int row, int column);
void lcm1602_backlight (bool enabled);
void lcm1602_drive (void);
void lcm1602_flash (int row, int column, int n);

