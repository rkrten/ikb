
/*
 *	fgen.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	Frequency Generator.
 *
 *	2025 10 12	R. Krten		created
*/

#include "main.h"
#include "gen.pio.h"
#include <float.h>
#include <math.h>
#include <string.h>

#define	NGENERATORS	3

typedef enum Modes
{
	Decimal,											// specify frequency as a decimal number, e.g., 2600 Hz
	Period,												// specify cycle based on period (e.g., 1.7 seconds)
//	Musical,											// specify frequency as a musical node, e.g., A4 to produce 440 Hz
	ROP,												// adjust signal generator ROP program
	// DTMF: {697, 770, 852, 941} x {1209, 1336, 1477, 1633} => {1, 2, 3, A, 4, 5, 6, B, 7, 8, 9, C, *, 0, #, D}
	// Precise Tone Plan: Dial 350+440, Busy 480+620, Ring 480+620
	// R1/MF: KP 1100/1700, ST 1100/1500, 1 700/900, 2 700/1100, 3 900/1300, 4 700/1300, 5 900/1100, 6 1100/1300, 7 700/1500, 8 900/1500, 9 1300/1500, 0 1300/1100, STP 1300/1700, ST2P 1500/1700
	NMODES												// number of values in this enum
} Mode;

static inline const char *
ModeName (Mode m)
{
	switch (m) {
	case	Decimal:	return "Decimal";
	case	Period:		return "Period";
	case	ROP:		return "ROP";
	}
	return "<unknown>";
}

typedef enum
{
	Startup,											// generator is being transitioned into -- perform any one-off startups
	Operating,											// generator normal operating mode
	Shutdown											// generator is being exited -- perform any one-off shutdowns
} Phase;

static inline const char *
PhaseName (Phase p)
{
	switch (p) {
	case	Startup:	return "Startup";
	case	Operating:	return "Operating";
	case	Shutdown:	return "Shutdown";
	}

	return "<unknown>";
}

typedef enum
{
	FreeRunning,										// generator is running
	SyncWait,											// generator is primed for synchronization
	SyncReleaseWait,									// generator is waiting for release of all generators so that it can sync up
} Sync;

static inline const char *
SyncName (Sync s)
{
	switch (s) {
	case	FreeRunning:		return "FreeRunning";
	case	SyncWait:			return "SyncWait";
	case	SyncReleaseWait:	return "SyncReleaseWait";
	}

	return "<unknown>";
}

typedef struct
{
	uint32_t	mmantissa;								// milli-mantissa -- the significant digits
	int			ee;										// engineering exponent multiplier from base units, 10^(3*<value>)
	int			cursor;									// UI digit cursor
}	decimal_t;

typedef struct
{
	uint32_t	mmantissa;								// milli-mantissa -- the significant digits
	int			ee;										// engineering exponent multiplier from base units, 10^(3*<value>)
	int			cursor;									// UI digit cursor
}	period_t;

typedef struct
{
	uint8_t		rop;
	int			value_rop_curated;						// index into curated ROPs
	int			cursor;									// UI digit cursor
}	rop_t;

typedef struct
{
	// these are the values as maintained by each generator
	decimal_t	decimal;								// decimal context
	period_t	period;									// period context
	rop_t		rop;
	uint32_t	value_musical;							// note number

	// these are common to all generators
	uint8_t		duty;									// 0..100 inclusive
	Mode		mode;
	int			gpio;									// output pin
	Sync		sync;									// synchronization state
	uint32_t	hw_low, hw_high;						// values sent to hardware; can reset to 0, 0 if you need to reload
} Generator;

static Generator generators [NGENERATORS];
static int exponents [] = { 1, 10, 100, KILO, 10 * KILO, 100 * KILO, MEGA, 10 * MEGA, 100 * MEGA, GIGA };

static void frequency_display (Generator *g, Phase ph);

static uint32_t
convert_frequency_to_cycles (float frequency)
{
	return system_clock / frequency;
}

static uint32_t
convert_period_ns_to_cycles (uint32_t period)
{
	return period / system_period;
}

static void
frequency_sm_set (Generator *g)
{
	float cycles = 0.0;

	if (g -> mode == Period) {
		// convert milli-mantissa x 10^(3*ee) to a number of on and off system clock cycles
		period_t *p = &g -> period;
		switch (p -> ee) {
		case	-2:										// microseconds:	millimantissa represents 0.000 us through 9,999.999 us; the value 1 represents 1 nanosecond
			cycles = convert_period_ns_to_cycles (p -> mmantissa);
			break;

		case	-1:										// milliseconds:	millimantissa represents 0.000 ms through 9,999.999 ms; the value 1 represents 1 microsecond
			cycles = convert_period_ns_to_cycles (p -> mmantissa * KILO);
			break;

		case	 0:										// seconds:			millimantissa represents 0.000  s through 9,999.999  s; the value 1 represents 1 millisecond
			cycles = convert_period_ns_to_cycles (p -> mmantissa * MEGA);
			break;

		case	 1:										// kiloseconds:		millimantissa represents 0.000 ks through 9,999.999 ks; the value 1 represents 1 second
			cycles = convert_period_ns_to_cycles (p -> mmantissa * GIGA);
			break;

		default:
			printf ("Invalid period EE multiplier %d, expected -2 .. +1 range\n", p -> ee);
			break;
		}

	} else if (g -> mode == Decimal) {
		decimal_t *d = &g -> decimal;
		switch (d -> ee) {
		case	0:										// Hertz:			millimantissa represents 0.000  Hz through 9,999.999  Hz; the value 1 represents 1 mHz
			cycles = convert_frequency_to_cycles ((float) d -> mmantissa / KILO);
			break;

		case	1:										// kilo Hertz:		millimantissa represents 0.000 kHz through 9,999.999 kHz; the value 1 represents 1 Hz
			cycles = convert_frequency_to_cycles (d -> mmantissa);
			break;

		case	2:										// mega Hertz:		millimantissa represents 0.000 MHz through 9,999.999 MHz; the value 1 represents 1 kHz
			cycles = convert_frequency_to_cycles (d -> mmantissa * KILO);
			break;

		case	3:										// giga Hertz:		millimantissa represents 0.000 GHz through 9,999.999 GHz; the value 1 represents 1 MHz
			cycles = convert_frequency_to_cycles (d -> mmantissa * MEGA);
			break;

		default:
			printf ("Invalid decimal EE multiplier %d, expected -2 .. +1 range\n", d -> ee);
			break;
		}

	}

	if (!cycles) {
		return;
	}

	uint32_t lo = cycles * (float) g -> duty / 100.;
	uint32_t hi = cycles * (1. - (float) g -> duty / 100.);
	if (g -> hw_low != lo || g-> hw_high != hi) {
		setup_dual_pio_pwm_channel (g - generators, g -> gpio, g -> hw_low = lo, g -> hw_high = hi);
	}
}

static void
frequency_sm_stop (Generator *g)
{
	frequency_sm_disable_channel (g - generators);
	g -> hw_low = g -> hw_high = 0;
}

/*
 *	=====
 *	MODES
 *	=====
 *
 *	For each mode, there's a "display" and an "event" handler.
 *
 *	The display handler is responsible for showing the mode's values on the first or second line, depending
 *	on the generator number.
 *
 *	The event handler is responsible for handling the rotary encoder events and updating the generators[]
 *	context structure. The event handlers should call into the generic frequency_display() function (instead of
 *	the mode specific one, e.g., frequency_display_musical()) so that common processing can occur. The generic
 *	function dispatches to the specific function.
*/

typedef enum { Left, Middle, Right } Unit;

static bool
common_duty (Generator *g, Unit u, Encoder *e)
{
	if (u != Right) {
		return false;
	}

	// within the duty cycle, we can select 0..100 inclusive
	if (e -> knob == RE_CW) {
		if (g -> duty < 100) {
			++g -> duty;
			return true;
		}
	} else if (e -> knob == RE_CCW) {
		if (g -> duty > 0) {
			--g -> duty;
			return true;
		}
	}

	return false;
}

static bool
common_sync (Generator *g, Unit u, Encoder *e)
{
	if (u != Right) {
		return false;
	}

	switch (e -> button) {
	case	PB_Hold:
		g -> sync = SyncWait;
		frequency_display (g, Operating);
		break;

	case	PB_Release:
		if (g -> sync == SyncWait) {
			g -> sync = SyncReleaseWait;
			bool ready = true;

			// re-use "g" as general purpose iterator hereafter
			for (g = generators; g < generators + NGENERATORS; g++) {
				if (g -> sync == SyncWait) {
					ready = false;
					break;
				}
			}

			// if no generators are waiting for release, then this is the final release; synchronize (but only the ones that opted in)
			if (!ready) break;
			for (g = generators; g < generators + NGENERATORS; g++) {
				if (g -> mode != Decimal && g -> mode != Period) continue;
				if (g -> sync != SyncReleaseWait) continue;
				g -> sync = FreeRunning;
				g -> hw_low = g -> hw_high = 0;	// force reload
				frequency_display (g, Operating);
			}
		}
		break;
	}

	return true;
}

/*
 *	DECIMAL
*/

static void
frequency_display_decimal (Generator *g, Phase ph)
{
	switch (ph) {
	case	Startup:
		gpio_set_function (g -> gpio, GPIO_FUNC_PIO1);
		break;

	case	Shutdown:
//		frequency_sm_stop (g);
		return;											// nothing further to do
	}

	/*
	 *	We display the following:
	 *
	 *	01234567891123456789
	 *	F xxx%     0.001  Hz	ee == 0, 1 pulse every kilosecond
	 *	F xxx% 9,999.999 kHz	ee == 1
	 *	F xxx%   125.000 MHz	ee == 2, absolute maximum hardware rate
	 *	  \_/  \_______/ \_/
	 *     |       |      +---	ee member
	 *	   |       +----------	milli-mantissa member
	 *	   +------------------	duty (or "SYNC" if synchronizing)
	*/

	// where am I?     01234567891123456789
	char line [21] = {"F xxx% 9,999.999 xHz"};			// prototype initialization;
	static int cursor_locations [] = { 4, 7, 9, 10, 11, 13, 14, 15, 19 };	// indicies into the above string
	// what am I?					  |d| |------mmantissa-------| |ee|
	// which one am I?				   0  1  2   3   4   5   6   7   8
	#define DecimalLastCursor										 8		// highest possible cursor value

	decimal_t *d = &g -> decimal;

	if (g -> sync == FreeRunning) {
		digits_with_comma (line + 2, 3, g -> duty, 1);
	} else {
		memcpy (line + 2, "SYNC", 4);
	}

	// cursor is within mmantissa
	int ndigits = 0;									// digits to show, above and beyond what is implied by the value itself
	if (d -> cursor >= 1 && d -> cursor < DecimalLastCursor) {
		ndigits = 8 - d -> cursor;
	}
	if (ndigits < 4) ndigits = 4;						// 4 digits minimum because we have milli-mantissa, 0.xxx
	digits_with_comma (line + 7, 9, d -> mmantissa, ndigits);
	if (line [12] == ',') line [12] = '.';				// correct comma to decimal in this case

	switch (d -> ee) {
	case	0: line [17] = ' '; break;
	case	1: line [17] = 'k'; break;
	case	2: line [17] = 'M'; break;
	}

	int ch = g - generators;
	lcm1602_write_line (ch, line);
	lcm1602_flash (ch, cursor_locations [d -> cursor], 1);

	frequency_sm_set (g);
}

#define	MAXIMUM_FREQUENCY	(2 * MEGA)					// this seems to be the usable range

static void
frequency_event_decimal (Generator *g, Unit u, Encoder *e)
{
	decimal_t *d = &g -> decimal;
	bool refresh = false;

	// MIDDLE moves cursor between fields and field members
	if (u == Middle) {
		if (e -> knob == RE_CCW) {
			if (--d -> cursor < 0) {
				d -> cursor = DecimalLastCursor;
			}
			refresh = true;
		} else if (e -> knob == RE_CW) {
			if (++d -> cursor > DecimalLastCursor) {
				d -> cursor = 0;
			}
			refresh = true;
		}
	}

	/*
	 *	RIGHT
	 *	- encode knob selects value, and depends on which field we're in
	 *	- pushbutton allows synchronization
	*/

	if (u == Right) {
		if (e -> button == PB_Hold || e -> button == PB_Release) {
			common_sync (g, u, e);
		}

		if (d -> cursor == 0) {
			// use the common duty UI to select 0..100 inclusive
			if (common_duty (g, u, e)) {
				refresh = true;
			}

		} else if (d -> cursor < DecimalLastCursor) {
			// within the frequency millimantissa, we can select 0 -> 9,999,999 inclusive, except in the MHz scale in which case the maximum is MAXIMUM_FREQUENCY
			// @@@ right now, we can exceed 9,999,999 -- it does indeed bump the frequency, but the display drops the leading 10 million's digit.
			if (e -> knob == RE_CW) {
				int newm = d -> mmantissa + exponents [7 - d -> cursor];
				int f = (float) newm / KILO * exponents [3 * d -> ee];
				if (f <= MAXIMUM_FREQUENCY) {
					d -> mmantissa = newm;
					refresh = true;
				}
			} else if (e -> knob == RE_CCW) {
				int newm = d -> mmantissa - exponents [7 - d -> cursor];
				if (newm > 0) {
					d -> mmantissa = newm;
					refresh = true;
				}
			}

		} else {
			// within the exponent selection
			if (e -> knob == RE_CW) {
				d -> ee = (d -> ee + 1) % 3;
				refresh = true;
			} else if (e -> knob == RE_CCW) {
				if (d -> ee) {
					--d -> ee;
				} else {
					d -> ee = 2;
				}
				refresh = true;
			}
		}
	}

	if (refresh) {
		frequency_display (g, Operating);
	}
}

/*
 *	PERIOD
*/

void
frequency_display_period (Generator *g, Phase ph)
{
	switch (ph) {
	case	Startup:
		gpio_set_function (g -> gpio, GPIO_FUNC_PIO1);
		break;

	case	Shutdown:
//		frequency_sm_stop (g);
		return;											// nothing further to do
	}

	/*
	 *	We display the following:
	 *
	 *	01234567891123456789
	 *	P xxx% 9,999.999   s	ee ==  0, 1 pulse every {10ks .. 1ms}
	 *	P xxx% 9,999.999  ms	ee == -1
	 *	P xxx%     0.008  us	ee == -2, absolute maximum for hardware at normal (125MHz) clock rate
	 *	  \_/  \_______/  \/
	 *     |       |       +--	ee member
	 *	   |       +----------	milli-mantissa member
	 *	   +------------------	duty (or "SYNC" if synchronizing)
	*/

	// where am I?     01234567891123456789
	char line [21] = {"P xxx% 9,999.999  xs"};			// prototype initialization;
	static int cursor_locations [] = { 4, 7, 9, 10, 11, 13, 14, 15, 18 };	// indicies into the above string
	// what am I?					  |d| |------mmantissa-------| |ee|
	// which one am I?				   0  1  2   3   4   5   6   7   8
	#define PeriodLastCursor										 8		// highest possible cursor value

	period_t *p = &g -> period;

	if (g -> sync == FreeRunning) {
		digits_with_comma (line + 2, 3, g -> duty, 1);
	} else {
		memcpy (line + 2, "SYNC", 4);
	}

	// cursor is within mmantissa
	int ndigits = 0;									// digits to show, above and beyond what is implied by the value itself
	if (p -> cursor >= 1 && p -> cursor < PeriodLastCursor) {
		ndigits = 8 - p -> cursor;
	}
	if (ndigits < 4) ndigits = 4;						// 4 digits minimum because we have milli-mantissa, 0.xxx
	digits_with_comma (line + 7, 9, p -> mmantissa, ndigits);
	if (line [12] == ',') line [12] = '.';				// correct comma to decimal in this case

	switch (p -> ee) {
	case	 0: line [18] = ' '; break;
	case	-1: line [18] = 'm'; break;
	case	-2: line [18] = 'u'; break;
	}

	int ch = g - generators;
	lcm1602_write_line (ch, line);
	lcm1602_flash (ch, cursor_locations [p -> cursor], 1);

	frequency_sm_set (g);
}

#define	MAXIMUM_PERIOD		(10 * MEGA - 1)				// this is fine -- 10M x us = 10 s
#define	MINIMUM_PERIOD		10							// anything close to this and you should be generating frequencies, not periods

static void
frequency_event_period (Generator *g, Unit u, Encoder *e)
{
	period_t *p = &g -> period;
	bool refresh = false;

	// MIDDLE moves cursor between fields and field members
	if (u == Middle) {
		if (e -> knob == RE_CCW) {
			if (--p -> cursor < 0) {
				p -> cursor = PeriodLastCursor;
			}
			refresh = true;
		} else if (e -> knob == RE_CW) {
			if (++p -> cursor > PeriodLastCursor) {
				p -> cursor = 0;
			}
			refresh = true;
		}
	}

	// RIGHT selects value, and depends on which field we're in
	if (u == Right) {
		if (e -> button == PB_Hold || e -> button == PB_Release) {
			common_sync (g, u, e);
		}

		if (p -> cursor == 0) {
			// use the common duty UI to select 0..100 inclusive
			if (common_duty (g, u, e)) {
				refresh = true;
			}

		} else if (p -> cursor >= 1 && p -> cursor < PeriodLastCursor) {
			// within the period millimantissa, we can select 0 -> 9,999,999 inclusive, except in the us scale in which case the minimum is 8.
			if (e -> knob == RE_CW) {
				int newm = p -> mmantissa + exponents [7 - p -> cursor];
				if (newm < 10 * MEGA) {
					p -> mmantissa = newm;
					refresh = true;
				}
			} else if (e -> knob == RE_CCW) {
				int newm = p -> mmantissa - exponents [7 - p -> cursor];
				if (newm >= 8 || (p -> ee != -2 && newm > 0)) {
					p -> mmantissa = newm;
					refresh = true;
				}
			}

		} else {
			// within the exponent selection
			if (e -> knob == RE_CW) {
				if (p -> ee < 0) {
					++p -> ee;
				} else {
					p -> ee = -2;
				}
				refresh = true;
			} else if (e -> knob == RE_CCW) {
				if (p -> ee > -2) {
					--p -> ee;
				} else {
					p -> ee = 0;
				}
				refresh = true;
			}
		}
	}

	if (refresh) {
		frequency_display (g, Operating);
	}
}

/*
 *	ROP
*/

/*
 *	program_rop
 *
 *	Sends bits out to the '595 latches, in the order r2b7, r2b6, r2b5, ... r0b2, r0b1, r0b0.
 *	In the hardware, r2b7 ends up ANDing with decoder output 7 on F3.
*/

static void
program_rop (void)
{
	static bool init = false;
	static uint8_t hw [NGENERATORS];

	if (!init) {
		init = true;
		gpio_set_function (ROP_DATA_GPIO, GPIO_FUNC_SIO);
		gpio_set_function (ROP_CLOCK_GPIO, GPIO_FUNC_SIO);
		gpio_set_dir (ROP_DATA_GPIO, GPIO_OUT);
		gpio_set_dir (ROP_CLOCK_GPIO, GPIO_OUT);
		gpio_put (ROP_DATA_GPIO, 1);
		gpio_put (ROP_CLOCK_GPIO, 1);
		hw [0] = ~generators [0].rop.rop;
		hw [1] = ~generators [1].rop.rop;
		hw [2] = ~generators [2].rop.rop;
	}

	bool any = false;
	for (int rop = 0; rop < NGENERATORS; rop++) {
		if (hw [rop] != generators [rop].rop.rop) {
			any = true;
			hw [rop] = generators [rop].rop.rop;
		}
	}

	if (!any) return;

	for (int rop = 3; rop >= 0; rop--) {
		for (int bit = 7; bit >= 0; bit--) {
			gpio_put (ROP_CLOCK_GPIO, 0);
			sleep_us (1);								// @@@ seems to now be required at 5V operation (3v3 doesn't need it, but then the PICOs 3V3 doesn't provide enough drive for all the LEDs to be on at the same time)

			if (rop == 3) {
				gpio_put (ROP_DATA_GPIO, 0);			// last row gets zeros
			} else {
				gpio_put (ROP_DATA_GPIO, !!(generators [rop].rop.rop & (1 << bit)));
			}
			gpio_put (ROP_CLOCK_GPIO, 1);
		}
	}
	gpio_put (ROP_CLOCK_GPIO, 0);
	gpio_put (ROP_CLOCK_GPIO, 1);
}

/*
 *	rop_lookup (r)
 *
 *	Convert r into a short, human readable description.
 *	Not all ROP operations are convertible.
 *
 *		NSB  .....  LSB
 *	C	1 1 1 1 0 0 0 0
 *	B	1 1 0 0 1 1 0 0
 *	A	1 0 1 0 1 0 1 0
 *		- - - - - - - -
 *		0 0 0 0 0 0 0 0  (00)	false
 *		0 0 0 0 0 0 0 1  (01)	-(A|B|C)
 *		0 0 0 0 0 0 1 0  (02)	A only
 *		0 0 0 0 0 0 1 1  (03)	-(B|C)
 *		0 0 0 0 0 1 0 0  (04)	B only
 *		0 0 0 0 0 1 0 1  (05)	-(A|C)
 *		0 0 0 0 1 0 1 0  (0a)	A&-C
 *		0 0 0 0 1 1 0 0  (0c)	B&-C
 *		0 0 0 0 1 1 1 1  (0f)	-C
 *		0 0 0 1 0 0 0 0  (10)	C only
 *		0 0 0 1 1 1 1 0  (1e)	C^(A|B)
 *		0 0 0 1 0 0 0 1  (11)	-(A|B)
 *		0 0 0 1 0 1 1 0  (16)	any 1
 *		0 0 0 1 0 1 1 1  (17)	0 or 1
 *		0 0 1 0 0 0 1 0  (22)	A&-B
 *		0 0 1 0 1 0 0 0  (28)	A&(B^C)
 *		0 0 1 1 0 0 0 0  (30)	C&-B
 *		0 0 1 1 0 0 1 1  (33)	-B
 *		0 0 1 1 0 1 1 0  (36)	B^(A|C)
 *		0 0 1 1 1 1 0 0  (3c)	B^C
 *		0 0 1 1 1 1 1 1  (3f)	-(B&C)
 *		0 1 0 0 0 1 0 0  (44)	B&-A
 *		0 1 0 0 1 0 0 0  (48)	B&(A^C)
 *		0 1 0 1 0 0 0 0  (50)	C&-A
 *		0 1 0 1 0 1 0 1  (55)	-A
 *		0 1 0 1 0 1 1 0  (56)	A^(B|C)
 *		0 1 0 1 1 0 1 0  (5a)	A^C
 *		0 1 0 1 1 1 1 1  (5f)	-(A&C)
 *		0 1 1 0 0 0 0 0  (60)	C&(A^B)
 *		0 1 1 0 0 1 1 0  (66)	A^B
 *		0 1 1 0 1 0 0 0  (68)	any 2
 *		0 1 1 0 1 0 0 1  (69)	0 or 2 (also -(A^B^C))
 *		0 1 1 0 1 0 1 0  (6a)	A^(B&C)
 *		0 1 1 0 1 1 0 0  (6c)	B^(A&C)
 *		0 1 1 1 1 0 0 0  (78)	C^(A&B)
 *		0 1 1 1 0 1 1 1  (77)	-(A&B)
 *		0 1 1 1 1 1 1 0  (7e)	1 or 2
 *		0 1 1 1 1 1 1 1  (7f)	-(A&B&C)
 *		1 0 0 0 0 0 0 0  (80)	A&B&C
 *		1 0 0 0 1 0 0 0  (88)	A&B
 *		1 0 0 1 0 1 1 0  (96)	A^B^C
 *		1 0 0 1 1 0 0 1  (99)	-(A^B)
 *		1 0 1 0 0 0 0 0  (a0)	A&C
 *		1 0 1 0 0 1 0 1  (a5)	-(A^C)
 *		1 0 1 0 1 0 0 0  (a8)	A&(B|C)
 *		1 0 1 0 1 0 1 0  (aa)	A
 *		1 0 1 0 1 1 0 0  (ac)	C?A:B
 *		1 0 1 0 1 1 1 1  (af)	A|(-C)
 *		1 0 1 1 1 0 0 0  (b8)	B?A:C
 *		1 0 1 1 1 0 1 1	 (bb)	A|(-B)
 *		1 0 1 1 1 1 1 0  (be)	A|(B^C)
 *		1 1 0 0 0 0 0 0  (c0)	B&C
 *		1 1 0 0 0 0 1 1  (c3)	-(B^C)
 *		1 1 0 0 1 0 0 0  (c8)	B&(A|C)
 *		1 1 0 0 1 1 0 0  (cc)	B
 *		1 1 0 0 1 1 1 1  (cf)	B|(-C)
 *		1 1 0 1 1 1 0 1  (dd)	(-A)|B
 *		1 1 0 1 1 1 1 0  (de)	B|(A^C)
 *		1 1 1 0 0 0 0 0  (e0)	C&(A|B)
 *		1 1 1 0 0 1 0 0  (e4)	A?B:C
 *		1 1 1 0 1 0 1 0  (ea)	A|(B&C)
 *		1 1 1 0 1 1 0 0  (ec)	B|(A&C)
 *		1 1 1 0 1 1 1 0  (ee)	A|B
 *		1 1 1 1 0 0 0 0  (f0)	C
 *		1 1 1 1 0 0 1 1  (f3)	(-B)|C
 *		1 1 1 1 0 1 1 0  (f6)	C|(A^B)
 *		1 1 1 1 1 0 0 0  (f8)	C|(A&B)
 *		1 1 1 1 1 0 1 0  (fa)	A|C
 *		1 1 1 1 1 1 0 0  (fc)	B|C
 *		1 1 1 1 1 1 0 1  (fd)	(-A)|C
 *		1 1 1 1 1 1 1 0  (fe)	A|B|C
 *		1 1 1 1 1 1 1 1  (ff)	true
 *
 *	We opted for a short-form notation. Instead of -(A|B|C), we distribute the | over the terms, and call it -|ABC; it's RPN+APL-like :-)
 *
 *	The rop_curated[] array groups ROPs together in what's hoped to be a "human ordered" list.
 *
 *	In the current layout, we have 9 spaces for the name, which should be plenty for human readable names.
*/

static struct HexName
{
	uint8_t hex;
	const char *name;
} rop_curated [] =
{
	// constants
	{ 0x00,     "false"}, { 0xff,      "true"},

	// singletons
	{ 0x02,    "A only"}, { 0xaa,         "A"}, { 0x55,        "-A"},
	{ 0x04,    "B only"}, { 0xcc,         "B"}, { 0x33,        "-B"},
	{ 0x10,    "C only"}, { 0xf0,         "C"}, { 0x0f,        "-C"},

	// two operand (A, B)
	{ 0xee,       "|AB"}, { 0x11,      "-|AB"}, { 0xbb,      "|A-B"}, { 0xdd,      "|-AB"},
	{ 0x88,       "&AB"}, { 0x77,      "-&AB"}, { 0x22,      "&A-B"}, { 0x44,      "&-AB"},
	{ 0x66,       "^AB"}, { 0x99,      "-^AB"},

	// two operand (A, C)
	{ 0xfa,       "|AC"}, { 0x05,      "-|AC"}, { 0xaf,      "|A-C"}, { 0xfd,      "|-AC"},
	{ 0xa0,       "&AC"}, { 0x5f,      "-&AC"}, { 0x0a,      "&A-C"}, { 0x50,      "&-AC"},
	{ 0x5a,       "^AC"}, { 0xa5,      "-^AC"},

	// two operand (B, C)
	{ 0xfc,       "|BC"}, { 0x03,      "-|BC"}, { 0xcf,      "|B-C"}, { 0xf3,      "|-BC"},
	{ 0xc0,       "&BC"}, { 0x3f,      "-&BC"}, { 0x0c,      "&B-C"}, { 0x30,      "&-BC"},
	{ 0x3c,       "^BC"}, { 0xc3,      "-^BC"},

	// three operand, first operation OR
	{ 0xfe,      "|ABC"}, { 0x01,     "-|ABC"},
	{ 0xbe,     "|A^BC"}, { 0xea,     "|A&BC"}, { 0xde,     "|B^AC"}, { 0xec,     "|B&AC"}, { 0xf6,     "|C^AB"}, { 0xf8,     "|C&AB"},

	// three operand, first operation AND
	{ 0x80,      "&ABC"}, { 0x7f,     "-&ABC"},
	{ 0xa8,     "&A|BC"}, { 0x28,     "&A^BC"}, { 0xc8,     "&B|AC"}, { 0x48,     "&B^AC"}, { 0xe0,     "&C|AB"}, { 0x60,     "&C^AB"},

	// three operand, first operation XOR
	{ 0x96,      "^ABC"}, { 0x69,     "-^ABC"},
	{ 0x6a,     "^A&BC"}, { 0x56,     "^A|BC"}, { 0x6c,     "^B&AC"}, { 0x36,     "^B|AC"}, { 0x78,     "^C&AB"}, { 0x1e,     "^C|AB"},

	// ternary ("select") operator
	{ 0xd8,     "A?B:C"}, { 0xb8,     "B?A:C"}, { 0xac,     "C?A:B"},

	// misc
	{ 0x16,     "any 1"}, { 0x68,     "any 2"}, { 0x17,    "0 or 1"}, { 0x69,    "0 or 2"}, { 0x7e,    "1 or 2"},
};

static struct ROPInfo
{
	int	curated;
} rop_info [256];

static const char *
rop_lookup (uint8_t r)
{
	static bool init = false;
	static const char *rop_name [256];

	if (!init) {
		init = true;

		// by default, entries point to an empty string
		for (int i = 0; i < NELEMENTS (rop_name); i++) {
			rop_name [i] = "";
		}

		// but select ones point to actual names
		for (int i = 0; i < NELEMENTS (rop_curated); i++) {
			rop_name [rop_curated [i].hex] = rop_curated [i].name;
		}
	}

	return rop_name [r];
}

static int
rop_lookup_curated (uint8_t r)
{
	static bool init = false;

	if (!init) {
		init = true;

		// by default, the curated value is zero, but for ones that have a human-readable name, we write in the index value
		for (int i = 0; i < NELEMENTS (rop_curated); i++) {
			rop_info [rop_curated [i].hex].curated = i;
		}
	}

	return rop_info [r].curated;
}

static void
frequency_display_rop (Generator *g, Phase ph)
{
	/*
	 *	We display the following:
	 *
	 *	01234567891123456789
	 *	R bbbbbbbb hhhhhhhhh
	 *	  \______/ \_______/
	 *       |         +------	human-readable display (if any, else just two digits hex)
	 *	     +----------------	binary value sent to ROP hardware (digits represent values, "." indicates not selected)
	*/

	// where am I?     01234567891123456789
	char line [21] = {"R 76543210 hhhhhhhhh"};			// prototype initialization;
	static int cursor_locations [] = { 2, 3, 4, 5, 6, 7, 8, 9, 11 };
	// what am I?					   |-   binary value   -|   ^- human readable name
	// which one am I?				   0  1  2  3  4  5  6  7   8
	#define ROPLastCursor										8	// highest possible cursor value

	rop_t *r = &g -> rop;

	// write output string
	for (int bit = 0; bit < 8; bit++) {
		line [2 + bit] = r -> rop & (1 << (7 - bit)) ? '0' + (7 - bit) : '.';
	}

	const char *rop_string = rop_lookup (r -> rop);
	if (*rop_string) {
		sprintf (line + 11, "%9.9s", rop_string);
	} else {
		sprintf (line + 11, "     0x%02X", r -> rop);
	}

	int ch = g - generators;
	lcm1602_write_line (ch, line);
	if (r -> cursor == ROPLastCursor) {
		lcm1602_flash (ch, cursor_locations [r -> cursor], 9);
	} else {
		lcm1602_flash (ch, cursor_locations [r -> cursor], 1);
	}
	program_rop ();
}

static void
frequency_event_rop (Generator *g, Unit u, Encoder *e)
{
	rop_t *r = &g -> rop;
	bool refresh = false;

	// MIDDLE moves cursor between fields and field members
	if (u == Middle) {
		if (e -> knob == RE_CCW) {
			if (--r -> cursor < 0) {
				r -> cursor = ROPLastCursor;
			}
			refresh = true;
		} else if (e -> knob == RE_CW) {
			if (++r -> cursor > ROPLastCursor) {
				r -> cursor = 0;
			}
			refresh = true;
		}
	}

	// RIGHT selects value, and depends on which field we're in
	if (u == Right) {
		if (r -> cursor < ROPLastCursor) {
			if (e -> knob == RE_CW) {
				r -> rop += 1 << (7 - r -> cursor);
				refresh = true;
			} else if (e -> knob == RE_CCW) {
				r -> rop -= 1 << (7 - r -> cursor);
				refresh = true;
			}
			if (refresh) {
				// we just changed the raw binary ROP value; see if it has a curated name
				r -> value_rop_curated = rop_lookup_curated (r -> rop);
			}
		} else {
			if (e -> knob == RE_CW) {
				r -> value_rop_curated = (r -> value_rop_curated + 1) % NELEMENTS (rop_curated);
				r -> rop = rop_curated [r -> value_rop_curated].hex;
				refresh = true;
			} else if (e -> knob == RE_CCW) {
				if (r -> value_rop_curated > 0) {
					r -> value_rop_curated--;
				} else {
					r -> value_rop_curated = NELEMENTS (rop_curated) - 1;
				}
				r -> rop = rop_curated [r -> value_rop_curated].hex;
				refresh = true;
			}
		}
	}

	if (refresh) {
		frequency_display (g, Operating);
	}
}

/*
 *	MUSICAL
 *	-------
 *
 *	Notes range from C0 to B9, with A4 being 440 Hz.
 *
 *	https://en.wikipedia.org/wiki/Scientific_pitch_notation says:
 *
 *		The octave number increases by 1 upon an ascension from B to C. Thus, A0 refers
 *		to the first A above C0 and middle C (the one-line octave's C or simply c) is
 *		denoted as C4 in SPN. For example, C4 is one note above B3, and A5 is one note
 *		above G5.
 *
 *	This makes the jumps look a little odd from a strictly sorting perspective.
*/

#define	MAXIMUM_NOTES	(10 * 12)

void
frequency_display_musical (Generator *g, Phase ph)
{
#if 0
	switch (ph) {
	case	Startup:
//		frequency_sm_enable (true, g);
		return;

	case	Shutdown:
//		frequency_sm_stop (g);
		return;
	}

	static bool init = false;
	static float frequencies [MAXIMUM_NOTES];			// e.g., [0] == C0, [57] = A4, [119] = B9
	static char names [] =  "CCDDEFFGGAAB";
	static char sharps [] = " # #  # # # ";

	if (!init) {
		init = true;
		for (int i = 0; i < NELEMENTS (frequencies); i++) {
			frequencies [i] = 440. * pow (2., ((double) i - 57.) / 12.);
//			printf ("%c%c%d -> %.1f\n", names [i % 12], sharps [i % 12], i / 12, frequencies [i]);
		}
	}

	// string columns:  01234567891123456789
	char line [21] = { " Note F#4   369.9 Hz" };		// prototype initialized string
	int ch = g - generators;
	line [6] = names [g -> value_musical % 12];
	line [7] = sharps [g -> value_musical % 12];
	line [8] = g -> value_musical / 12 + '0';

	sprintf (line + 10, "%7.1f Hz", frequencies [g -> value_musical]);
	lcm1602_write_line (ch, line);

	static int digit_locations [] = { 6, 8 };		// digit number -> column map
	if (g -> digit >= NELEMENTS (digit_locations)) {
		g -> digit = NELEMENTS (digit_locations) - 1;				// we may be coming from a different mode that has a larger digit range
	}
	lcm1602_flash (ch, cursor_locations [m -> cursor], 1);
//	g -> frequency_requested = frequencies [g -> value_musical];
//	frequency_sm_set (g);
#endif
}

static void
frequency_event_musical (Generator *g, Unit u, Encoder *e)
{
#if 0
	if (left == CW || left == CCW) {
		g -> digit = !g -> digit;
		frequency_display (g, Operating);
	}

	if (right == CW) {
		int newn = g -> value_musical + (g -> digit ? 12 : 1);
		if (newn < MAXIMUM_NOTES) {
			g -> value_musical = newn;
			frequency_display (g, Operating);
		}
	} else if (right == CCW) {
		int newn = g -> value_musical - (g -> digit ? 12 : 1);
		if (newn >= 0) {
			g -> value_musical = newn;
			frequency_display (g, Operating);
		}
	}
#endif
}

static void
frequency_display (Generator *g, Phase ph)
{
	switch (g -> mode) {
	case	Decimal:	frequency_display_decimal (g, ph);	break;
//	case	Musical:	frequency_display_musical (g, ph);	break;
	case	Period:		frequency_display_period (g, ph);	break;
	case	ROP:		frequency_display_rop (g, ph);		break;
	}
}

static Encoder current [NENCODER_ROWS * NENCODER_COLUMNS];

static void
init_decimal (Generator *g)
{
	decimal_t *d = &g -> decimal;
	d -> mmantissa = KILO;								// set a reasonable frequency
	d -> ee = 0;										// 1k milli mantissa * 10^(3*0) == 1 Hz
	d -> cursor = 4;									// position cursor over the most-likely-to-adjust digit
}

static void
init_period (Generator *g)
{
	period_t *p = &g -> period;
	p -> mmantissa = KILO;								// set a reasonable period
	p -> ee = 0;										// 1k milli mantissa * 10^(3 * 0) == 1 s
	p -> cursor = 4;									// position cursor over the most-likely-to-adjust digit
}

static void
init_rop (Generator *g)
{
	rop_t *r = &g -> rop;
	switch (g - generators) {
	case	0: r -> rop = 0xAA;	 break;					// default ROP is identity "A"
	case	1: r -> rop = 0xCC;	 break;					// default ROP is identity "B"
	case	2: r -> rop = 0xF0;	 break;					// default ROP is identity "C"
	}

	r -> cursor = 8;									// position cursor over the ROP-by-name selector
	r -> value_rop_curated = rop_lookup_curated (r -> rop);
}

static int frequency_generator_gpios [] = { FGEN1_GPIO, FGEN2_GPIO, FGEN3_GPIO };

static void
init_frequency_generator (void)
{
	Generator *g = generators;
	for (int i = 0; i < NELEMENTS (generators); i++) {
		g -> duty = 50;									// set a reasonable duty cycle
		g -> gpio = frequency_generator_gpios [i];
		g -> mode = Decimal;
		g -> hw_low = g -> hw_high = 0;					// invalid value, forces initialization
		init_decimal (g);
		init_period (g);
		init_rop (g);
		frequency_display (&generators [i], Startup);
		g++;
	}
	program_rop ();
}

static void
frequency_event (Generator *g, Unit u, Encoder *e)
{
	switch (g -> mode) {
	case	Decimal:	frequency_event_decimal (g, u, e);	break;
	case	Period:		frequency_event_period  (g, u, e);	break;
	case	ROP:		frequency_event_rop		(g, u, e);	break;
	default:
		break;
	}
}

void
frequency_generator (bool power)
{
	static bool current_power = false;
	bool refresh = false;

	if (power != current_power) {
		current_power = power;
		if (power) {
			init_frequency_generator ();
			refresh = true;
		} else {
			// anything you want to do to turn off power
		}
	}

	if (!power) return;

	// see if anything interesting happened
	for (int i = 0; i < NELEMENTS (current); i++) {
		Encoder *c = current + i;
		Encoder *e = get_encoder (i);
		Generator *g = generators + i / 3;				// 3 encoders per generator

		// pushbutton change?
		if (e -> button != c -> button) {
//printf ("Button unit %d change, was %s, now %s\n", i, PushButtonStateName (c -> button), PushButtonStateName (e -> button));
			c -> button = e -> button;
			e -> button = PB_None;						// consume the event
			frequency_event (g, i % 3, c);
		}

		// rotation?
		if (e -> knob != c -> knob) {
//printf ("Knob unit %d change, was %s @ %d, now %s @ %d\n", i, RotaryEncoderStateName (c -> knob), c -> knob_position, RotaryEncoderStateName (e -> knob), e -> knob_position);
			c -> knob = e -> knob;
			c -> knob_position = e -> knob_position;
			e -> knob = RE_None;						// consume the event

			if (i % 3 == 0) {							// left knob
				if (c -> knob == RE_CCW) {
					frequency_display (g, Shutdown);
					if (g -> mode == 0) {
						g -> mode = NMODES - 1;
					} else --g -> mode;
					frequency_display (g, Startup);
					refresh = true;
				} else if (c -> knob == RE_CW) {
					frequency_display (g, Shutdown);
					if (++g -> mode >= NMODES) {
						g -> mode = 0;
					}
					frequency_display (g, Startup);
					refresh = true;
				}
			} else {									// middle and right knobs
				frequency_event (g, i % 3, c);
			}
		}
	}
}

