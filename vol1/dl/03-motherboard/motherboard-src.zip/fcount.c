
/*
 *	fcount.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	Frequency counter module.
 *
 *	2025 10 09	R. Krten		created
*/

#include "main.h"
#include "edge.pio.h"
#include <string.h>

#define	DC_LOW		-1
#define	DC_HIGH		-2

typedef struct
{
	PIO			pio;
	uint		sm;
	int			pin;
	float		frequency;								// Hz, if negative, then  DC_LOW or DC_HIGH
	uint64_t	last_data;
	int32_t		last_high;
	int32_t		last_low;
}	Counter;

#define	NCOUNTERS	3
static	Counter counters [NCOUNTERS];

static void
init_frequency_counter (void)
{
	setup_pio_edge_timer (&counters [0].pio, &counters [0].sm, SAMPLE1_GPIO);
	setup_pio_edge_timer (&counters [1].pio, &counters [1].sm, SAMPLE2_GPIO);
	setup_pio_edge_timer (&counters [2].pio, &counters [2].sm, SAMPLE3_GPIO);

	lcm1602_write_line (3, "------ ------ ------");
}

static void
display_value (Counter *c)
{
	/*
	 *	We display the following:
	 *
	 *	01234567891123456789
	 *	<val1> <val2> <val3>	Three frequency values, 6 characters each, as follows:
	 *
	 *	123456	Description
	 *	------	---------------------------------------------------------------------------------
	 *	DC  Lo	If we can't compute a frequency, we at least show the polarity of the signal, low
	 *	DC  Hi	or high.
	 *	1.0000	Lowest computable value, 1 Hz -- anything lower than that and we call it DC
	 *	10.000	10 Hz
	 *	100.00	100 Hz
	 *	1k0000	1,000 Hz
	 *	10k000	10,000 Hz
	 *	100k00	100,000 Hz
	 *	1M0000	1,000,000 Hz
	 *	10M000	10,000,000 Hz
	 *	100M00	100,000,000 Hz
	*/

	char field [7] = {"------"};						// prototype initialization

	if (c -> frequency < 0) {
		if (c -> frequency == DC_LOW) {
			lcm1602_write_line_at (3, (c - counters) * 7, "DC  LO");
		} else if (c -> frequency == DC_HIGH) {
			lcm1602_write_line_at (3, (c - counters) * 7, "DC  HI");
		}
	} else {
		if (c -> frequency < 10) {
			snprintf (field, sizeof (field), "%6.4f", c -> frequency);
		} else if (c -> frequency < 100) {
			snprintf (field, sizeof (field), "%6.3f", c -> frequency);
		} else if (c -> frequency < KILO) {
			snprintf (field, sizeof (field), "%6.2f", c -> frequency);
		} else if (c -> frequency < 10 * KILO) {
			snprintf (field, sizeof (field), "%dk%04d", (int) (c -> frequency / KILO), (int) (c -> frequency * 10.) % (10 * KILO));
		} else if (c -> frequency < 100 * KILO) {
			snprintf (field, sizeof (field), "%2dk%03d", (int) (c -> frequency / KILO), (int) (c -> frequency) % KILO);
		} else if (c -> frequency < MEGA) {
			snprintf (field, sizeof (field), "%3dk%02d", (int) (c -> frequency / KILO), (int) (c -> frequency / 10) % 100);
		} else if (c -> frequency < 10 * MEGA) {
			snprintf (field, sizeof (field), "%dM%04d", (int) (c -> frequency / MEGA), (int) (c -> frequency / 100) % (10 * KILO));
		} else {
			snprintf (field, sizeof (field), "%2dM%03d", (int) (c -> frequency / MEGA), (int) (c -> frequency / KILO) % KILO);
		}
		lcm1602_write_line_at (3, (c - counters) * 7, field);
	}
}

#define	UPDATE_PERIOD_US	(250 * KILO)
#define	CONSIDERED_AS_DC_US	(MEGA)

static float
compute (int32_t l, int32_t h)
{
	uint64_t total = l + h;
	return 1. / ((float) total * 8e-9);
}

void
frequency_counter (bool power)
{
	static bool current_power = false;

	if (power != current_power) {
		current_power = power;
		if (power) {
			init_frequency_counter ();
		} else {
			// anything you want to do to turn off power
			return;
		}
	}

	static uint64_t last = 0;

	if (now - last < UPDATE_PERIOD_US) return;
	last = now;

	for (Counter *c = counters; c < counters + NCOUNTERS; c++) {
		if (now - c -> last_data > CONSIDERED_AS_DC_US) {
	//printf ("D\n");
			c -> frequency = gpio_get (c -> pin) ? DC_HIGH : DC_LOW;
			c -> last_data = now;
			continue;
		}

		if (pio_sm_is_rx_fifo_empty (c -> pio, c -> sm)) {
			// if this continues, then we'll declare DC due to timeout above
	//printf ("E\n");
			continue;
		}

		c -> last_data = now;


		int data = pio_sm_get (c -> pio, c -> sm);
	//printf ("V %d -> ", data);

		if (data < 0) {
			c -> last_low = -2 * data  + 2;
			if (pio_sm_is_rx_fifo_empty (c -> pio, c -> sm)) {
				c -> last_high = 0;
	//			printf ("not ready\n");
			} else {
				data = pio_sm_get (c -> pio, c -> sm);
				c -> last_high = 2 * data + 5;
	//			printf ("FAST: high signal, %d H and %d L\n", c -> last_high, c -> last_low);
				c -> frequency = compute (c -> last_low, c -> last_high);
				display_value (c);
				// fast, so drain up to 16 samples
				for (int i = 0; i < 16; i++) {
					if (pio_sm_is_rx_fifo_empty (c -> pio, c -> sm)) {
						break;
					}
					pio_sm_get (c -> pio, c -> sm);
				}
			}
		} else {
			c -> last_high = 2 * data + 5;
	//		printf ("SLOW: high signal, %d H and %d L\n", c -> last_high, c -> last_low);
			c -> frequency = compute (c -> last_low, c -> last_high);
			display_value (c);
		}
	}
}

