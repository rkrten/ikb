
/*
 *	fgen.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 12	R. Krten		created
*/

void frequency_generator (bool power);
