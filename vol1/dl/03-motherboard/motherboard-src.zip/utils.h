
/*
 *	utils.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 27	R. Krten		created
*/

const char * digits_with_comma (char *dest, size_t len, uint32_t value, int leader);

