
/*
 *	encoder.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	Handles rotary encoders.
 *
 *	2025 10 09	R. Krten		created
*/

#include "main.h"

#define	DEBOUNCE_PERIOD_US		750
#define	HOLD_THRESHOLD_US		MEGA

typedef struct
{
	uint64_t	since;
	bool		current;
} Debounced;

static bool
debounce (Debounced *d, bool value)
{
	if (value == d -> current) {
		d -> since = now;
	} else {
		if (now - d -> since >= DEBOUNCE_PERIOD_US) {
			d -> current = value;
			d -> since = now;
		}
	}

	return d -> current;
}

static int encoder_inputs [] = { ENCODER_SWITCH_SENSE, ENCODER_PHASE1_SENSE, ENCODER_PHASE2_SENSE };
static int encoder_outputs [] = { ENCODER_ADDR0, ENCODER_ADDR1, ENCODER_ADDR2, ENCODER_ADDR3 };

static Encoder encoders [NENCODER_ROWS * NENCODER_COLUMNS];

typedef struct
{
	Debounced	sw;										// the value of the pushbutton switch
	uint64_t	since;									// since when have we held the switch?
	bool		held;									// do we know that it's held?
	Debounced	ph1;									// the value of the phase 1 output
	Debounced	ph2;									// the value of the phase 2 output
} encoder_value_t;

static encoder_value_t values [NENCODER_ROWS * NENCODER_COLUMNS];

static void
set_address (int which)
{
	/*
	 *	The matrix looks like this:
	 *	0	2	1
	 *
	 *	6	8	7
	 *
	 *	3	5	4
	*/
	static int adtrans [] = { 0, 2, 1, 6, 8, 7, 3, 5, 4 };	// hardware and the art of PCB layout, right?

	which = adtrans [which % NELEMENTS (adtrans)];
	gpio_put (ENCODER_ADDR0, !!(which & 1));
	gpio_put (ENCODER_ADDR1, !!(which & 2));
	gpio_put (ENCODER_ADDR2, !!(which & 4));
	gpio_put (ENCODER_ADDR3, !!(which & 8));
}

static void
set_init_value (encoder_value_t *v)
{
	v -> sw.current = false;
	v -> since = now;
	v -> held = false;
	v -> ph1.current = false;
	v -> ph2.current = false;
}

void
init_encoders (void)
{
	// set up the hardware
	for (int i = 0; i < NELEMENTS (encoder_inputs); i++) {
		int p = encoder_inputs [i];
		gpio_set_function (p, GPIO_FUNC_SIO);
		gpio_set_dir (p, GPIO_IN);
		gpio_pull_down (p);
	}

	for (int i = 0; i < NELEMENTS (encoder_outputs); i++) {
		int p = encoder_outputs [i];
		gpio_set_function (p, GPIO_FUNC_SIO);
		gpio_set_dir (p, GPIO_OUT);
		gpio_put (p, 0);
	}

	for (int i = 0; i < NELEMENTS (values); i++) {
		set_init_value (&values [i]);
	}

//#define	DEBUG
#ifdef	DEBUG
	for (;;) {
		for (int i = 0; i < 9; i++) {
			set_address (i);
			sleep_ms (100);
			int a = gpio_get (ENCODER_SWITCH_SENSE);
			int b = gpio_get (ENCODER_PHASE1_SENSE);
			int c = gpio_get (ENCODER_PHASE2_SENSE);
			printf ("%d -> %d %d %d\n", i, a, b, c);
		}
		printf ("\n");
		sleep_ms (1000);
	}
#endif	// DEBUG
}


void
hardware_scan (bool power)
{
	static bool current_power = false;

	if (power != current_power) {
		current_power = power;
	}

	static int rotor = 0;
	static enum { Address, Read } state = Address;

	switch (state) {
	case	Address:
		set_address (rotor);
		state = Read;									// we read on the next cycle in order to give time to propagate the signal
		break;

	case	Read:
		// read the three sense inputs, with debounce
		encoder_value_t *v = &values [rotor];
		bool old_sw = !v -> sw.current;
		bool new_sw = !debounce (&v -> sw, gpio_get (ENCODER_SWITCH_SENSE));

		// switch change?
		if (old_sw != new_sw) {
//printf ("%02d SW %d -> %d\n", rotor, old_sw, new_sw);
			if (new_sw) {								// switch released (negative logic)
				encoders [rotor].button = PB_Release;
				v -> held = false;
			} else {
				encoders [rotor].button = PB_Press;
				v -> since = now;
			}
		} else {
			if (!old_sw && !v -> held && now - v -> since > HOLD_THRESHOLD_US) {
				v -> held = true;
				encoders [rotor].button = PB_Hold;
			}
		}

		// phase change?
		int old_phase = 2 * v -> ph2.current + v -> ph1.current;
		int new_phase = 2 * debounce (&v -> ph2, gpio_get (ENCODER_PHASE2_SENSE)) + debounce (&v -> ph1, gpio_get (ENCODER_PHASE1_SENSE));
		if (old_phase != new_phase) {
//printf ("%02d PH %d -> %d\n", rotor, old_phase, new_phase);
			if (new_phase == 3) {
				if (old_phase == 1) {
					encoders [rotor].knob_position--;
					encoders [rotor].knob = RE_CCW;
				} else if (old_phase == 2) {
					encoders [rotor].knob_position++;
					encoders [rotor].knob = RE_CW;
				}
			}
		}

		rotor = (rotor + 1) % NELEMENTS (values);
		state = Address;
		break;
	}
}

Encoder *
get_encoder (int unit)
{
	return encoders + (unit % NELEMENTS (encoders));
}

