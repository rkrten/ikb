
/*
 *	main.c
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	This module drives the frequency counter.
 *
 *	2025 10 09	R. Krten		created
*/

#include "main.h"
#include "version.h"
#include "hardware/clocks.h"

static void
banner (bool show)
{
	if (show) {
		char line [NCOLUMNS + 1] = { 0 };
		lcm1602_write_line (0, " Function Generator ");
		lcm1602_write_line (1, " Frequency  Counter ");
		snprintf (line, sizeof (line), "IKCH33 Version %5.5s", version);
		lcm1602_write_line (2, line);
		snprintf (line, sizeof (line), "    %03d MHz PICO", system_clock / MEGA);
		lcm1602_write_line (3, line);
	} else {
		for (int i = 0; i < NROWS; i++) lcm1602_write_line (i, "");
	}
}

uint64_t now = 0;
uint32_t system_clock = 0;								// system clock speed in Hz
uint32_t system_period = 0;								// system clock speed in ns

static void
background (void)
{
	// in the beginning was darkness...
	lcm1602_display_enabled (false);
	lcm1602_backlight (false);
	lcm1602_cursor_blink (false);

	enum {
		Off,											// nothing is happening, power is off
		PoweringOn,										// startup, proceeding to powered on
		On, 											// operating state
		PoweringOff										// sequencing back to power off
	} major = Off;

	uint64_t since = now;
	for (;;) {
		now = time_us_64 ();

		switch (major) {
		case	Off:

			if (now - since > MEGA * 1) {
				// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
				// @@@ replace with pushbutton detection, not timing
				// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
				banner (true);
				lcm1602_display_enabled (true);
				lcm1602_backlight (true);
				major = PoweringOn;
				since = now;
			}
			break;

		case	PoweringOn:
			if (now - since > MEGA * 1) {				// show splash screen for this long
				banner (false);
				major = On;
				since = now;
			}
			break;

		case	On:
			if (now - since > 1000) {
				printf ("%lld us\n", now - since);
			}
			since = now;
			frequency_counter (true);
			frequency_generator (true);
			hardware_scan (true);
			break;

		case	PoweringOff:
			lcm1602_display_enabled (false);
			lcm1602_backlight (false);
			frequency_counter (false);
			frequency_generator (false);
			hardware_scan (false);
			major = Off;
			break;
		}
	}
}

void
main (void)
{
	now = time_us_64();									// establish a baseline
	init_lcm1602 ();

#define	USB_STDIO
#ifdef	USB_STDIO
	stdio_init_all ();
	stdio_set_translate_crlf (&stdio_usb, false);		// prevent library from helpfully converting \n to \r\n
	sleep_ms (2000);
#endif	// USB_STDIO

	init_encoders ();

	system_clock = clock_get_hz (clk_sys);				// in Hertz
	system_period = GIGA / system_clock;				// in nanoseconds

	multicore_launch_core1 (background);

	uint64_t last = 0;
	for (;;) {
		sleep_us (100);									// we certainly don't need to be any faster than this (and downstream processors slow this down internally even more)
		lcm1602_drive ();								// slow AF
	}
}

