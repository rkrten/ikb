
/*
 *	encoder.h
 *
 *	(C) Copyright 2025 by Robert Krten, all rights reserved.
 *
 *	2025 10 09	R. Krten		created
*/

typedef enum
{
	PB_None,
	PB_Press,
	PB_Hold,
	PB_Release
}	PushButtonState;

typedef enum
{
	RE_None,
	RE_CW,
	RE_CCW
}	RotaryEncoderState;

static inline
const char *PushButtonStateName (PushButtonState pb)
{
	switch (pb) {
	case	PB_None:		return "None";
	case	PB_Press:		return "Press";
	case	PB_Hold:		return "Hold";
	case	PB_Release:		return "Release";
	}
	return "<unknown>";
}

static inline
const char *RotaryEncoderStateName (RotaryEncoderState re)
{
	switch (re) {
	case	RE_None:		return "None";
	case	RE_CW:			return "CW";
	case	RE_CCW:			return "CCW";
	}
	return "<unknown>";
}

typedef struct
{
	PushButtonState		button;
	RotaryEncoderState	knob;
	uint32_t			knob_position;
}	Encoder;

// hardware is configured as follows:
#define	NENCODER_ROWS		3
#define	NENCODER_COLUMNS	3

void hardware_scan (bool power);
void init_encoders (void);
Encoder *get_encoder (int unit);

