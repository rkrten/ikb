
/*
 *	gps.c
 *
 *	(C) Copyright 2024 by Robert Krten, all rights reserved.
 *
 *	This library module performs GPS NMEA string processing.
 *
 *	2024 12 05	R. Krten		created from IKCH31C GPS processing routines.
*/

#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include "hardware/uart.h"
#include "hardware/gpio.h"
#include "gps.h"

GPS_t *
gps_create (GPS_t *gps)
{
	// allow them to specify a structure, or NULL to allocate one
	if (gps) {
		memset (gps, 0, sizeof (*gps));
	} else {
		gps = calloc (sizeof (GPS_t), 1);
	}
	if (!gps) {
		return NULL;
	}

	// set up defaults -- we can add getters and setters later if we need them, for now, this should cover most cases
	gps -> baud = 9600;
	gps -> data = 8;
	gps -> stop = 1;
	gps -> parity = UART_PARITY_NONE;
	gps -> uart = NULL;
	gps -> serial_initialized = false;

	gps -> state = GPS_IDLE;
	gps -> content_index = 0;
	gps -> checksum = 0;
	gps -> phrase = 0;

	return gps;
}

void
gps_destroy (GPS_t *gps)
{
	free (gps);
}

void
gps_init_serial (GPS_t *gps, int rx_pin, int tx_pin)
{
	if (!gps) return;

	if (rx_pin == 1 || rx_pin == 13 || rx_pin == 17) {
		if (tx_pin >= 0 && tx_pin != 0 && tx_pin != 12 && tx_pin != 16) {
			// TX pin specified, but didn't correspond to RX uart
			return;
		}
		gps -> uart = uart0;
	} else if (rx_pin == 5 || rx_pin == 9) {
		if (tx_pin >= 0 && tx_pin != 4 && tx_pin != 8) {
			// TX pin specified, but didn't correspond to RX uart
			return;
		}
		gps -> uart = uart1;
	} else {
		// invalid RX pin choice, no UARTs present
		return;
	}

	uart_init (gps -> uart, gps -> baud);
	uart_set_format (gps -> uart, gps -> data, gps -> stop, gps -> parity);
	gpio_set_function (rx_pin, GPIO_FUNC_UART);

	if (tx_pin >= 0) {
		// drive the TX pin low; this prevents noise from triggering the generator's RX
		gpio_init (tx_pin);
		gpio_set_dir (tx_pin, GPIO_OUT);
		gpio_put (tx_pin, 0);
	}

	gps -> serial_initialized = true;
}

void
gps_set_callback (GPS_t *gps, void (*done) (GPS_t *))
{
	if (gps) {
		gps -> done = done;
	}
}

int
gps_handle_serial (GPS_t *gps)
{
	if (!gps || !gps -> serial_initialized) return -1;

	int nchars = 0;
	while (uart_is_readable (gps -> uart)) {
		nchars++;
		gps_handle_character (gps, uart_getc (gps -> uart));
	}
	return nchars;
}

void
gps_handle_character (GPS_t *gps, uint8_t ch)
{
//printf ("%c", ch);
	if (!gps) return;

	switch (gps -> state) {
	case	GPS_IDLE:
		if (ch == '$') {
			gps -> state = GPS_PHRASE;
			gps -> content [gps -> content_index = 0] = 0;
			gps -> phrase = gps -> checksum = 0;
			*gps -> gps_date = *gps -> gps_time = 0;
			gps -> valid = GPS_TYPE_NONE;
		}
		break;

	case	GPS_PHRASE:
		if (ch == '*') {
			// we don't bother processing the last phrase, "A"
			gps -> state = GPS_CHECKSUM_FIRST_DIGIT;
			break;
		}

		gps -> checksum ^= ch;						// all other characters count towards the checksum
		if (ch == ',') {
			if (gps -> phrase == 0) {
				if (!strcmp (gps -> content, "GPRMC")) {
					gps -> valid = GPS_TYPE_GPRMC;
				} else if (!strcmp (gps -> content, "GNRMC")) {
					gps -> valid = GPS_TYPE_GNRMC;
				} else {
					gps -> state = GPS_IDLE;		// these are not the droids you're looking for
					break;							// no further processing
				}
			} else if (gps -> phrase == 1) {		// because we process GPRMC / GNRMC only, we know that the time is in phrase 1
				strlcpy (gps -> gps_time, gps -> content, sizeof (gps -> gps_time));
			} else if (gps -> phrase == 9) {		// because we process GPRMC / GNRMC only, we know that the date is in phrase 9
				strlcpy (gps -> gps_date, gps -> content, sizeof (gps -> gps_date));
			}
			gps -> phrase++;
			gps -> content [gps -> content_index = 0] = 0;		// reset
		} else {
			if (gps -> content_index >= sizeof (gps -> content) - 1) {
				gps -> state = GPS_IDLE;
				break;
			}

			gps -> content [gps -> content_index++] = ch;
			gps -> content [gps -> content_index] = 0;			// keep nul terminated for convenience
		}
		break;

	case	GPS_CHECKSUM_FIRST_DIGIT:
		if (isxdigit (ch)) {
			gps -> checksum ^= (isdigit (ch) ? ch - '0' : tolower (ch) - 'a' + 10) << 4;	// first digit is high nybble
			gps -> state = GPS_CHECKSUM_SECOND_DIGIT;
		} else {
			gps -> state = GPS_IDLE;
		}
		break;

	case	GPS_CHECKSUM_SECOND_DIGIT:
		if (isxdigit (ch)) {
			gps -> checksum ^= isdigit (ch) ? ch - '0' : tolower (ch) - 'a' + 10;			// second digit is low nybble
			if (!gps -> checksum) {
//printf ("DATE [%s] TIME [%s]\n", gps -> gps_date, gps -> gps_time);
				if (*gps -> gps_date && *gps -> gps_time) {
					if (gps -> done) {
						gps -> done (gps);					// checksum is good, call the callback
					}
				}
			}
		}
		gps -> state = GPS_IDLE;
		break;

	}
}

