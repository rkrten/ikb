
/*
 *	gps.h
 *
 *	(C) Copyright 2024 by Robert Krten, all rights reserved.
 *
 *	Interface for GPS library
 *
 *	2024 12 05	R. Krten		created from IKCH31C GPS routines.
*/

typedef enum { GPS_IDLE, GPS_PHRASE, GPS_CHECKSUM_FIRST_DIGIT, GPS_CHECKSUM_SECOND_DIGIT } GPS_State;

typedef enum { GPS_TYPE_NONE, GPS_TYPE_GPRMC, GPS_TYPE_GNRMC } GPS_Type;

typedef struct GPS_s GPS_t;

struct GPS_s
{
	// the serial port
	unsigned baud;
	unsigned stop;
	unsigned data;
	unsigned parity;
	uart_inst_t *uart;								// uart0 or uart1, auto detected
	bool serial_initialized;						// indicates if we've initialized the serial port

	// the GPS processor
	GPS_State	state;
	char		content [64];
	int			content_index;
	uint8_t		checksum;
	int			phrase;								// which CSV value we are in; "GPRMC"/"GNRMC" is phrase 0
	char		gps_date [7];						// string snapshot from serial state machine
	char		gps_time [7];
	GPS_Type	valid;								// which string we found

	// the optional callback
	void		(*done) (GPS_t *gps);

};

/*
 *	gps_create(), gps_destroy()
 *
 *	Call gps_create() to initialize a GPS_t structure that you supply, or if you pass
 *	NULL, to allocate one for you. If dynamic allocation is requested and fails, NULL
 *	is returned.
 *	Call gps_destroy() to return the resources if they were dynamically allocated.
 *
 *	You must still call gps_init_serial() to set up the serial port associated with GPS
 *	if you plan on using the functions with a serial port.
*/

GPS_t *gps_create (GPS_t *gps);
void gps_destroy (GPS_t *gps);

/*
 *	gps_set_callback (gps, cb)
 *
 *	Set the callback on valid phrase detection to "cb".
 *	To remove the callback, pass NULL.
 *
 *	When a valid phrase (that is, one that is in the set of things we are processing,
 *	and has a valid checksum) is detected, the callback (if not NULL) will be called.
 *	The context structure's "valid" member indicates the detected phrase.
*/

void gps_set_callback (GPS_t *gps, void (*done) (GPS_t *));

/*
 *	gps_init_serial (gps, rx, tx)
 *
 *	Initialize the serial port associated with the GPS.
 *
 *	This is a convenience function that you can use if you source your data from
 *	a serial port.
 *
 *	Note that the TX pin can be -1, meaning it's not used (we don't use it anyway,
 *	but if you specify the TX pin, we set it low so that it doesn't cause noise on
 *	the serial data line going into the GPS).
 *
 *	The uart (uart0 or uart1) is auto-detected.
 *	If both an rx and tx pin are specified, they must be on the same uart.
*/

void gps_init_serial (GPS_t *gps, int rx_pin, int tx_pin);

/*
 *	gps_handle_serial (GPS_t *gps)
 *
 *	Check the serial port, and process characters from it while characters are
 *	immediately available.
 *
 *	Returns the number of characters processed, -1 on error.
 *
 *	If you're not processing characters from a serial port, you can use the
 *	gps_handle_character () function instead to feed characters one by one
 *	to the state machine -- that's what this function ends up doing anyway.
*/

int gps_handle_serial (GPS_t *gps);

/*
 *	gps_handle_character (GPS_t *gps, uint8_t character)
 *
 *	Process one character in the context of the gps context structure.
*/

void gps_handle_character (GPS_t *gps, uint8_t character);

