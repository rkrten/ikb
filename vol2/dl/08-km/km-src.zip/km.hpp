
/*
 *	km.hpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module represents the master include for the KiCad Move tool.
 *
 *	2023 02 06	R. Krten		created
*/

#include <fstream>
#include <map>
#include <set>
#include <cmath>

using namespace std;

#include <string.h>
#include "options.hpp"
#include "stringf.hpp"

#define NELEMENTS(_x) ((sizeof(_x)/sizeof((_x)[0])))

extern	const char *progname;							// main.cpp
extern	string	version;								// version.hpp

extern	bool			optf;							// main.cpp, display footprints
extern	bool			optp;							// main.cpp, pretty print
extern	string			optP;							// main.cpp, pattern (default none)
extern	list <string>	optr;							// main.cpp, limit operation to these references only
extern	set <string>	optr_set;						// main.cpp, optr as a set
extern	bool			optt;							// main.cpp, tabularize
extern	double			optx;							// main.cpp, X basis of operations
extern	double			opty;							// main.cpp, Y basis of operations
extern	int				optv;							// main.cpp, verbosity level

#include "sexpr.hpp"
#include "process.hpp"
