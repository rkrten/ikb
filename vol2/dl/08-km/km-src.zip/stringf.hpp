
/*
 *	stringf.hpp
 *
 *	(C) Copyright 2020, Robert Krten.  All rights reserved.
 *
 *	This is the public include file for stringf from the RK++ library.
 *
 *	2020 12 23	R. Krten		created.
 *	2021 09 05	R. Krten		added stringf() by popular demand.
*/

#ifndef	__LIBRKPP__STRINGF__
#define	__LIBRKPP__STRINGF__

#include <string>
#include <stdint.h>

#define	KILO	1000LL
#define	MEGA	(KILO * KILO)
#define	GIGA	(MEGA * KILO)
#define	TERA	(GIGA * KILO)
#define	PETA	(TERA * KILO)
#define	EXA		(PETA * KILO)

namespace rkpp {
	using namespace std;

	// put everything in here
	string comma (uint64_t n);
	string signed_comma (int64_t n);
	string stringf (const string format, ...);
};

#endif	// __LIBRKPP__STRINGF__

