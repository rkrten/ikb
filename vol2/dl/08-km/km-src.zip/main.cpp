
/*
 *	main.cpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module represents the main module for km, the KiCad Move tool.
 *
 *	2023 02 06	R. Krten		created
*/

#include "km.hpp"
#include "version.hpp"
#include "build.hpp"

using namespace std;
using namespace rkpp;

static string usage_message
{
//--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8----+----9----+----1
R"USAGE(
usage:
km [options] arguments

where [options] are optional parameters chosen from:
    -f             display space separated footprint values
    -p             pretty print the input file
    -P pat[,args]  apply a distribution pattern "pat" with optional arguments (see below)
    -r <rspec>     apply operations to the following component references only (see below)
    -t             tabularize components primarily by type and secondarily by reference
    -w             write output (overwrites input file)
    -x base        X basis of operations (default 0)
    -y base        Y basis of operations (default 0)
    -v             verbose operation

Manipulates a KiCad PCB layout file (version 6).

Notes:

<rspec> is a list of component references which limit the footprints that are modified. If you
don't specify any -r value, then all footprints are candidates for modification. This is probably
not what you want, except for the -t case.

<rspec> is given as a comma separated (no spaces) list of component references, e.g., D100,D101,D102
In the glorious future, we might allow fnmatch style expressions (e.g., "D1??") and ranges (e.g.,
"D100-D119,D130-D149") and other more complicated expressions. Right now, be happy (use -f to show
all the references and then use sed).

Distribution patterns are selected from the list below. Note that each option is literally the
optional character, followed by an equals sign, followed by the value. There are no spaces
between options.

    ring[,option[,option]...]
    - Distributes footprints in a ring. Great for making clocks.
      Options are:
         r=radius   -- distance from center (x and y basis) to component (default 0)
         s=stepsize -- number of degrees to add to each component (default 360 / # value in -r)
         i=initial  -- initial degree (default zero)
         c=rotation -- component rotation (added to ring rotation)

)USAGE"
//--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8----+----9----+----1
};

const char		*progname = "km";
bool			optf = false;							// show footprints
bool			optp = false;							// pretty print the input file
string			optP;									// pattern (default none)
list <string>	optr;									// limit operation to these references only, and in the specified order
set <string>	optr_set;								// optr as a set; useful for quick search when order isn't important
bool			optt = false;							// tabularize
bool			optw = false;							// write permission
double			optx = 0;								// X basis of operations
double			opty = 0;								// Y basis of operations
int				optv = 0;								// verbose operation (default off)

int
main (int argc, char **argv)
{
	vector <string> arglist;
	try {
		Options	opt = {argc, (const char **) argv, "fpP:r,tvwx:y:"};
		opt.fetch ("fpPrtvwxy", optf, optp, optP, optr, optt, optv, optw, optx, opty);
		arglist = opt.arguments();
	}
	catch (exception &e) {
		cerr << "Error detected during command line processing:  " << e.what() << endl;
		cerr << usage_message;
		exit (EXIT_FAILURE);
	}

	if (optv) {
		cout << "km version " << version << " built " << build_id <<  " git hash " << git_id << endl;
	}

	// convert list<string> to set<string> for fast lookups
	for (auto &i : optr) {
		optr_set.insert (i);
	}

	if (arglist.size()) {
		for (auto &f : arglist) {
			ifstream s (f);
			if (!s.good()) {
				cerr << "Can't open " << f << " for read, " << errno << " (" << strerror (errno) << ")\n";
				exit (EXIT_FAILURE);
			}
			if (optv) {
				cout << "Processing " << f << ":\n";
			}
			SExpr *root = SExprReadStream (s);
			process (root);
			if (optw) write (f, root);

		}
	} else {
		if (optv) {
			cout << "Processing standard input:\n";
		}
		SExpr *root = SExprReadStream(cin);
		process (root);
		if (optw) write (cout, root);
	}

	exit (EXIT_SUCCESS);
}

