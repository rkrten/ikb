
/*
 *	proces.hpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module contains the manifest constants and declarations for
 *	the
 *
 *	2023 02 06	R. Krten		created
*/

bool process (SExpr *);
