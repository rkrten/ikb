
/*
 *	module.cpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module
 *
 *	2023 02 06	R. Krten		created
*/

#include "km.hpp"

