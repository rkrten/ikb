
/*
 *	options.cpp
 *
 *	(C) Copyright 2015 by Robert Krten, all rights reserved.
 *
 *	This is the library module for options processing, responsible for handling
 *	command line options.
 *
 *	2015 05 09	R. Krten		created
 *	2020 04 15	R. Krten		added -@filename automagic (recursive too!) additional options processing
*/

#include "options.hpp"
#include <iostream>

using namespace std;
//using namespace rkpp;

rkpp::Options::Options (int argc, const char *argv [], string optstring)
{
	argstart = 0;
	argcount = argc;
	arglist = argv;

	// separate out command line elements into those that take arguments (stored in opts and commas) and those that don't (stored in flags)
	for (unsigned i = 0; i < optstring.length(); i++) {
		// if there's nothing after the character, then it's a flag and we're done
		if (i + 1 >= optstring.length()) {
			flags += optstring [i];
			break;
		}

		// otherwise, there's something following it
		if (optstring [i + 1] == ':') {
			opts += optstring [i++];					// it's the ':' specifier, store it and skip it
		} else if (optstring [i + 1] == ',') {
			commas += optstring [i++];					// it's the ',' specifier, store it and skip it
		} else {
			flags += optstring [i];						// neither of those, so we're considering it to be a flag
		}
	}

	progname = argv [0];

	// populate the options vector with all found options, and sanity check against optstring
	for (argstart = 1; argstart < argc; argstart++) {
		if (argv [argstart][0] != '-') {				// no longer starts with a dash?
			break;										// then we're done processing options/flags
		}
		if (argv [argstart][1] == '-') {				// the magic "--"?
			argstart++;									// skip it
			break;										// another fine reason to be done with processing
		}

		for (int a = 1; argv [argstart][a]; a++) {
			if (flags.find_first_of (argv [argstart][a]) != string::npos) {			// is it a flag?
				options.push_back (make_tuple (argv [argstart][a], "", ""));
			} else if (opts.find_first_of (argv [argstart][a]) != string::npos
			       ||  commas.find_first_of (argv [argstart][a]) != string::npos
			       ||  argv [argstart][a] == '@') {		// is it an option (":" or "," kind) or the magic -@?
				if (argv [argstart][a + 1]) {			// is the argument immediately after the option letter?
					if (argv [argstart][a] == '@') {	// we handle -@ ourselves (this one has the filename immediately following)
						add_from_file (argv [argstart] + a + 1);
					} else {
						options.push_back (make_tuple (argv [argstart][a], "", argv [argstart] + a + 1));
					}
				} else {								// no, it's in the next argv
					if (argstart == argc - 1) {
						string x; x += argv [argstart][a];
						throw (runtime_error ("rkpp::options failed, option " + x + " expected an argument"));
					}
					char letter = argv [argstart++][a];
					if (letter == '@') {				// we handle -@ ourselves (this one has the filename as the next argv)
						add_from_file (argv [argstart]);
					} else {
						options.push_back (make_tuple (letter, "", argv [argstart]));
					}
				}
				break;
			} else {
				string x; x += argv [argstart][a];
				throw (runtime_error ("rkpp::options failed, option " + x + " is not valid, expected { " + optstring + " }"));
			}
		}
	}

//#define	DEBUG
#ifdef	DEBUG
	cout << "----------------------------" << endl;
	cout << "Parsed options vector tuples" << endl;
	for (auto &v : options) {
		cout << "  short [" << get<0>(v) << "], long [" << get<1>(v) << "], value [" << get<2>(v) << "]" << endl;
	}
	cout << "  flags [" << flags << "], commas [" << commas << "], and options [" << opts << "]" << endl;
	cout << "----------------------------" << endl;
#endif
}

bool
rkpp::Options::boolean (char letter)
{
	for (auto p : options) {
		if (letter == get<0>(p)) {
			return (true);
		}
	}
	return (false);
}

int
rkpp::Options::validate_integer (char letter, int mi, int ma)
{
	for (auto p : options) {
		if (letter == get<0>(p)) {
			int	val = stoi (get<2>(p));
			if (val < mi) {
				string x; x += get<0>(p);
				throw (runtime_error ("rkpp::options failed, option " + x + " value (" + to_string (val) + ") is smaller than the minimum value (" + to_string (mi) + ")"));
			}
			if (val > ma) {
				string x; x += get<0>(p);
				throw (runtime_error ("rkpp::options failed, option " + x + " value (" + to_string (val) + ") is bigger than the maximum value (" + to_string (ma) + ")"));
			}
			return (val);
		}
	}
	return (false);
}

double
rkpp::Options::validate_floating (char letter, double mi, double ma)
{
	for (auto p : options) {
		if (letter == get<0>(p)) {
			double val = stod (get<2>(p));

			if (val < mi) {
				string x; x += get<0>(p);
				throw (runtime_error ("rkpp::options failed, option " + x + " value (" + to_string (val) + ") is smaller than the minimum value (" + to_string (mi) + ")"));
			}
			if (val > ma) {
				string x; x += get<0>(p);
				throw (runtime_error ("rkpp::options failed, option " + x + " value (" + to_string (val) + ") is bigger than the maximum value (" + to_string (ma) + ")"));
			}
			return (val);
		}
	}
	string x; x = letter;
	throw (runtime_error ("rkpp::options failed, option " + x + " not found"));
}

int
rkpp::Options::count (char letter)
{
	int		count = 0;

	for (auto p : options) {
		if (letter == get<0>(p)) {
			count++;
		}
	}
	return (count);
}

void
rkpp::Options::mutex (string letters)
{
	char	found = 0;

	for (auto p : letters) {
		if (count (p)) {
			if (found) {
				string x; x += p;
				string y; y += found;
				throw (runtime_error ("rkpp::options failed, option " + x + " is mutually exclusive with option " + y));
			}
			found = p;
		}
	}
}

void
rkpp::Options::mandatory (string letters)
{
	for (auto p : letters) {
		if (!count (p)) {
			string x; x += p;
			throw (runtime_error ("rkpp::options failed, missing option " + x + " is mandatory"));
		}
	}
}

void
rkpp::Options::once (string letters)
{
	for (auto p : letters) {
		if (count (p) > 1) {
			string x; x += p;
			throw (runtime_error ("rkpp::options failed, option " + x + " can only be specified once"));
		}
	}
}

string
rkpp::Options::text (char letter)
{
	for (auto p : options) {
		if (letter == get<0>(p)) {
			return (get<2>(p));
		}
	}
	string x; x += letter;
	throw (runtime_error ("rkpp::options failed, option " + x + " not found"));
}

vector <string>
rkpp::Options::texts (char letter)
{
	vector <string>	result;

	for (auto p : options) {
		if (letter == get<0>(p)) {
			result.push_back (get<2>(p));
		}
	}
	return (result);
}

vector <string>
rkpp::Options::arguments (void)
{
	vector <string>	result;

	for (int i = argstart; i < argcount; i++) {
		result.push_back (arglist [i]);
	}
	return (result);
}

// fetches a string of characters, or a double-quoted string of characters with \" and \\ being interpreted correctly
static string
fetch_c_string (const char *&ptr)
{
	enum State { Idle, InString, InQuotedString, InEscape } state = Idle;

	string result;
	while (*ptr) {
		switch (state) {
		case	Idle:
			if (*ptr == '"') {
				state = InQuotedString;
			} else if (!isspace (*ptr)) {
				state = InString;
				result += *ptr;
			}
			break;

		case	InString:
			if (isspace (*ptr)) {
				ptr++;
				return (result);
			}
			result += *ptr;
			break;

		case	InQuotedString:
			if (*ptr == '"') {
				ptr++;
				return (result);
			}
			if (*ptr == '\\') {
				state = InEscape;
			}
			break;

		case	InEscape:
			if (*ptr == '\\') {
				result += '\\';
			} else {
				result += *ptr;
			}
			state = InQuotedString;
			break;
		}

		ptr++;
	}
	return (result);
}

#include <fstream>

void
rkpp::Options::add_from_file (const char *fname)
{

cout << "UNTESTED CODE BEING EXECUTED AT " << __FILE__ << " LINE " << __LINE__ << endl;
	ifstream input ((string (fname)));
	if (!input.is_open()) {
		throw (runtime_error ("rkpp::options -@" + string (fname) + " failed, can't open file"));
	}

	string line;
	vector <string> argvector;
	while (getline (input, line)) {
		const char *ptr = line.c_str();
		string s = fetch_c_string (ptr);
		while (s.size()) {
			argvector.push_back (s);
			s = fetch_c_string (ptr);
		}
	}

	if (argvector.size()) {
		const char **argv = (const char **) malloc (sizeof (const char *) * (argvector.size() + 1));
		argv [0] = progname.c_str();
		for (int i = 0; i < argvector.size(); i++) {
			argv [i + 1] = argvector [i].c_str();
		}
		Options (argvector.size() + 1, argv, "");
	}
}

// this is enabled automatically in the Makefile
#ifdef	SELFTEST

#include <iostream>
#include <list>
#include <string>

using namespace rkpp;

int
main (int argc, char **argv)
{
	const char	*av [] = { "./options", "-a", "5", "-b", "-v", "-c6", "-d", "7.5", "-v", "-v", "parm1", "parm2", "parm3" };
	int			ac = sizeof (av) / sizeof (av [0]);

	cout << "\n";
	cout << "*************************************\n";
	cout << "*** SELFTEST FOR MODULE \"Options\" ***\n";
	cout << "*************************************\n";

	Options		o1 = {ac, av, "a:bc:d:v"};

	// argstart test
	if (o1.parmstart () == 10) {
		cout << "CORRECT:  parmstart is 10\n";
	} else {
		cout << +"ERROR:   parmstart is " << o1.parmstart() << " but we expected 10\n";
	}

	// Boolean test
	if (o1.boolean ('v')) {
		cout << "CORRECT:  -v is specified\n";
	} else {
		cout << "ERROR:    -v is present, but not detected by library\n";
	}

	// argstart test
	if (o1.parmstart () == 10) {
		cout << "CORRECT:  parmstart is still 10\n";
	} else {
		cout << +"ERROR:   parmstart is " << o1.parmstart() << " but we expected 10\n";
	}

	// argument spread over two argv[] elements test
	if (o1.validate_integer ('a') == 5) {
		cout << "CORRECT:  -a has the value 5\n";
	} else {
		cout << "ERROR:    -a does not have the value 5 (it has the value " << o1.validate_integer ('a') << ")\n";
	}

	// argument immediately after option letter test
	if (o1.validate_integer ('c') == 6) {
		cout << "CORRECT:  -c has the value 6\n";
	} else {
		cout << "ERROR:    -c does not have the value 6 (it has the value " << o1.validate_integer ('c') << ")\n";
	}

	// integer argument range test with default initializer for maximum
	try {
		cout << "(expect -------> rkpp::options failed, option a value (5) is smaller than the minimum value (10)\n";
		o1.validate_integer ('a', 10);
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// integer argument range test for maximum value test
	try {
		cout << "(expect -------> rkpp::options failed, option a value (5) is bigger than the maximum value (2)\n";
		o1.validate_integer ('a', 1, 2);
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// floating point tests
	if (o1.validate_floating ('d') == 7.5) {
		cout << "CORRECT:  -d has the value 7.5\n";
	} else {
		cout << "ERROR:    -d does not have the value 7.5 (it has the value " << o1.validate_floating ('d') << ")\n";
	}

	// floating argument range test with default initializer for maximum
	try {
		cout << "(expect -------> rkpp::options failed, option d value (7.5) is smaller than the minimum value (10.1)\n";
		o1.validate_floating ('d', 10.1);
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// floating argument range test for maximum value test
	try {
		cout << "(expect -------> rkpp::options failed, option d value (7.5) is bigger than the maximum value (2.4)\n";
		o1.validate_floating('d', 1, 2.4);
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// count test
	if (o1.count ('v') == 3) {
		cout << "CORRECT:  -v is specified three times\n";
	} else {
		cout << "ERROR:    -v is specified three times,  but count returns " << o1.count ('v') << "\n";
	}

	// argument list test
	cout << "Argument list (should be parm1, parm2, parm3): ";
	for (auto &i : o1.arguments()) cout << i << ", ";
	cout << "\n";

	// missing argument test
	try {
		cout << "(expect -------> rkpp::options failed, option c expected an argument\n";

		const char	*av2 [] = { "./options", "-a", "5", "-b", "-v", "-c" };
		int			ac2 = sizeof (av2) / sizeof (av2 [0]);

		Options		o2 = {ac2, av2, "a:bc:v"};
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// mutex argument test
	try {
		cout << "(expect -------> rkpp::options failed, option b is mutually exclusive with option a\n";


		const char	*av3 [] = { "./options", "-a", "5", "-b", "-v", "-c", "75" };
		int			ac3 = sizeof (av3) / sizeof (av3 [0]);

		Options		o3 = {ac3, av3, "a:bc:v"};
		o3.mutex ("abc");
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// mandatory argument test
	try {
		cout << "(expect -------> rkpp::options failed, missing option b is mandatory\n";


		const char	*av4 [] = { "./options", "-a", "5", "-v", "-c", "75" };
		int			ac4 = sizeof (av4) / sizeof (av4 [0]);

		Options		o4 = {ac4, av4, "a:bc:v"};
		o4.mandatory ("b");
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	// once argument test
	try {
		cout << "(expect -------> rkpp::options failed, option v can only be specified once\n";


		const char	*av5 [] = { "./options", "-a", "5", "-v", "-c", "75", "-v", "-v" };
		int			ac5 = sizeof (av5) / sizeof (av5 [0]);

		Options		o5 = {ac5, av5, "a:bc:v"};
		o5.once ("v");
	}
	catch (exception &e) {
		cout << "Caught exception " << e.what() << "\n";
	}

	if (o1.text ('a') == "5") {
		cout << "CORRECT:  -a has the string value \"5\"\n";
	} else {
		cout << "ERROR:    -a does not have the string value \"5\", but instead has \"" << o1.text ('a') << "\"\n";
	}

	// fetcher test
	const char			*av6 [] = { "./options", "-a", "val1", "-d12.12", "-v", "-b", "val2", "-b", "val3", "-v", "-b", "val4", "-a", "val5", "-x", "val6", "-j", "3", "-i", "7", "-i", "8", "-i", "9", "-vv" };
	int					ac6 = sizeof (av6) / sizeof (av6 [0]);
	vector <string>		o6a;
	list <string>		o6b;
	double				o6d = 999.999;
	vector <int>		o6i;
	int					o6j = 999;
	int					o6v = 0;
	int					o6w = 0;
	string				o6x = "initialized, but not processed";

	cout << "Options input:  " ; for (auto p : av6) cout << p << " "; cout << "\n";
	Options		o6 = {ac6, av6, "a:b:d:i:j:x:vw"};
	o6.fetch ("abdijvwx", o6a, o6b, o6d, o6i, o6j, o6v, o6w, o6x);

	cout << "Expecting a = {\"val1\", \"val5\"}, b = {\"val2\", \"val3\", \"val4\"}, d = 12.12, i = {7, 8, 9}, j = 3, v = 4, w = 0, x = \"val6\"\n";
	cout << "a is { "; for (auto p : o6a) cout << p << " "; cout << "}" << endl;
	cout << "b is { "; for (auto p : o6b) cout << p << " "; cout << "}" << endl;
	cout << "d is " << o6d << "\n";
	cout << "i is { "; for (auto p : o6i) cout << p << " "; cout << "}" << endl;
	cout << "j is " << o6j << "\n";
	cout << "v is " << o6v << "\n";
	cout << "w is " << o6w << "\n";
	cout << "x is " << o6x << "\n";

	// bool increment test
	const char *av7 [] = { "./options", "-v", "-v", "-vv" };
	int ac7 = sizeof (av7) / sizeof (av7 [0]);
	Options o7 (ac7, av7, "v");
	bool ov7bool = false;
	o7.fetch ("v", ov7bool);
	cout << "Specifying a bool multiple times yields " << ov7bool << " (we expected true)\n";

	// comma test
	const char *av8 [] = { "./options", "-a1,2", "-a", "3", "-a4,5" };
	int ac8 = sizeof (av8) / sizeof (av8 [0]);
	Options o8 (ac8, av8, "a,");
	vector <string> ov8string;
	o8.fetch ("a", ov8string);
	cout << "Using the new-fangled , operator gives us the argument list { ";
	for (auto &a : ov8string) cout << a << " ";
	cout << "}" << endl;
	cout << "Expected { 1 2 3 4 5 }" << endl;

	const char *av9 [] = { "./options", "-v", "-a1,2,3" };
	int ac9 = sizeof (av9) / sizeof (av9 [0]);
	Options o9 (ac9, av9, "a,v");
	vector <string> ov9string;
	int ov9int = 0;
	o9.fetch ("av", ov9string, ov9int);
	cout << "Mixing a,v with v first gives -v " << ov9int << " and { ";
	for (auto &a : ov9string) cout << a << " ";
	cout << "}" << endl;
	cout << "Expected 1 and 1,2,3" << endl;

	const char *av10 [] = { "./options", "-a1,2,3", "-v" };
	int ac10 = sizeof (av10) / sizeof (av10 [0]);
	Options o10 (ac10, av10, "a,v");
	vector <string> ov10string;
	int ov10int = 0;
	o10.fetch ("av", ov10string, ov10int);
	cout << "Mixing a,v with a first gives -v " << ov10int << " and { ";
	for (auto &a : ov10string) cout << a << " ";
	cout << "}" << endl;
	cout << "Expected 1 and 1,2,3" << endl;

}

#endif	// SELFTEST

