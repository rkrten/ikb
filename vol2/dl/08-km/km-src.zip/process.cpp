
/*
 *	process.cpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module contains the KiCad Move processing logic.
 *
 *	2023 02 06	R. Krten		created
*/

#include "km.hpp"

#define	V8

map <string, SExpr *> footprints;						// map of reference -> footprint associations (e.g., { {D100, ptr}, {D101, ptr}, {D102, ptr} ... } )

static bool
verify_version (SExpr *root)
{
	SExpr *version = find (find (root, "kicad_pcb"), "version");
	if (version) {
		if (optv) {
			cout << "Processing version " << version -> value (0) << " file\n";
		}
#ifdef	V8
		return version -> value (0) >= "20240108";
#else	// V8
		return version -> value (0) >= "20211014";
#endif	// V8
	}
	return false;
}

static void
map_footprints (SExpr *root)
{
	Slist feet = find_all (find (root, "kicad_pcb"), "footprint");

	for (auto &f : feet) {
#ifdef	V8
		for (auto &t : find_all (f, "property")) {
			if (t -> value (0) == "\"Reference\"") {
				string reference = t -> value(1);
				reference = reference.substr (1, reference.length() - 2);
				if (optr_set.empty() || optr_set.find (reference) != optr_set.end()) {
					footprints [reference] = f;
				}
				break;									// we don't care about any other "fp_text" elements
			}
		}
#else	// V8
		for (auto &t : find_all (f, "fp_text")) {
			if (t -> value (0) == "reference") {
				string reference = t -> value(1);
				reference = reference.substr (1, reference.length() - 2);
				if (optr_set.empty() || optr_set.find (reference) != optr_set.end()) {
					footprints [reference] = f;
				}
				break;									// we don't care about any other "fp_text" elements
			}
		}
#endif	// V8
	}
}

// convert "SW12" -> "SW"
static string
reftype (string ref)
{
	return ref.substr (0, ref.find_first_of ("0123456789"));
}

static void
show_footprints (void)
{
	string type = reftype (footprints.begin()->first);

	for (auto & f : footprints) {
		string candidate = reftype (f.first);

		if (candidate != type) {
			cout << "\n";
			type = candidate;
		}
		cout << f.first << " ";
	}
	cout << "\n";
}

static void
move_footprint (SExpr *footprint, double x, double y, double r)
{
	for (auto & a : footprint->children()) {
//cout << "a: " << a -> name() << "\n";
		if (a -> name() == "at") {						// top level at
			int i;
			Slist::iterator it;
			Slist &members = a->children();
			for (i = 0, it = members.begin(); it != members.end(); ++it, i++) {
				if (i == 0) {
					(*it) -> name(to_string (x));
				} else if (i == 1) {
					(*it) -> name(to_string (y));
				} else if (i == 2) {
					break;
				}
			}
			if (it != members.end()) {
				string s = (*it) -> name();
				if (isdigit (s [0]) || s[0] == '-') {
					(*it) -> name(to_string (fmod (stod (s) + r, 360.)));
				} else {
					(a->children()).insert (it, new SExpr {to_string (r)});
				}
			} else {
				a->children().push_back (new SExpr { to_string (r) });
			}
		}
		for (auto & b : a -> children()) {
//cout << "b: " << b -> name() << "\n";
			if (b->name() == "at") {

				// duplicate-ish; we should recurse!
				int i;
				Slist::iterator it;
				Slist &members = b->children();
				for (i = 0, it = members.begin(); it != members.end(); ++it, i++) {
					if (i == 0) {
					} else if (i == 1) {
					} else if (i == 2) {
						break;
					}
				}
				if (it != members.end()) {
					string s = (*it) -> name();
					if (isdigit (s [0]) || s [0] == '-') {
						(*it) -> name(to_string (fmod (stod (s) + r, 360.)));
					} else {
						(b->children()).insert (it, new SExpr {to_string (r)});
					}
				} else {
					b->children().push_back (new SExpr { to_string (r) });
				}
			}
		}
	}
}

static bool
is_dimensionable (string v)
{
	static string dimensionables [] =
	{
		"fp_arc",
		"fp_circle",
		"fp_line",
		"fp_poly",
		"fp_rect",
		"pad",
	};

	for (auto &s : dimensionables) {
		if (s == v) {
			return true;
		}
	}
//cout << v << " is not dimensionable, right?\n";
	return false;
}

struct Boundaries
{
	void xy (double x1, double y1, double x2, double y2)
	{
		if (!initialized) {
			minx = min (x1, x2);
			maxx = max (x1, x2);
			miny = min (y1, y2);
			maxy = max (y1, y2);
			initialized = true;
		}  else {
			minx = min (minx, min (x1, x2));
			maxx = max (maxx, max (x1, x2));
			miny = min (miny, min (y1, y2));
			maxy = max (maxy, max (y1, y2));
		}
	}

	double xsize (void)
	{
		return maxx - minx;
	}

	double ysize (void)
	{
		return maxy - miny;
	}

	Boundaries &
	operator+= (const Boundaries &rhs) {
		if (!this -> initialized) {
			this -> minx = rhs.minx;
			this -> maxx = rhs.maxx;
			this -> miny = rhs.miny;
			this -> maxy = rhs.maxy;
			this -> initialized = true;
		} else {
			this -> minx = min (minx, rhs.minx);
			this -> maxx = max (maxx, rhs.maxx);
			this -> miny = min (miny, rhs.miny);
			this -> maxy = max (maxy, rhs.maxy);
		}
		return *this;
	}

	string info (void) {
		stringstream s;
		if (!initialized) {
			s << "** not initialized **";
		} else {
			s << "{ (" << minx << ", " << miny << ") -> (" << maxx << ", " << maxy << ") size (" << xsize() << " x " << ysize() << ") }";
		}
		return s.str();
	}

	bool initialized = false;
	double minx;
	double maxx;
	double miny;
	double maxy;
};

// finds fp_text followed by reference
static SExpr *
find_fp_text (SExpr *base, string ttype)
{
	bool have_ref = false;
//	cout << "{{ ";
	for (auto &i : base -> children()) {
#ifdef	V8
		if (i -> name() == "property") {
			for (auto & j : i -> children()) {
				if (have_ref) {
					return (j);
				}
				if (j -> name() == "\"Reference\"") {
					have_ref = true;
				}
			}
		}
#else	// V8
		if (i -> name() == "fp_text") {
			for (auto & j : i -> children()) {
//				cout << j -> name();
				if (!j -> children().empty()) {
//					cout << "+";
				}
//				cout << " ";
				if (have_ref) {
//					cout << "}}";
					return (j);
				}
				if (j -> name() == "reference") {
					have_ref = true;
				}
			}
		}
#endif	// V8
	}
	return NULL;
}

static void
fetch2(SExpr *s, double &a, double &b)
{
	Slist base = s -> children();
	Slist::iterator it;
	it = base.begin();
	a = stod ((*it) -> name());
	++it;
	b = stod ((*it) -> name());
}

static Boundaries
compute_bounding_box (SExpr *v)
{
	Boundaries result;
	string type = v -> name();

//cout << "compute_bounding_box for " << type << " " << find_fp_text (v, "reference") -> name() <<":\n";

	for (auto & i : v -> children()) {
		if (!is_dimensionable (i -> name())) continue;
//cout << "  " << i -> name() << ":";
		if (i -> name() == "fp_rect" || i -> name() == "fp_line") {
			// (fp_rect (start) (end) )
			SExpr *start = find (i, "start");
			SExpr *end = find (i, "end");
			if (start && end) {
				double x1, y1, x2, y2;
				fetch2 (start, x1, y1);
				fetch2 (end, x2, y2);
				result.xy (x1, y1, x2, y2);
//cout << "\n  + start/end @ (" << x1 << ", " << y1 << ") - (" << x2 << ", " << y2 << ") -> { " << result.info() << " size " << result.xsize() << " x " << result.ysize() << " }\n";
			}
		} else if (i -> name() == "pad") {
			// (pad (at) (size) )
			SExpr *at = find (i, "at");
			SExpr *size = find (i, "size");
			if (at && size) {
				double xc, yc, xs, ys;
				fetch2 (at, xc, yc);
				fetch2 (size, xs, ys);
				result.xy (xc - xs / 2, yc - ys / 2, xc + xs / 2, yc + ys / 2);
//cout << "\n  + at/size @ (" << xc << ", " << yc << ") diam (" << xs << ", " << ys << ") -> { " << result.info() << " size " << result.xsize() << " x " << result.ysize() << " }\n";
			}
		} else if (i -> name() == "fp_circle") {
    			// (fp_circle (center) (end) )
			SExpr *center = find (i, "center");
			SExpr *end = find (i, "end");
			if (center && end) {
				double xc, yc, xe, ye;
				fetch2 (center, xc, yc);
				fetch2 (end, xe, ye);
				result.xy (xc, yc, xc + xe, yc + ye);
//cout << "\n  + center/end @ (" << xc << ", " << yc << ") end (" << xe << ", " << ye << ") -> { " << result.info() << " size " << result.xsize() << " x " << result.ysize() << " }\n";
			}
		} else if (i -> name() == "fp_poly") {
    			// (fp_poly (pts (xy) (xy) ... ) )
    			SExpr *pts = find (i, "pts");
    			if (pts) {
    				int npoints = 0;
    				for (auto &xy : pts -> children()) {
    					if (xy -> name() == "xy") {
    						double x, y;
    						fetch2 (xy, x, y);
    						result.xy (0, 0, x, y);
					}
					npoints++;
				}
//cout << "\n  + poly/pts (" << npoints << " points) { " << result.info() << " size " << result.xsize() << " x " << result.ysize() << " }\n";
			}
		} else if (i -> name() == "fp_arc") {
			// (fp_arc (start) (mid) (end) )
			SExpr *arc [3];
			arc [0] = find (i, "start");
			arc [1] = find (i, "start");
			arc [2] = find (i, "start");
			if (arc [0] && arc [1] && arc [2]) {
				for (int i = 0; i < NELEMENTS(arc); i++) {
					double x, y;
					fetch2 (arc [i], x, y);
					result.xy (0, 0, x, y);
				}
//cout << "\n  + start/mid/end { " << result.info() << " size " << result.xsize() << " x " << result.ysize() << " }\n";
			} else {
				cout << "Unhandled " << i->name() << "\n";
			}
		}
	}
//cout << "-> " << result.info() << "\n\n";
	return result;
}

static void
tabularize (void)
{
	double xposition = optx;
	double yposition = opty;
	double max_width = 0;

	for (auto & f : footprints) {
		Boundaries result = compute_bounding_box (f.second);
//cout << "Part " << f.first << " " << result.info() << " moves to position " << xposition << ", " << yposition << " (minx " << result.minx << ", miny " << result.miny << ")\n";
		move_footprint (f.second, xposition - result.minx, yposition - result.miny, 0);
		yposition += result.ysize() + 1;
		if (result.xsize() > max_width) {
			max_width = result.xsize();
//cout << "  (new max width " << max_width << ")\n";
		}
		if (yposition > 200) {
			xposition += max_width + 1;
			yposition = opty;
			max_width = 0;
//cout << "  (new column)\n";
		}
	}
}

/*
 *	Pattern: ring
 *		r=radius   -- distance from center (x and y basis) to component (default 0)
 *		s=stepsize -- number of degrees to add to each component (default 360 / # value in -r)
 *		i=initial  -- initial degree (default zero)
 *		c=rotation -- component rotation (added to ring rotation)
*/

static void
pattern_ring (list<string> args)
{
	double radius = 0;
	double stepsize = 360. / optr.size();
	double i = 0;
	double add = 0;

cout << "RING\n";
	for (auto &s : args) {
		switch (s [0]) {
		case	'r':
			radius = stod (s.substr(2));
			break;

		case	's':
			stepsize = stod (s.substr(2));
			break;

		case	'i':
			i = stod (s.substr(2));
			break;

		case	'c':
			add = stod (s.substr(2));
			break;

		default:
			cerr << "Unknown radius option \"" << s << "\"\n";
			exit (EXIT_FAILURE);
		}
	}

cout << "EXECUTE RADIUS (radius=" << radius << ", stepsize=" << stepsize << ", initial=" << i << ", +component=" << add << ")\n";

	double x, y;
	for (auto & footprint : optr) {
		if (footprints.find (footprint) == footprints.end()) {
			cerr << "Specified footprint \"" << footprint << "\" not in PCB\n";
			exit (EXIT_FAILURE);
		}
		auto &f = footprints [footprint];
		x = radius * sin (i / 180. * M_PI);
		y = radius * cos (i / 180. * M_PI);
		Boundaries b = compute_bounding_box (f);
cout << "Moving footprint " << footprint << " to (" << x << " {" << x-b.minx << "}, " << y << " {" << y-b.miny << "} angle " << fmod (i + add, 360.) << "\n";
		move_footprint (f, x, y, fmod (i + add, 360.));
		i += stepsize;
	}
}

static void
pattern (void)
{
	int pos = optP.find_first_of (",");
	string command;
	list <string> arguments;
	if (pos < optP.size()) {
		command = optP.substr (0, pos);

		string each;
		stringstream ss (optP.substr (pos + 1));
		while (getline (ss, each, ',')) {
			arguments.push_back (each);
		}
	} else {
		command = optP;
	}
	cout << "Command " << command << "\n";

	if (command == "ring") {
		pattern_ring (arguments);
	}
}

bool
process (SExpr *root)
{
	if (!verify_version (root)) {
		cerr << "Invalid version, we support 20211014 and up only\n";
		return false;
	}

	if (optp) {
		for (auto &i : root->children()) {
			cout << SExprDump (i) << "\n";
		}
	}

	map_footprints (root);

	if (optP.size()) pattern ();
	if (optt) tabularize ();
	if (optf) show_footprints ();

	footprints.clear();

	return true;
}

