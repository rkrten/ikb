
/*
 *	sexpr.cpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module
 *
 *	2023 02 06	R. Krten		created
*/

#include "km.hpp"

struct SToken
{
	SToken (istream &s) : stream_ {s} {};

	string
	token (void)
	{
		string result;
		enum { Initial, Accumulating, AccumulatingQuoted } state = Initial;

		char ch;
		while (stream_.get (ch)) {
			switch (state) {
			case	Initial:
				if (ch == '(' || ch == ')') {
					result = ch;
					return (result);
				}
				if (!isspace (ch)) {
					result += ch;	// save the double quote; it tells us it's a string
					if (ch == '"') {
						state = AccumulatingQuoted;
					} else {
						state = Accumulating;
					}
				}
				break;

			case	Accumulating:
				if (isspace (ch) || ch == ')') {
					stream_.putback (ch);
					return (result);
				}
				result += ch;
				break;

			case	AccumulatingQuoted:
				result += ch;
				if (ch == '"') {
					state = Accumulating;
				}
				// escaping, e.g. '"', is done with '{dblquote}' instead of '\"'. Sadly, they don't escape "{", so literally putting in "{dblquote}" magically turns that text into a double quote. Sigh. Quoting and escaping is hard.
				break;

			}
		}
		return (result);
	}

	bool
	eof (void)
	{
		return (stream_.eof());
	}

private:
	istream &stream_;
};

static SExpr *
SExprReadObject (SToken &input, SExpr *parent = NULL)
{
	SExpr *result = new SExpr;

	string token = input.token();
	if (token == ")") {
		return NULL;
	}

	if (token != "(") {
		result -> name (token);
		result -> parent (parent);
		return result;
	}

	result -> name (input.token());
	result -> parent (parent);
	while (!input.eof()) {
		SExpr *value = SExprReadObject (input, result);
		if (value) {
			result -> add (value);
		} else {
			break;
		}
	}
	return result;
}

SExpr *
SExprReadStream (istream &s)
{
	SToken input (s);
	SExpr *root = new SExpr { "root" };
	while (!input.eof()) {
		root -> add (SExprReadObject (input, root));
	}
	return (root);
}

string
SExprDump (SExpr * sexpr, int indent)
{
	stringstream result;

	if (!sexpr -> children().empty()) {
		result << "\n" << (indent == 1 ? "\n" : "") << string (indent * 2, ' ') << "(" << sexpr -> name();
		for (auto & contents : sexpr ->children()) {
			result << SExprDump (contents, indent + 1);
		}
		result << ")";
	} else {
		result << " " << sexpr -> name();
	}
	return (result.str());
}

void
write (ostream &o, SExpr *root)
{
	for (auto &i : root->children()) {
		o << SExprDump (i) << "\n";
	}
}

void
write (string &f, SExpr *root)
{
	cout << "write " << f << "\n";
	ofstream out (f);
	if (!out.good()) {
		cerr << "Can't open " << f << " for write, " << errno << " (" << strerror (errno) << ")\n";
		exit (EXIT_FAILURE);
	}
	write(out, root);
}

SExpr *
find (SExpr *base, string name)
{
	if (!base) {
		return NULL;
	}

	if (base->name() == name) {
		return base;
	}
	for (auto &i : base -> children()) {
		SExpr *r = find (i, name);
		if (r) {
			return r;
		}
	}
	return NULL;
}

Slist
find_all (SExpr *base, string name)
{
	Slist result;
	if (!base) return result;;

	for (auto &r : base->children()) {
		if (r->name() == name) {
			result.push_back (r);
		}
	}
	return result;
}

