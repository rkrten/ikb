
/*
 *	sexpr.hpp
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *	Use subject to terms in LICENSE file.
 *
 *	This module contains the manifest constants and declarations for
 *	the S-Expression handlers.
 *
 *	2023 02 06	R. Krten		created
*/

/*
 *	S-Expr parsing
 *
 *	An S-Expr consists of a number of objects arranged in an arbitrary hierarchy.
 *
 *	Here's an example:
 *
 *		(kicad_pcb
 *		  (version 20211014)
 *		  (generator pcbnew)
 *		  (general
 *		    (thickness 1.6)
 *		  )
 *		  (paper "A4")
 *		  (layers
 *		    (0 "F.Cu" signal)
 *		    (31 "B.Cu" signal)
 *		    ...
 *		  )
 *		  ...
 *		)
 *
 *	We want to be able to get at any object at any depth, therefore we use pointers
 *	to the objects. The pointer is an "SExpr *" -- that is, it points to a name and
 *	a list of optional children.
*/

struct SExpr;
typedef list <SExpr *> Slist;

struct SExpr
{
	SExpr (void) {}

	SExpr (string s)
	{
		name_ = s;
	}

	SExpr (string n, Slist c)
	{
		name_ = n;
		children_ = c;
	}

	string name (void) { return name_; }
	void name (string v) { name_ = v; }

	Slist &children (void) { return children_; }
	void add (SExpr *v) { children_.push_back (v); }

	void parent (SExpr *p) { parent_ = p; }
	SExpr *parent (void) { return parent_; }

	string
	value (unsigned index)
	{
		// children are stored in a list, so we need to iterate
		Slist::iterator it;
		for (it = children_.begin(); it != children_.end(); ++it) {
			if (index-- == 0) {
				return (*it)->name();
			}
		}
		return "";
	}

private:
	string name_;
	Slist children_;
	SExpr *parent_ = NULL;
};

SExpr *SExprReadStream (istream &s);
string SExprDump (SExpr *, int indent=0);

void write (ostream &, SExpr *);
void write (string &, SExpr *);

SExpr * find (SExpr *base, string name);
Slist find_all (SExpr *base, string name);
