
/*
 *	options.hpp
 *
 *	(C) Copyright 2015, Robert Krten.  All rights reserved.
 *
 *	This is the public include file for options processing from the RK++ library.
 *
 *	2015 05 09	R. Krten		created.
*/

#ifndef	__LIBRKPP__OPTIONS__
#define	__LIBRKPP__OPTIONS__

#include <string>
#include <vector>
#include <list>
#include <tuple>
#include <limits>
#include <iostream>
#include <sstream>

namespace rkpp {

	using namespace std;								// restricted to within namespace rkpp
	using namespace rkpp;

	class Options
	{
	public:
		/* constructor */	Options (int argc, const char *argv[], string optstring);
		/* constructor */	Options (void) : argstart {0} { };

		bool				boolean (char letter);
		int					count (char letter);
		double				validate_floating (char letter, double minimum = numeric_limits<double>::min(), double maximum = numeric_limits<double>::max());
		double				validate_floating (string letters, double minimum = numeric_limits<double>::min(), double maximum = numeric_limits<double>::max());
		int					validate_integer (char letter, int minimum = numeric_limits<int>::min(), int maximum = numeric_limits<int>::max());
		int					validate_integer (string letters, int minimum = numeric_limits<int>::min(), int maximum = numeric_limits<int>::max());
		void				mutex (string letters);
		void				mandatory (string letters);
		void				once (string letters);
		int					parmstart (void) { return argstart; }
		string				text (char letter);			// return one option (letter) as a string
		void				text (string letters, ...);
		void				text (string, vector <string *>);// return multiple option (string) into corresponding vector members
		vector <string>		texts (char letter);		// return multiple instances of one option (letter) as a vector strings
		vector <string>		arguments (void);			// return all arguments as a string vector

		// the final (bogus) one
		void fetch (const string s) { }

		// the scalar version (generic version)
		template <typename Containee, typename... Args>
			void
			fetch (const string s, Containee &value, Args&... args)
			{
				for (auto p : options) {
					if (s [0] == get<0>(p)) {
						if (flags.find_first_of (s [0]) != string::npos) {			// is it a flag?
//							int tmp = value; tmp++; value = tmp;					// gets around warning of "incrementing a bool" being deprecated (shouldn't be a problem for other non-ints, because we don't have them as flags)
							value++;
						} else {													// then it must be a comma or a colon, but with a scalar, we can't comma split anyway.
							value = fetch_value (get<2>(p), value);
							break;
						}
					}
				}
				return fetch (s.substr (1), args...);
			}

		// the scalar version (bool specialization)
		template <typename... Args>
			void
			fetch (const string s, bool &value, Args&... args)
			{
				for (auto p : options) {
					if (s [0] == get<0>(p)) {
						if (flags.find_first_of (s [0]) != string::npos) {			// is it a flag?
							value = true;
						} else {													// then it must be a comma or a colon, but with a scalar, we can't comma split anyway.
							value = fetch_value (get<2>(p), value);
							break;
						}
					}
				}
				return fetch (s.substr (1), args...);
			}

		// the scalar version (string specialization)
		template <typename... Args>
			void
			fetch (const string s, string &value, Args&... args)
			{
				for (auto p : options) {
					if (s [0] == get<0>(p)) {
						value = get<2>(p);
						break;
					}
				}
				return fetch (s.substr (1), args...);
			}


		// the container version
		template <typename Containee, template <typename, typename...> class Container, typename... Args>
			void
			fetch (const string s, Container<Containee> &value, Args&... args)
			{
				for (auto p : options) {
					if (s [0] == get<0>(p)) {
						Containee v;
						if (commas.find_first_of (s [0]) != string::npos) {
							stringstream ss (get<2>(p));
							string each;
							while (getline (ss, each, ',')) {
								v = fetch_value (each, v);
								value.push_back (v);
							}
						} else {
							v = fetch_value (get<2>(p), v);
							value.push_back(v);
						}
					}
				}
				return fetch (s.substr (1), args...);
			}

	private:
		void			add_from_file (const char *fname);	// adds options from file
		bool			fetch_value (string value, bool &result) { return (result ? true : false); }
		char			fetch_value (string value, char &result) { return (value [0]); }
		int				fetch_value (string value, int &result) { return (stoi (value)); }
		double			fetch_value (string value, double &result) { return (stod (value)); }
		string			fetch_value (string value, string &result) { return (value); }

		int					argstart;					// tells us where arguments start
		int					argcount;					// cached value of argc
		const char			**arglist;					// cached value of argv
		vector <tuple <char, string, string>> options;	// holds the collection of arguments (char), long option name (string) (if any, future) and arguments (string) (if any)
		string				flags;						// string of flags (e.g., "abdh" if constructor given "abc:de:f:g:h")
		string				opts;						// string of options (e.g., "cefg" if constructor given "abc:de:f:g:h")
		string				commas;						// string of options that comma separate (e.g., "gkq" if constructor given "ab:c:def:g,jk,lmq,r")
		string				progname;					// raw value of argv[0]
	};

}

#endif	// __LIBRKPP__OPTIONS__

