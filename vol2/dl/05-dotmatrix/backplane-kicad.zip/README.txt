In production 2026 06 15
Received 2026 06 27

Panelizing them yourself is fine; but next time put silk screen cuts on BOTH sides, and maybe make the fill zone exclusions around the cuts just a touch bigger.

A high-TPI saw blade is the trick; your jigsaw blade was completely dull.

For the next rev, add 3V3 <-> 5V level shifter backpack, and 220 uF capacitor hole.


