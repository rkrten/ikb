
/*
 *	Copyright (C) 2025 Rob Krten, all rights reserved.
 *
 *	Include file for IKCH31I 247 LED clock driver.
*/

#include "gps.h"
#include "moon.h"

#define	NELEMENTS(_x)	(sizeof ((_x)) / sizeof ((_x) [0]))

/*
 *	Hardware map (all pins active high unless otherwise noted)
 *
 *	Pin		Name	I/O		Function
 *	 1		TX0		O		Transmit serial, goes to GPS but not used
 *	 2		RX0		I		Receive serial, 96008N1
 *	 4		GP2		O		ADDR0 common cathode address bit 0
 *	 5		GP3		O		ADDR1 common cathode address bit 1
 *	 6		GP4		O		ADDR2 common cathode address bit 2
 *	 7		GP5		O		MINUTES decoder enable
 *	 9		GP6		O		HOURS decoder enable
 *	10		GP7		O		SECONDS decoder enable
 *	11		GP8		O		2SECONDS decoder enable
 *	12		GP9		O		Common anode 7 drive
 *	15		GP10	O		Common anode 6 drive
 *	14		GP11	O		Common anode 5 drive
 *	16		GP12	O		Common anode 4 drive
 *	17		GP13	O		Common anode 3 drive
 *	19		GP14	O		Common anode 2 drive
 *	20		GP15	O		Common anode 1 drive
 *	21		GP16	O		Common anode 0 drive
 *	22		GP17	I		SENSE input
 *	24		SDA1	I/O		SDA1
 *	25		SCL1	I/O		SCL1
 *	26		SDA0 	I/O		SDA0
 *	27		SCL0	I/O		SCL0
 *	29		GP22	O		WS2812 moon phase complication
 *	31		ADC0	I		ADC0
 *	32		ADC1	I		ADC1
 *	34		ADC2	I		ADC2
*/


#define	MINUTES_ENABLE		5
#define	HOURS_ENABLE		6
#define	SECONDS1_ENABLE		7
#define	SECONDS2_ENABLE		8

#define	ANODE0				16
#define	ANODE1				15
#define	ANODE2				14
#define	ANODE3				13
#define	ANODE4				12
#define	ANODE5				11
#define	ANODE6				10
#define	ANODE7				9

#define	ADDR0				2
#define	ADDR1				3
#define	ADDR2				4

#define	SENSE				17

#define	SERIAL_TX_PIN		0
#define	SERIAL_RX_PIN		1

#define	WS2812				22

