
/*
 *	Function to compute moon phase.
 *
 *	Stolen from https://github.com/faytor/moon_phase_calculator/blob/master/moon_phase_calculator/moon_phase_calculator.ino
 *
 *	To run from commandline, compile with -DTEST
*/

#ifdef	TEST
#include <stdio.h>
#include <stdlib.h>
#endif	// TEST

#include <math.h>

static int timeZone = 0;

static double
proper_ang (double big)
{
	double tmp = 0;

	if (big > 0) {
	  tmp = big / 360.0;
	  tmp = (tmp - floor(tmp)) * 360.0;
	} else {
	  tmp = ceil(fabs(big / 360.0));
	  tmp = big + tmp * 360.0;
	}

	return tmp;
}

static double
julianDat (int year, int month, int day)
{
  double  zone = -(timeZone * 60 / 1440.0);

  if (month <= 2) {
	year -= 1;
	month += 12;
  }

//  double day2 = day + zone + 0.5;
  double day2 = day;	// RK -- removed timezone and mid-day correction; we're trying to blend on an hourly basis
  double A = floor(year / 100.0);
  double B = 2 - A + floor(A / 4.0);
  double JD = floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + day2 + B - 1524.5;

  return JD;
}

// returns 0..27, 14 == full moon

int
moonPhases (int year, int month, int day)
{
	double jd = julianDat(year, month, day);  // calculate Julian Date
	float dr = M_PI / 180.0;
	float rd = 1 / dr;
	unsigned long meeDT = pow(jd - 2382148, 2) / 41048480 / 86400;
	double meeT = (jd + meeDT - 2451545.0) / 36525;
	unsigned long meeT2 = pow(meeT, 2);
	unsigned long meeT3 = pow(meeT, 3);
	double meeD = 297.85 + (445267.1115 * meeT) - (0.0016300 * meeT2) + (meeT3 / 545868);

	meeD = proper_ang(meeD) * dr;

	double meeM1 = 134.96 + (477198.8676 * meeT) + (0.0089970 * meeT2) + (meeT3 / 69699);

	meeM1 = proper_ang(meeM1) * dr;

	double meeM = 357.53 + (35999.0503 * meeT);

	meeM = proper_ang(meeM) * dr;

	double elong = meeD * rd + 6.29 * sin(meeM1);

	elong = elong - 2.10 * sin(meeM);

	elong = elong + 1.27 * sin(2 * meeD - meeM1);

	elong = elong + 0.66 * sin(2 * meeD);

	elong = proper_ang(elong);

	elong = round(elong);

	double moonNum = ((elong + 6.43) / 360) * 28;

	moonNum = floor(moonNum);

	if (moonNum == 28) {
		moonNum = 0;
	}

	return moonNum;
}

#ifdef	TEST
int
main (int argc, char **argv)
{
	if (argc != 4) {
		fprintf (stderr, "moon: arguments are y m d\n");
		exit (EXIT_FAILURE);
	}

	int y, m, d;
	y = atoi (argv [1]);
	m = atoi (argv [2]);
	d = atoi (argv [3]);

	printf ("For %04d-%02d-%02d the moon phase is %d\n", y, m, d, moonPhases (y, m, d));
}
#endif	// TEST
