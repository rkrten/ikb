
/*
 *	mmon.h
 *
 *	(C) Copyright 2025 Rob Krten, all rights reserved.
 *
 *	Manifests for the moon computation
*/

// returns 0..27, 14 == full moon

int moonPhases (int year, int month, int day);

