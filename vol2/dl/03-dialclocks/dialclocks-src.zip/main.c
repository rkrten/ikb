
/*
 *	Copyright (C) 2025 Rob Krten, all rights reserved.
 *
 *	Program to control the IKCH31I 247 LED clock project.
 *
 *	At the highest level, it's a loop that does the following:
 *		- processes a subset of NMEA GPS data on the serial port
 *		- updates the LED display
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include "pico/stdlib.h"

#include "ikch31i.h"
#include "ws2812.pio.h"
#include "version.h"

// inputs (require pulldowns)
static unsigned inputs [] = { SENSE };					// list of inputs we want initialized

// outputs
static unsigned cathodes [] = { ADDR0, ADDR1, ADDR2 };	// cathode address bits, ordered in bit number (i.e., [0] is 0x01 bit)

// 3-to-8 line decoder enables for hours, minutes, and seconds; ordering is made to correspond to "CONFIG 1" through "CONFIG 4" jumpers on board
static unsigned decoder_enables [] = { SECONDS2_ENABLE, SECONDS1_ENABLE, HOURS_ENABLE, MINUTES_ENABLE };

// anodes
static unsigned anodes [] = { ANODE0, ANODE1, ANODE2, ANODE3, ANODE4, ANODE5, ANODE6, ANODE7 };

/*
 *	configs []
 *
 *	The configuration jumpers on the board.
 *	Identified as "CONFIG 1" through "CONFIG 4" on IKCH31IA, we extend this with ADDR0..2 and A0..7 on IKCH31IB to give us 11 additional CONFIG jumpers.
 *
 *	Currently, the following configuration jumpers are assigned:
 *
 *	CONFIG 1	if jumpered, disables the 120ths of a second "fast hand"
 *	CONFIG 2	if jumpered, WS2812s are driven from pin 4 -- this means the chain order is reversed
 *	CONFIG 3	if jumpered, WS2812s are RGB order, otherwise GRB
 *
 *	Scanned once at startup.
*/

static bool configs [NELEMENTS (decoder_enables) + NELEMENTS (cathodes) + NELEMENTS (anodes)] = { 0 };

// keep track of time as we get it when we get it (UTC time)
#define	MICROSECONDS	(1000LL * 1000LL)
static uint64_t last_tick = 0;							// free-running microsecond counter at last time fix
static unsigned last_time = 0;							// UTC time in seconds since 00:00:00 at last time fix
static bool have_gps = false;							// we don't have a valid GPS value yet

// time that we use for display, and the TZ offset for correcting
static unsigned time [4] = { 0 };						// the display time, [0] = H24, [1] = M, [2] = S, [3] = 1/i120th S
static unsigned tzoffset = 0;							// timezone offset, in hours (never negative, use 24's complement math)
static unsigned utc [6] = { 0 };						// UTC YMDHMS; year given as 00..99
#define	UYEAR	(utc [0])
#define	UMONTH	(utc [1])
#define	UDAY	(utc [2])
#define	UHOUR	(utc [3])
#define	UMINUTE	(utc [4])
#define	USECOND	(utc [5])

// store a valid UTC date and time into our base variables
static void
commit (GPS_t *gps)
{
	if (gps -> valid != GPS_TYPE_GPRMC && gps -> valid != GPS_TYPE_GNRMC) return;

	have_gps = true;

	char *d = gps -> gps_date;
	char *t = gps -> gps_time;

	// process UTC time; note that GPS delivers time as DDMMYY
	UYEAR   =  (d [4] - '0') * 10 + (d [5] - '0');			// 00..99 -> 2000..2099
	UMONTH  = ((d [2] - '0') * 10 + (d [3] - '0')) % 13;	// 01..12
	UDAY    = ((d [0] - '0') * 10 + (d [1] - '0')) % 32;	// 01..31
	UHOUR   = ((t [0] - '0') * 10 + (t [1] - '0')) % 24;
	UMINUTE = ((t [2] - '0') * 10 + (t [3] - '0')) % 60;
	USECOND = ((t [4] - '0') * 10 + (t [5] - '0')) % 60;

	last_tick = time_us_64();								// store free-running microseconds counter
	last_time = ((UHOUR * 60) + UMINUTE) * 60 + USECOND;	// and snapshot of current UTC time corresponding to that counter value

	/*
	 *	Automatically compute EST/EDT when the compute_est_edt flag is set.
	 *	This is mainly for the convenience of my eastern timezone target audience using GPS :-)
	 *
	 *	NRC EST/EDT specification at https://nrc.canada.ca/en/certifications-evaluations-standards/canadas-official-time/time-zones-daylight-saving-time
	 *	says that DST starts on the 2nd Sunday in March at 02:00 EST and ends 1st Sunday in November at 02:00 EDT.
	 *	Converting that to GPS UTC time, that's 07:00 UTC start and 06:00 UTC end time.
	 *
	 *	The early and later parts of March are easy -- since we're looking for a transition at the 2nd Sunday, we know that
	 *	any dates before the 8th can't be the second Sunday (so they're in EST territory), and any dates after the 14th can't
	 *	be the second Sunday either (so they're in EDT territory).
	 *
	 *	The middle of March is interesting:
	 *
	 *				 0	 1	 2	 3	 4	 5	 6  (dotw)
	 *				Sat Sun Mon Tue Wed Thu Fri
	 *			08	EST	 ? 	EST	EST	EST	EST	EST
	 *			09	EST	 ? 	 . 	EST	EST	EST	EST
	 *			10	EST	 ?   . 	 . 	EST	EST	EST
	 *			11	EST	 ? 	 . 	 . 	 . 	EST	EST
	 *			12	EST	 ? 	 . 	 . 	 . 	 . 	EST
	 *			13	EST	 ? 	 . 	 . 	 . 	 . 	 .
	 *			14	 .   ? 	 . 	 . 	 . 	 . 	 .
	 *
	 *	The pattern is more apparent if we move Saturday after Friday:
	 *
	 *				 1	 2	 3	 4	 5	 6	 7	(dotw)
	 *				Sun Mon Tue Wed Thu Fri SAT
	 *			08	 ? 	EST	EST	EST	EST	EST	EST
	 *			09	 ? 	 . 	EST	EST	EST	EST	EST
	 *			10	 ?   . 	 . 	EST	EST	EST	EST
	 *			11	 ? 	 . 	 . 	 . 	EST	EST	EST
	 *			12	 ? 	 . 	 . 	 . 	 . 	EST	EST
	 *			13	 ? 	 . 	 . 	 . 	 . 	 . 	EST
	 *			14	 ? 	 . 	 . 	 . 	 . 	 . 	 .
	 *
	 *	The day minus the dotw gives us:
	 *
	 *				 1	 2	 3	 4	 5	 6	 7	(dotw)
	 *				Sun Mon Tue Wed Thu Fri SAT
	 *			08	  7	  6	  5	  4	  3	  2	  1
	 *			09	  8	  7	  6	  5	  4	  3	  2
	 *			10	  9	  8	  7	  6	  5	  4	  3
	 *			11	 10	  9	  8	  7	  6	  5	  4
	 *			12	 11	 10	  9	  8	  7	  6	  5
	 *			13	 12	 11	 10	  9	  8	  7	  6
	 *			14	 13	 12	 11	 10	  9	  8	  7
	 *
	 *	Any value less than or equal to 6 is EST, any value greater than or equal to 7 that's not a Sunday is EDT, and then we just check for Sundays
	 *	being before 07:00 UTC (EST) or not (EDT).
	 *
	 *	November has a similar table (with Saturday moved after Friday):
	 *
	 *				 1	 2	 3	 4	 5	 6	 7	(dotw)
	 *				Sun Mon Tue Wed Thu Fri SAT
	 *			01   ?  EDT EDT EDT EDT EDT EDT
	 *			02   ?   .  EDT EDT EDT EDT EDT
	 *			03   ?   .   .  EDT EDT EDT EDT
	 *			04   ?   .   .   .  EDT EDT EDT
	 *			05   ?   .   .   .   .  EDT EDT
	 *			06   ?   .   .   .   .   .  EDT
	 *			07   ?   .   .   .   .   .   .
	 *
	 *	Same table trick:
	 *
	 *				 1	 2	 3	 4	 5	 6	 7	(dotw)
	 *				Sun Mon Tue Wed Thu Fri SAT
	 *			01	  0	 -1	 -2	 -3	 -4	 -5	 -6
	 *			02	  1	  0	 -1	 -2	 -3	 -4	 -5
	 *			03	  2	  1	  0	 -1	 -2	 -3	 -4
	 *			04	  3	  2	  1	  0	 -1  -2	 -3
	 *			05	  4	  3	  2	  1	  0	 -1	 -2
	 *			06	  5	  4   3   2   1   0  -1
	 *			07	  6	  5	  4	  3	  2	  1	  0
	 *
	 *	Here, all negative numbers are in EST, all zero and positive in EDT unless it's a Sunday and then you need to check.
	*/

	unsigned dotw = (UDAY + 13 * (UMONTH + 1) / 5 + UYEAR + UYEAR / 4 + 105) % 7;	// 0 == Saturday
	if (!dotw) dotw = 7;								// move Saturday after Friday

	bool est = UMONTH <= 2 || UMONTH >= 11;				// JAN, FEB, and DEC are guaranteed to be EST; MAR .. NOV are assumed to be EDT

	if (UMONTH == 3) {
		if (UDAY < 8) {									// MAR 01 .. 07 are for sure not after the second Sunday
			est = true;
		} else if (UDAY <= 14) {						// MAR 08 .. 14 MIGHT be the, or after the, second Sunday
			if (UDAY - dotw <= 6) {						// these are all EST according to the table above
				est = true;
			} else if (dotw == 1) {						// this is the 2nd Sunday; it may be in EST if they're early enough
				if (UHOUR < 7) {
					est = true;
				}
			}
		}												// MAR 15 .. 31 are definitely not in EST
	} else if (UMONTH == 11) {
		if (UDAY < 8) {
			int diff = UDAY;
			diff -= dotw;
			if (diff < 0) {
				est = false;
			}
			if (UDAY < 8 && dotw == 1) {
				est = UHOUR >= 6;
			}
		}
	}
	tzoffset = 24 - 4 - est;							// EST = UTC - 05:00, EDT = UTC - 04:00
}

// compute the four time components (h, m, s, 1/120ths) from the base variables
static void
compute_time (void)
{
	uint64_t new_time_us = last_time * MICROSECONDS + time_us_64() - last_tick;

	// compute 1/120ths of a second
	time [3] = 120 * (new_time_us % MICROSECONDS) / MICROSECONDS;
	new_time_us /= MICROSECONDS;						// convert to seconds
	time [2] = new_time_us % 60;
	new_time_us /= 60;									// convert to minutes
	time [1] = new_time_us % 60;
	new_time_us /= 60;									// convert to hours
	time [0] = (new_time_us + tzoffset) % 24;
}

/*
 *	Hours, minutes, and seconds handlers and decode tables
 *
 *	The hardware gives us 120 second, 60 minute and 48 hour hands.
 *	This is different from the IKCH31C which had 60, 60, and 36, respectively.
 *	The hands are enabled by {HOURS,MINUTES,SECONDS1,SECONDS2}_ENABLE, with
 *	ADDR{0..2} driving the 3-to-8 line decoders, and ANODE{0..7} indicating which anode
 *	"column" is enabled (only one at a time).
*/

typedef struct {
	uint8_t	enable;										// which GPIO pin enables the '138 decoder
	uint8_t	addr;										// which address we send to the '138 decoder (via cathodes [0..2] for the bits)
	uint8_t	anode;										// which anode value we manifest
} ledinfo_t;

#define	H(__addr, __anode)	{ HOURS_ENABLE, __addr, ANODE##__anode }
ledinfo_t position_h [] = {
	H (0, 4), H (0, 3), H (1, 3), H (2, 3), 			// 00
	H (3, 3), H (4, 3), H (5, 3), H (5, 2), 			// 01
	H (4, 2), H (3, 2), H (2, 2), H (1, 2), 			// 02
	H (0, 2), H (0, 1), H (1, 1), H (2, 1), 			// 03
	H (3, 1), H (4, 1), H (5, 1), H (5, 0), 			// 04
	H (4, 0), H (3, 0), H (2, 0), H (1, 0), 			// 05
	H (0, 0), H (0, 7), H (1, 7), H (2, 7), 			// 06
	H (3, 7), H (4, 7), H (5, 7), H (5, 6), 			// 07
	H (4, 6), H (3, 6), H (2, 6), H (1, 6), 			// 08
	H (0, 6), H (0, 5), H (1, 5), H (2, 5), 			// 09
	H (3, 5), H (4, 5), H (5, 5), H (5, 4), 			// 10
	H (4, 4), H (3, 4), H (2, 4), H (1, 4), 			// 11
};
#undef H
static_assert (sizeof (position_h) == (48 * sizeof (ledinfo_t)), "Expected exactly 48 entries in hour-hand position table");

#define	M(__addr, __anode) { MINUTES_ENABLE, __addr, ANODE##__anode }
ledinfo_t position_m [] = {
	M (7, 4), M (7, 3), M (6, 3), M (5, 3), M (4, 3), 	// xx:00 -> xx:04
	M (3, 3), M (2, 3), M (1, 3), M (0, 2), M (1, 2), 	// xx:05 -> xx:09
	M (2, 2), M (3, 2), M (4, 2), M (5, 2), M (6, 2), 	// xx:10 -> xx:14
	M (7, 2), M (7, 1), M (6, 1), M (5, 1), M (4, 1), 	// xx:15 -> xx:19
	M (3, 1), M (2, 1), M (1, 1), M (0, 0), M (1, 0), 	// xx:20 -> xx:24
	M (2, 0), M (3, 0), M (4, 0), M (5, 0), M (6, 0), 	// xx:25 -> xx:29
	M (7, 0), M (7, 7), M (6, 7), M (5, 7), M (4, 7), 	// xx:30 -> xx:34
	M (3, 7), M (2, 7), M (1, 7), M (0, 6), M (1, 6), 	// xx:35 -> xx:39
	M (2, 6), M (3, 6), M (4, 6), M (5, 6), M (6, 6), 	// xx:40 -> xx:44
	M (7, 6), M (7, 5), M (6, 5), M (5, 5), M (4, 5), 	// xx:45 -> xx:49
	M (3, 5), M (2, 5), M (1, 5), M (0, 4), M (1, 4), 	// xx:50 -> xx:54
	M (2, 4), M (3, 4), M (4, 4), M (5, 4), M (6, 4), 	// xx:55 -> xx:59
};
#undef M
static_assert (sizeof (position_m) == (60 * sizeof (ledinfo_t)), "Expected exactly 60 entries in minute-hand position table");

#define	A(__addr, __anode) { SECONDS1_ENABLE, __addr, ANODE##__anode }
#define	B(__addr, __anode) { SECONDS2_ENABLE, __addr, ANODE##__anode }
ledinfo_t position_s [] = {
	A (7, 4), A (7, 3), A (6, 3), A (5, 3), A (4, 3), A (3, 3), A (2, 3), A (1, 3), B (7, 3), B (6, 3),		// xx:xx:00 -> xx:xx:04
	B (5, 3), B (4, 3), B (3, 3), B (2, 3), B (1, 3), B (0, 2), B (1, 2), B (2, 2), B (3, 2), B (4, 2),		// xx:xx:05 -> xx:xx:09
	B (5, 2), B (6, 2), B (7, 2), A (0, 2), A (1, 2), A (2, 2), A (3, 2), A (4, 2), A (5, 2), A (6, 2),		// xx:xx:10 -> xx:xx:14
	A (7, 2), A (7, 1), A (6, 1), A (5, 1), A (4, 1), A (3, 1), A (2, 1), A (1, 1), B (7, 1), B (6, 1),		// xx:xx:15 -> xx:xx:19
	B (5, 1), B (4, 1), B (3, 1), B (2, 1), B (1, 1), B (0, 0), B (1, 0), B (2, 0), B (3, 0), B (4, 0),		// xx:xx:20 -> xx:xx:24
	B (5, 0), B (6, 0), B (7, 0), A (0, 0), A (1, 0), A (2, 0), A (3, 0), A (4, 0), A (5, 0), A (6, 0),		// xx:xx:25 -> xx:xx:29
	A (7, 0), A (7, 7), A (6, 7), A (5, 7), A (4, 7), A (3, 7), A (2, 7), A (1, 7), B (7, 7), B (6, 7),		// xx:xx:30 -> xx:xx:34
	B (5, 7), B (4, 7), B (3, 7), B (2, 7), B (1, 7), B (0, 6), B (1, 6), B (2, 6), B (3, 6), B (4, 6),		// xx:xx:35 -> xx:xx:39
	B (5, 6), B (6, 6), B (7, 6), A (0, 6), A (1, 6), A (2, 6), A (3, 6), A (4, 6), A (5, 6), A (6, 6),		// xx:xx:40 -> xx:xx:44
	A (7, 6), A (7, 5), A (6, 5), A (5, 5), A (4, 5), A (3, 5), A (2, 5), A (1, 5), B (7, 5), B (6, 5),		// xx:xx:45 -> xx:xx:49
	B (5, 5), B (4, 5), B (3, 5), B (2, 5), B (1, 5), B (0, 4), B (1, 4), B (2, 4), B (3, 4), B (4, 4),		// xx:xx:50 -> xx:xx:54
	B (5, 4), B (6, 4), B (7, 4), A (0, 4), A (1, 4), A (2, 4), A (3, 4), A (4, 4), A (5, 4), A (6, 4),		// xx:xx:55 -> xx:xx:59
};
#undef B
#undef A
static_assert (sizeof (position_s) == (120 * sizeof (ledinfo_t)), "Expected exactly 120 entries in second-hand position table");

static int last_decoder_enabled = HOURS_ENABLE;			// any valid value will do
static int last_anode = ANODE0;

static void
light_off (void)
{
	gpio_put (last_anode, 0);							// turn off anode
	sleep_us (50);										// discharge remaining energy through current anode
	gpio_put (last_decoder_enabled, 0);
	sleep_us (50);										// required; if set to zero get ghosting on the hours and seconds!
}

static void
light_on (ledinfo_t *led)
{
	light_off ();

	gpio_put (cathodes [0], !!(led -> addr & 0x01));	// set the 3-to-8 line decode value for the cathodes
	gpio_put (cathodes [1], !!(led -> addr & 0x02));
	gpio_put (cathodes [2], !!(led -> addr & 0x04));
	gpio_put (last_anode = led -> anode, 1);			// turn on the anode we want
	gpio_put (last_decoder_enabled = led -> enable, 1);	// turn on just the one enable
}

#define	TIMEBASE_US		800

static unsigned lookup [60];

static void
init_lookup (void)
{
	// this is a simple exponential fade -- it's done as a table so you can make it extra fancy
	for (unsigned i = 0; i < NELEMENTS (lookup); i++) {
		lookup [i] = TIMEBASE_US * pow (2, 1. - (double) i / NELEMENTS (lookup)) - TIMEBASE_US;
	}
}

static void
execute_leds (bool forward)
{
	static unsigned rotor = 0;
	unsigned hold_time = TIMEBASE_US;
	unsigned dummy_time = 0;

	switch (rotor++) {
	case 0:
		// there are four "sub-hours", xx:{00:00 .. 14:59}, xx:{15:00 .. 29:59}, xx:{30:00 .. 44:59}, and xx:{45:00 .. 59:59}
		light_on (&position_h [(time [0] * 4 + time [1] / 15) % NELEMENTS (position_h)]);
		break;

	case 1:
		light_on (&position_m [time [1] % NELEMENTS (position_m)]);
		break;

	case 2:
		// there are two "sub-seconds", xx:xx:xx:000 .. xx:xx:xx:059 and xx:xx:xx:060 .. xx:xx:xx:119 (based on the 1/120th seconds value as the last element)
		light_on (&position_s [(time [2] * 2 + time [3] / 60) % NELEMENTS (position_s)]);
#ifdef	FADE
		hold_time = lookup [time [3] % NELEMENTS (lookup)];
		dummy_time = TIMEBASE_US - hold_time;
#endif	// FADE

		// skip the 120ths of a second if config 1 is jumpered
		if (configs [0]) {
			rotor = 0;
		}
		break;

	case 3: {
		unsigned onehundredandtwentieths = time [3] % NELEMENTS (position_s);	// 0..119
		// spinner goes CCW for Ante Meridiem, CW for Post Meridiem
		if (forward) {
			light_on (&position_s [onehundredandtwentieths]);
		} else {
			light_on (&position_s [NELEMENTS (position_s) - onehundredandtwentieths - 1]);	// 120 - (0..119) - 1 -> 120-0-1 .. 120-119-1 -> 119..0 :-)
		}
		rotor = 0;
		break; }
	}

	sleep_us (hold_time);
	if (dummy_time) {
		light_off ();
		sleep_us (dummy_time);
	}
}

/*
 *	moon phase complication
 *
 *	The LEDs corresponding to the moon phase complication are mapped as follows:
 *
 *		  A B C
 *		 G F E D
 *		H I J K L
 *		 P O N M
 *		  Q R S
 *
 *	Note the snake ordering; it made the PCB layout easier.
 *
 *	The moon itself starts illumination on the right side, waxes, wanes, and then exits on the left side.
 *	There are 28 moon phases; 14 is a full moon.
 *
 *	We don't use all 17 of the values in the powers[] table -- those LEDs are bright!
*/

#define	MOONLEDS	19
static uint8_t moon19 [MOONLEDS][3] = { 0 };	// R, G, B order (this is not the WS2812 wire order; that's corrected in write_moon())
static uint8_t powers [] = { 0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 255 };
static uint8_t moons [28][19] =
{
	{		// 0 new moon
		  0,0,0,
		 0,0,0,0,
		0,0,0,0,0,
		 0,0,0,0,
		  0,0,0
	}, {	// 1
		  0,0,0,
		 0,0,0,0,
		0,0,0,0,5,
		 0,0,0,0,
		  0,0,0
	}, {	// 2
		  0,0,0,
		 0,0,0,5,
		0,0,0,0,8,
		 0,0,0,5,
		  0,0,0
	}, {	// 3
		  0,0,0,
		 0,0,0,8,
		0,0,0,5,8,
		 0,0,0,8,
		  0,0,0
	}, {	// 4
		  0,0,5,
		 0,0,0,8,
		0,0,0,5,8,
		 0,0,0,8,
		  0,0,5
	}, {	// 5
		  0,0,8,
		 0,0,5,8,
		0,0,0,8,8,
		 0,0,5,8,
		  0,0,8
	}, {	// 6
		  0,0,8,
		 0,0,8,8,
		0,0,5,8,8,
		 0,0,8,8,
		  0,0,8
	}, {	// 7 first half
		  0,5,8,
		 0,0,8,8,
		0,0,5,8,8,
		 0,0,8,8,
		  0,5,8
	}, {	// 8 (6)
		  0,8,8,
		 0,0,8,8,
		0,0,8,8,8,
		 0,0,8,8,
		  0,8,8
	}, {	// 9 (5)
		  0,8,8,
		 0,5,8,8,
		0,0,8,8,8,
		 0,5,8,8,
		  0,8,8
	}, {	// 10 (4)
		  0,8,8,
		 0,8,8,8,
		0,5,8,8,8,
		 0,8,8,8,
		  0,8,8
	}, {	// 11 (3)
		  5,8,8,
		 0,8,8,8,
		0,8,8,8,8,
		 0,8,8,8,
		  5,8,8
	}, {	// 12 (2)
		  8,8,8,
		 5,8,8,8,
		0,8,8,8,8,
		 5,8,8,8,
		  8,8,8
	}, {	// 13 (1)
		  8,8,8,
		 8,8,8,8,
		5,8,8,8,8,
		 8,8,8,8,
		  8,8,8
	}, {	// 14 full moon, (0)
		  8,8,8,
		 8,8,8,8,
		8,8,8,8,8,
		 8,8,8,8,
		  8,8,8
	},

	// rest generated by symmetry at init_moon()
};

static void
swapu8 (uint8_t *a, uint8_t *b)
{
	uint8_t tmp = *a;
	*a = *b;
	*b = tmp;
}

/*
 *	Not only do the WS2812 5mm LEDs have a variety of pin orderings, they also have a variety of colour orderings!
 *
 *	In my inventory, I have three types:
 *		Foggy 1
 *		Foggy 2
 *		Clear
 *
 *	Colour orderings are:
 *
 *		Foggy 1	R, G, B
 *		Foggy 2	G, R, B
 *		Clear	(unknown, haven't tried one yet)
*/

static uint8_t rgb_shifts [3];

#define	S(__segment) (tolower(__segment)-'a')
static void
init_moon (void)
{
	// figure out the LED colour ordering
	if (configs [2]) {
		// R, G, B ordering
		rgb_shifts [0] = 24;
		rgb_shifts [1] = 16;
		rgb_shifts [2] = 8;
	} else {
		// G, R, B ordering
		rgb_shifts [0] = 16;
		rgb_shifts [1] = 24;
		rgb_shifts [2] = 8;
	}

	// generate moons 15..27 by symmetry
	for (int i = 15; i < 28;i ++) {
		int base = 28 - i;

		moons [i][S('A')] = moons [base][S('C')];		// swap first row
		moons [i][S('B')] = moons [base][S('B')];
		moons [i][S('C')] = moons [base][S('A')];

		moons [i][S('D')] = moons [base][S('G')];		// swap second row
		moons [i][S('E')] = moons [base][S('F')];
		moons [i][S('F')] = moons [base][S('E')];
		moons [i][S('G')] = moons [base][S('D')];

		moons [i][S('H')] = moons [base][S('L')];		// swap third row
		moons [i][S('I')] = moons [base][S('K')];
		moons [i][S('J')] = moons [base][S('J')];
		moons [i][S('K')] = moons [base][S('I')];
		moons [i][S('L')] = moons [base][S('H')];

		moons [i][S('M')] = moons [base][S('P')];		// swap fourth row
		moons [i][S('N')] = moons [base][S('O')];
		moons [i][S('O')] = moons [base][S('N')];
		moons [i][S('P')] = moons [base][S('M')];

		moons [i][S('Q')] = moons [base][S('S')];		// swap fifth row
		moons [i][S('R')] = moons [base][S('R')];
		moons [i][S('S')] = moons [base][S('Q')];
	}

	// now fixup moon data -- the on-wire data is A..S, but the data set is presented as A..C, G..D, H..L, P..M, Q..S
	for (int i = 0; i < 28; i++) {
		// odd rows (ABC, HIJKL, and QRS) are fine
		swapu8 (&moons [i][S('D')], &moons [i][S('G')]);	// DEFG -> GFED
		swapu8 (&moons [i][S('E')], &moons [i][S('F')]);
		swapu8 (&moons [i][S('M')], &moons [i][S('P')]);	// MNOP -> PONM
		swapu8 (&moons [i][S('N')], &moons [i][S('O')]);
	}
}

// light the segments identified in the string
static void
moon_segments (const char *s, int r, int g, int b)
{
	while (*s) {
		uint8_t *v = moon19 [S(*s)];
		*v++ = r;
		*v++ = g;
		*v++ = b;
		s++;
	}
}
#undef S

static void
clear_moon (void)
{
	memset (moon19, 0, sizeof (moon19));
}

/*
 *	write_moon19()
 *
 *	Write the moon logical data to the WS2812 physical LEDs.
 *	The LEDs colour order is determined by a table, because it varies.
 *	The ordering of the LEDs varies as well, based on which pin is the input and which is the output -- this
 *	puts the input at the beginning of the chain or the end.
*/

static void
write_moon19 (void)
{
	if (configs [1]) {
		// if configuration jumper 2 is set, then the LEDs are driven from the last one in the chain to the first
		for (int i = MOONLEDS - 1; i >= 0; i--) {
			pio_sm_put_blocking (pio0, 0, (moon19 [i][0] << rgb_shifts [0]) + (moon19 [i][1] << rgb_shifts [1]) + (moon19 [i][2] << rgb_shifts [2]));
		}
	} else {
		// otherwise, the LEDs are driven from the first in the chain to the last
		for (int i = 0; i < MOONLEDS; i++) {
			pio_sm_put_blocking (pio0, 0, (moon19 [i][0] << rgb_shifts [0]) + (moon19 [i][1] << rgb_shifts [1]) + (moon19 [i][2] << rgb_shifts [2]));
		}
	}
}

// moon phase calculation uses UTC hour because the midnight boundary has to match UTC YMD
static void
moon (void)
{
	static int last_hour = 24;

	if (UHOUR == last_hour) {
		return;
	}

	last_hour = UHOUR;

	uint8_t *today = moons [moonPhases (2000 + UYEAR, UMONTH, UDAY) % NELEMENTS (moons)];
	uint8_t *tomorrow = moons [moonPhases (2000 + UYEAR, UMONTH, UDAY + 1) % NELEMENTS (moons)];	// doesn't matter if "day" is no longer valid for the month

	// blend the moon phases on an hourly basis
	for (int i = 0; i < MOONLEDS; i++) {
		int v1 = powers [today [i]];
		int v2 = powers [tomorrow [i]];
		int r = v1 + last_hour * (v2 - v1) / 24;
		moon19 [i][0] = moon19 [i][1] = r;
		// bias the moon to be slightly blue
		v1 = powers [today [i] + 1];
		v2 = powers [tomorrow [i] + 1];
		r = v1 + last_hour * (v2 - v1) / 24;
		moon19 [i][2] = r;
	}
	write_moon19 ();
}

/*
 *	For reference:
 *
 *		  A B C
 *		 G F E D
 *		H I J K L
 *		 P O N M
 *		  Q R S
 *
 *
 *	Note that currently the colours are somewhat arbitrary based on the character being displayed :-)
*/

static void
moon_char (uint8_t c)
{
	clear_moon ();
	switch (c) {

//#define ARABIC
#ifdef	ARABIC
	case	'0': moon_segments ("abcdlmsrqphgejo", 0, 0, 9);	break;
	case	'1': moon_segments ("bejnqrs", 0, 0, 9);			break;
	case	'2': moon_segments ("abcgdjkoqrs", 0, 0, 9);		break;
	case	'3': moon_segments ("abcqrsjkldm", 0, 0, 9);		break;
	case	'4': moon_segments ("aghijkdnr", 0, 0, 9);			break;
	case	'5': moon_segments ("abcghijklmsrq", 0, 0, 9);		break;
	case	'6': moon_segments ("abcghpqrsmijk", 0, 0, 9);		break;
	case	'7': moon_segments ("abcejoq", 0, 0, 9);			break;
	case	'8': moon_segments ("abcdlmsrqphgijk", 0, 0, 9);	break;
	case	'9': moon_segments ("qrsmldcbaghijk", 0, 0, 9);		break;
#endif	// ARABIC

#define FANCY
#ifdef	FANCY
	case	'0': moon_segments ("abcdlmsrqphg", 0, 0, 9);		break;
	case	'1': moon_segments ("hijkl", 0, 0, 9);				break;
	case	'2': moon_segments ("abcqrs", 0, 0, 9);				break;
	case	'3': moon_segments ("abchpqlms", 0, 0, 9);			break;
	case	'4': moon_segments ("abchiklqrs", 0, 0, 9);			break;
	case	'5': moon_segments ("acjqs", 0, 0, 9);				break;
	case	'6': moon_segments ("achlqs", 0, 0, 9);				break;
	case	'7': moon_segments ("achjlqs", 0, 0, 9);			break;
	case	'8': moon_segments ("achiklqs", 0, 0, 9);			break;
	case	'9': moon_segments ("abchjlqrs", 0, 0, 9);			break;
#endif	// FANCY

	case	'.': moon_segments ("r", 0, 0, 9);					break;
	case	'?': moon_segments ("abegjr", 9, 0, 0);				break;
	case	'X': moon_segments ("afjnscejoq", 9, 9, 0);			break;
	default:
		break;
	}
	write_moon19 ();
}

static void
init_ios (unsigned *gpios, unsigned n, int dir)
{
	for (unsigned i = 0; i < n; i++) {
		gpio_init (gpios [i]);
		gpio_set_dir (gpios [i], dir);
		if (dir == GPIO_IN) {
			gpio_pull_down (gpios [i]);
		} else {
			gpio_put (gpios [i], 0);					// set all outputs to zero
		}
	}
}

static bool
sense_one (uint8_t gpio)
{
	gpio_put (gpio, 1);
	sleep_us (5);										// allow outputs to propagate (without this, it reads 0)
	bool value = gpio_get (SENSE);
	gpio_put (gpio, 0);
	return value;
}

static void
init_configuration (void)
{
	int c = 0;

	for (int i = 0; i < NELEMENTS (decoder_enables); i++) {
		configs [c++] = sense_one (decoder_enables [i]);
	}

	for (int i = 0; i < NELEMENTS (cathodes); i++) {
		configs [c++] = sense_one (cathodes [i]);
	}

	for (int i = 0; i < NELEMENTS (anodes); i++) {
		configs [c++] = sense_one (anodes [i]);
	}

	gpio_set_dir (SENSE, GPIO_OUT);						// after we're done reading, set the SENSE to be an output ...
	gpio_put (SENSE, 1);								// ... and set it high -- this prevents pull-down through the isolation diodes
}

static void
init_pio (void)
{
	uint offset;
	const int speed = 1100000;

	offset = pio_add_program (pio0, &ws2812_program);
	ws2812_program_init (pio0, 0, offset, WS2812, speed, false);
}

static GPS_t gps;

static void
initialize (void)
{
	init_ios (inputs, NELEMENTS (inputs), GPIO_IN);

	init_ios (cathodes, NELEMENTS (cathodes), GPIO_OUT);
	init_ios (decoder_enables, NELEMENTS (decoder_enables), GPIO_OUT);
	init_ios (anodes, NELEMENTS (anodes), GPIO_OUT);

	init_configuration ();
	init_pio ();
	init_lookup ();
	init_moon ();

	// set up GPS from serial port with callback for decoded data
	gps_create (&gps);
	gps_init_serial (&gps, SERIAL_RX_PIN, SERIAL_TX_PIN);
	gps_set_callback (&gps, commit);
}

static void
lamp_test (void)
{
//#define	CONTINUOUS_MOON_ANIMATION_TEST
#ifdef	CONTINUOUS_MOON_ANIMATION_TEST
	year = 2025;
	month = 1;
	day = 1;
	for (;;) {
		moon ();
		sleep_ms (25);
		time [0] = (time [0] + 1) % 24;
		if (!time [0]) {
			day++;
		}
	}
#endif

//#define	CONTINUOUS_NUMBER_TEST
#ifdef	CONTINUOUS_NUMBER_TEST
	for (;;) {
		for (int i = '0'; i <= '9'; i++) {
			moon_char (i);
			sleep_ms (800);
			moon_char (' ');
			sleep_ms (200);
		}
	}
#endif

	int h = 0;
	int m = 0;
	int s = 0;

	unsigned counter = 0;
	unsigned rotor = 0;
	unsigned moon_unit = 0;
	unsigned moon_colour = 0;
	for (int i = 0; i < 14400; i++) {
		switch (rotor++) {
		case 0:
			light_on (&position_h [h % NELEMENTS (position_h)]);
			break;

		case 1:
			light_on (&position_m [m % NELEMENTS (position_m)]);
			break;

		case 2:
			light_on (&position_s [s % NELEMENTS (position_s)]);
			rotor = 0;
			break;

		}

		if ((counter % 48) == 0) {
			h = (h + 1) % 48;
		}
		if ((counter % 30) == 0) {
			m = (m + 59) % 60;
		}
		if ((counter % 60) == 0) {
			s = (s + 1) % 120;
		}
		if ((counter % 150) == 0) {
			clear_moon ();
			if (moon_unit == MOONLEDS - 1) {
				moon_colour = (moon_colour + 1) % 3;
				moon_unit = 0;
			} else {
				moon_unit++;
			}
			moon19 [moon_unit][moon_colour] = 0x40;
			write_moon19 ();
		}
		counter++;

		sleep_ms (1);
	}

	// display version information
	clear_moon ();
	for (const char *s = version; *s; s++) {
		moon_char (*s);
		sleep_ms (1500);
		moon_char (' ');
		sleep_ms (200);
	}
	clear_moon ();
	write_moon19 ();
}

// manifest hours "ghosts" in seconds ring for reference
static void
ghosts (void)
{
	static int divisor = 0;
	if (++divisor < 10) return;
	divisor = 0;

	for (int rotor = 0; rotor < 12; rotor++) {
		light_on (&position_s [rotor * 10]);
		sleep_us (10);
	}
	light_off ();										// turn off the last ghost when done, otherwise the "11" ghost is brighter than the others :-)
}

int
main ()
{
#ifdef	STDIO
	stdio_init_all ();
	stdio_set_translate_crlf (&stdio_usb, false);		// prevent library from helpfully converting \n to \r\n
	sleep_ms (2000);
	printf ("Starting...\n");
#endif

	initialize ();
	lamp_test ();

	int nchars = 0;
	for (;;) {
		nchars += gps_handle_serial (&gps);
		compute_time ();
		execute_leds (time [0] >= 12);					// AM/PM passed as bool "forward"

		if (nchars < 1000) {
			moon_char ('?');
		} else {
			if (have_gps) {
				moon ();
			} else {
				moon_char ('X');
			}
		}

		ghosts ();
	}
}

