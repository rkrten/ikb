
2025 01 19
ikch31i may have been abandoned.

Bulk layout using km:

	1) start with an empty PCB
	2) import all the symbols in the usual manner (via PCB editor "import from schematic") and save
	3) copy the "clean" version to saved
	4) to restart from clean, the following script:
		- destroys the current image and replaces it with the clean one
		- organizes the components and moves them out of the way
		- generates the hours, minutes, and seconds rings

cp saved ikch31i.kicad_pcb ; km -tw -x 175 ikch31i.kicad_pcb ; km -w -rD100,D101,D102,D103,D104,D105,D106,D107,D108,D109,D110,D111,D112,D113,D114,D115,D116,D117,D118,D119,D120,D121,D122,D123,D124,D125,D126,D127,D128,D129,D130,D131,D132,D133,D134,D135,D136,D137,D138,D139,D140,D141,D142,D143,D144,D145,D146,D147 -P ring,r=40,c=90 ikch31i.kicad_pcb ; km -w -rD200,D201,D202,D203,D204,D205,D206,D207,D208,D209,D210,D211,D212,D213,D214,D215,D216,D217,D218,D219,D220,D221,D222,D223,D224,D225,D226,D227,D228,D229,D230,D231,D232,D233,D234,D235,D236,D237,D238,D239,D240,D241,D242,D243,D244,D245,D246,D247,D248,D249,D250,D251,D252,D253,D254,D255,D256,D257,D258,D259 -P ring,r=84,c=270 ikch31i.kicad_pcb ; km -w -rD300,D301,D302,D303,D304,D305,D306,D307,D308,D309,D310,D311,D312,D313,D314,D315,D316,D317,D318,D319,D320,D321,D322,D323,D324,D325,D326,D327,D328,D329,D330,D331,D332,D333,D334,D335,D336,D337,D338,D339,D340,D341,D342,D343,D344,D345,D346,D347,D348,D349,D350,D351,D352,D353,D354,D355,D356,D357,D358,D359,D360,D361,D362,D363,D364,D365,D366,D367,D368,D369,D370,D371,D372,D373,D374,D375,D376,D377,D378,D379,D380,D381,D382,D383,D384,D385,D386,D387,D388,D389,D390,D391,D392,D393,D394,D395,D396,D397,D398,D399,D400,D401,D402,D403,D404,D405,D406,D407,D408,D409,D410,D411,D412,D413,D414,D415,D416,D417,D418,D419 -P ring,r=128,c=90 ikch31i.kicad_pcb

Damn, this km thing is useful!

Revisiting costs

	310 x 310 QTY 5
		- eng fee $5.77
		- large size $39.40
		- board $52.54
		- shipping $54.62
	total: $152.33 ($30.47 each)

	320 x 320 QTY 5
		- eng fee $5.75
		- large size $45.44
		- board $55.79
		- shipping $54.41
	total: $161.39 ($32.28 each)

So, no real savings with 310 vs 320.

2025 01 20
Moving on, let's see if rotating in the resistors does anything for us.

cp PRECIOUS.pcb ikch31i.kicad_pcb ; \
km -w -rR300,R301,R302,R303,R304,R305,R306,R307 -Pring,r=132,s=3 ikch31i.kicad_pcb ; \
km -w -rR407,R406,R405,R404,R403,R402,R401,R400 -Pring,r=132,s=3,i=336 ikch31i.kicad_pcb ; \
km -w -rR200,R201,R202,R203,R204,R205,R206,R207 -Pring,r=88,i=270,s=6,c=270 ikch31i.kicad_pcb ; \
km -w -rR105,R104,R103,R102,R101,R100 -Pring,r=64,i=180,s=10,c=90 ikch31i.kicad_pcb

2025 01 21
I can't believe this, but a *four* layer board, in black, is only:

	320 x 320 QTY 5
		- eng fee $34.56
		- large size $45.51
		- colour $10.95
		- board $74.89
		- shipping $54.49
	total: $220.56 ($44.11 each)

2025 01 24
The other change I made from the previous generation is that I completely eliminated through-hole components.
While it isn't *that* noticeable, it does result in an even cleaner surface.
The RJ-45 that connects to the external devices (power, or serial, or GPS) has been replaced with a surface mount 0.1" connector.
Here, by "surface mount" I really mean a standard through-hole 0.1" space male pin header, assumed to be bent at 90 degrees,
and soldered on the short side so that it sticks out a tiny bit.

Final checks before production:
	- do we have all the external connections we need?
	- are all the silk screen labels correct?
	- are the external connectors oriented correctly, in the right order, and non-interfering?
	- do any pseudo-SMD parts interfere with each other during assembly?
	- is the spacing for the inner hour hands ok?
	- are the solder mask identifications and silks in place?
	- are the mounting holes good for desktop, wall mount, etc?
		- do you have mounting for add-on cards?
		- can we provide mountpoints for the GPS module so it's not just hanging?
	- verify WS2812 4-pin jumbo LEDs -- I haven't seen mine in a while, so I wanna be sure

Going to qty 10 makes it a tad cheaper (one free board, basically):

	320 x 320 QTY 10
		- eng fee $5.74
		- large size $54.66
		- board $111.32
		- shipping $78.23
	total: $249.95 ($25 each)

2025 02 16
Final checks before production:
YES	- do we have all the external connections we need?
YES	- are all the silk screen labels correct?
YES	- are the external connectors oriented correctly, in the right order, and non-interfering?
NO	- do any pseudo-SMD parts interfere with each other during assembly?
YES	- is the spacing for the inner hour hands ok?
YES	- are the solder mask identifications and silks in place?
YES	- are the mounting holes good for desktop, wall mount, etc?
NO		- do you have mounting for add-on cards?
			- no, additional add-on cards can just hang, or be attached to the case, or there's *plenty* of room on the corners
NO		- can we provide mountpoints for the GPS module so it's not just hanging?
			- no, the GPS module can just hang, or it can be mounted to the case
YES	- verify WS2812 4-pin jumbo LEDs -- I haven't seen mine in a while, so I wanna be sure
		- there are many to choose from, I've selected IGPO ordering (Input, Ground, Power, Output)
			wrong: Aliexpress https://vi.aliexpress.com/i/4000720415203.html
			right: Aliexpress https://vi.aliexpress.com/item/1005006447915276.html
		- mitigated; we now support all four combinations that have power and ground as the two centre pins
		- ordered 100 so we have sufficient quantity for all 5 boards.

Inventory check:
	PART		NEED	HAVE	Can make X clocks
	--------	-----	----	-----------------
	TBD62783		1	  10				   10
	TBD62387		4	   9					2
	74LS138			4	 105				   26
	Red			   48	 354					7
	Green		   60	 404					6
	Blue		  108	 662					6
	Warm White		8	  58					7
	Cold White		4	  78				   19

So the only thing we're really short of (apart from PICOs, maybe) is the '387s
Digikey has 191 in stock; $4.12 each or $47.20 for 20+ ($2.36 each) [buy 20 @ $2.36 is $47.20 + $8 shipping = $55.20]
Mouser has 225 in stock; $3.89 each or $22.30 for 10 ($2.23 each) [buy 12 @ $2.23 is $26.76 + $20 shipping = $46.76]
Not available anywhere else (lcsc has zero stock) :-(
(alibaba has a distributor who has stock; I didn't explore this yet)
So, I guess Digikey wins. [Actually, does not! Found some TD62387 on aliexpress, ordered 30, see ../costs.txt]

2025 02 18
Final check: gerbers

Done.

Checking out, and the options are UPS Express Saver, for $53.60, or DHL DPP for $76 + $14 duties (basically adding another $40 to the order)
So, let's go with UPS Express Saver.
I also have a $14 coupon that I applied.
Grand total this way is $145.54 ($29 each)
Although Paypal computes this as $151.95 ($30.39 each)

*** ORDERED ***

Production directory ikch31ia created, and contents moved therein.

2025 02 24
UPS charged a reasonable $25.13 for brokerage and HST.
Paid via Paypal.
Said it'll arrive tomorrow (Tues).
Total shipping was $78.73, then.
Total cost was $151.95 + $25.13 = $177.08 or $35.42 each

2025 02 25
Now UPS says that they will "provide a delivery date as soon as possible" LOL.

2025 02 26
Arrived around 17:30.

2025 03 07
Awesome.
Built one, and with a half-moon, it takes 170mA

