
2026 06 14
Using the foggy short/short/long/long WS2812s in inventory, the first row is backwards (4-3-2-1) and D1 is the final LED.

2026 06 16
Assembled and tested.
Takes about 2 hours to assemble.

I assembled the rotary encoders first, because I wanted to measure the height clearance for the shield.
It's exactly 1 cm.
Next, I installed the LEDs in the boustrophen order, and verified like 3 or 4 times :-)
Then I installed the shield (at the 1 cm height), and pushed the LEDs through the shield.
Then I soldered the LEDs in place, one row at a time.
A bunch of them easily shorted; solder sucker fixed it.
Then I soldered in the caps.

I think I could have done the caps as the very first thing.
I had been worried that they would impact the LEDs, but they are completely clear of the LEDs.

So, recommended assembly order:
1) install and solder caps
2) install LEDs, verify as many times as you think is wise
3) install shield at 1cm offset
4) solder LEDs, one row at a time, trimming after each row

After that, it doesn't matter.

