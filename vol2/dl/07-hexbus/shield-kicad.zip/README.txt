The mounting hole for the rotaty shaft encoder is MountHole_7mm
And the LEDs are 5mm holes.

The knob of theshaft encoder has a 1.7cm diameter, so I'd give it a 2cm diameter clearence.

2026 06 16
Beautiful.

