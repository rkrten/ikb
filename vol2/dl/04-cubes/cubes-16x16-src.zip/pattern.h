
/*
 *	pattern.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Manifest constants and prototypes for the pattern engine driver.
 *
 *	2023 10 19	R. Krten		created
*/

enum PatternPhase {
	Start,												// pattern should initialize itself, and prepare to run
	Run,												// pattern should go to next iteration; return true if it should continue running, false if it's done
};

typedef bool Pattern (enum PatternPhase x);

void generate_pattern (void);
