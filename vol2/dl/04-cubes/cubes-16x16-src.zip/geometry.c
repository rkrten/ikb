
/*
 *	geometry.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module contains functions that deal with the geometry of the cube.
 *
 *	2023 09 28	R. Krten		separated out from main
*/

#include "ikch42.h"

uint8_t		leds [NLIGHTS][3];							// GRB order
uint8_t		location_x [NLIGHTS];						// LED locations
uint8_t		location_y [NLIGHTS];
uint8_t		location_z [NLIGHTS];
uint16_t	adjacency [NLIGHTS][8];						// pre-computed adjacency matrix, 8 elements {up, up/right, right, right/down, down, down/left, left, left/up}

/*
 *	The software LED ordering is row major:
 *
 *	  0			   1		   2		...			 C-3		 C-2		 C-1
 *	 C			 C+1		 C+2		...			2C-3		2C-2		2C-1
 *	2C			2C+1		2C+2		...			3C-3		3C-2		3C-1
 *	...			...			...			...			...			...			...
 *	(R-3)C		(R-3)C+1	(R-3)C+2	...			(R-2)C-3	(R-2)C-2	(R-2)C-1
 *	(R-2)C		(R-2)C+1	(R-2)C+2	...			(R-1)C-3	(R-1)C-2	(R-1)C-1
 *	(R-1)C		(R-1)C+1	(R-1)C+2	...			 R   C-3	 R   C-2	 R   C-1
 *
 *	If required, the hardware serializer corrects for the actual layout.
*/

void
set_face_individual (int face, int r, int g, int b)
{
	uint8_t rgb [3];
	rgb [R] = r;
	rgb [G] = g;
	rgb [B] = b;
	if (face >= 0 && face < NFACES) {
		for (int i = 0; i < FACELIGHTS; i++) {
			setRGB (face * FACELIGHTS + i, rgb);
		}
	}
}

void
set_face (int face, uint8_t *rgb)
{
	if (face >= 0 && face < NFACES) {
		for (int i = 0; i < FACELIGHTS; i++) {
			setRGB (face * FACELIGHTS + i, rgb);
		}
	}
}

#include "font-8x8.h"

void
write_char_on_face_individual (int f, int c, int ro, int co, int r, int g, int b)
{
	for (int row = 0; row < NFONTROWS; row++) {
		for (int col = 0; col < NFONTCOLS; col++) {
			if (font8x8_basic [c][row] & (1 << col)) {
				leds [f * FACELIGHTS + (row + ro) * NCOLS + col + co][R] = r;
				leds [f * FACELIGHTS + (row + ro) * NCOLS + col + co][G] = g;
				leds [f * FACELIGHTS + (row + ro) * NCOLS + col + co][B] = b;
			}
		}
	}
}

// find adjacent to position p; a is 0..7 clockwise around p {up, up/right, right, right/down, down, down/left, left, left/up}
static int
compute_adjacency (int p, int a)
{
	int face, row, col;
	index_to_frc (p, &face, &row, &col);

	switch (a) {
	case	DIR_UP:				row--;					break;
	case	DIR_UP_RIGHT:		row--;		col++;		break;
	case	DIR_RIGHT:						col++;		break;
	case	DIR_RIGHT_DOWN:		row++;		col++;		break;
	case	DIR_DOWN:			row++;					break;
	case	DIR_DOWN_LEFT:		row++;		col--;		break;
	case	DIR_LEFT:						col--;		break;
	case	DIR_LEFT_UP:		row--;		col--;		break;
	}

	if (row >= 0 && row <= NROWS - 1 && col >= 0 && col <= NCOLS - 1) {
		return frc_to_index (face, row, col);
	}

	// if both row and col are out of bounds, we declare "no adjacency" and return the same value as original
	if ((row < 0 || row >= NROWS) && (col < 0 || col >= NCOLS)) {
		return p;
	}

	if (row < 0) {										// overflow up
		switch (face) {
		case	0:
			face = 3;
			row = 0;
			col = NCOLS - col - 1;
			break;

		case	1:
			face = 0;
			row = NROWS - 1;
			break;

		case	2:
			face = 0;
			row = NROWS - col - 1;						// flip from row to column
			col = NCOLS - 1;							// and land on the near side column
			break;

		case	3:
			face = 0;
			row = 0;
			col = NCOLS - col - 1;
			break;

		case	4:
			face = 0;
			row = col;
			col = 0;
			break;
		}
	}

	if (row >= NROWS) {									// overflow down
		switch (face) {
		case	0:
			face = 1;
			row = 0;
			break;

		case	1:
		case	2:
		case	3:
		case	4:
			row = NROWS - 1;
			col = NCOLS - col - 1;
			face = (face + 2) % 5;
			if (face < 2) face++;
			break;

		}
	}

	if (col < 0) {										// overflow left
		switch (face) {
		case	0:
			face = 4;
			col = row;
			row = 0;
			break;

		case	1:
		case	2:
		case	3:
		case	4:
			face--;
			if (!face) face = 4;
			col = NCOLS - 1;
			break;
		}
	}

	if (col >= NCOLS) {									// overflow right
		switch (face) {
		case	0:
			face = 2;
			col = NCOLS - row - 1;
			row = 0;
			break;

		case	1:
		case	2:
		case	3:
		case	4:
			face++;
			if (face == 5) face = 1;
			col = 0;
			break;
		}
	}

	return frc_to_index (face, row, col);
}

// correct direction based on cube geometry on face change
int
fixdir (int dir, int from, int to)
{
	int result = dir;									// by default, retain the current direction

	// fix direction if we change face
	int src = from / FACELIGHTS;
	int dst = to / FACELIGHTS;

	if (!src && dst) {							// leaving the top face
		switch (dir) {
		case	DIR_UP:
		case	DIR_DOWN:
		case	DIR_RIGHT:
		case	DIR_LEFT:
			result = DIR_DOWN;
			break;

		default:
			switch (dst) {
			case	1:
				// all valid transitions to 1 are the same direction
				break;
			case	2:
				// valid transitions to 2 translate RIGHT{up, down} -> DOWN{right, left}
				result = result == DIR_UP_RIGHT ? DIR_RIGHT_DOWN: DIR_DOWN_LEFT;		// only way to go 0->2 is right (above) and right/up and right/down
				break;
			case	3:
				// valid transitions to 3 translate UP{left, right} -> DOWN{right, left}
				result = result == DIR_UP_RIGHT ? DIR_DOWN_LEFT : DIR_RIGHT_DOWN;
				break;
			case	4:
				// valid transitions to 4 translate LEFT{up, down} -> DOWN{left, right}
				result = result == DIR_LEFT_UP ? DIR_DOWN_LEFT : DIR_RIGHT_DOWN;
				break;
			}
			break;
		}

	} else if (!dst && src) {					// entering top face
		switch (result) {
		case	DIR_UP:
			switch (src) {
			case	1:	/* no change */				break;
			case	2:	result = DIR_LEFT;			break;
			case	3:	result = DIR_DOWN;			break;
			case	4:	result = DIR_RIGHT;			break;
			}
			break;

		case	DIR_UP_RIGHT:
			switch (src) {
			case	1:	/* no change */				break;
			case	2:	result = DIR_LEFT_UP;		break;
			case	3:	result = DIR_DOWN_LEFT;		break;
			case	4:	result = DIR_RIGHT_DOWN;	break;
			}
			break;

		case	DIR_LEFT_UP:
			switch (src) {
			case	1:	/* no change */				break;
			case	2:	result = DIR_DOWN_LEFT;		break;
			case	3:	result = DIR_RIGHT_DOWN;	break;
			case	4:	result = DIR_UP_RIGHT;		break;
			}
			break;

		}
	} else if (src != dst && src) {				// transitioning from one face to another, neither of which is the top face
		switch (result) {
		case	DIR_DOWN:
			result = DIR_UP;
			break;

		case	DIR_RIGHT_DOWN:
			if ((src & 1) == (dst & 1)) {		// wrapping through bottom; face 1 <-> 3 or face 2 <-> 4 only
				result = DIR_LEFT_UP;
			}
			break;

		case	DIR_DOWN_LEFT:
			if ((src & 1) == (dst & 1)) {		// wrapping through bottom; face 1 <-> 3 or face 2 <-> 4 only
				result = DIR_UP_RIGHT;
			}
			break;
		}
	}

	return result;
}

void
init_metadata(void)
{
	// initialize location map: every LED has an X, Y, and Z assigned
	for (int row = 0; row < NROWS; row++) {
		for (int col = 0; col < NCOLS; col++) {
			// the top face is at Y = 8, and varies in X and Z
			location_x [0 * FACELIGHTS + row * NCOLS + col] = col;
			location_y [0 * FACELIGHTS + row * NCOLS + col] = 8;
			location_z [0 * FACELIGHTS + row * NCOLS + col] = NROWS - row - 1;

			// the face below the top face is at Z = 0, and varies in X and Y
			location_x [1 * FACELIGHTS + row * NCOLS + col] = col;
			location_y [1 * FACELIGHTS + row * NCOLS + col] = NROWS - row - 1;
			location_z [1 * FACELIGHTS + row * NCOLS + col] = 0;

			// the face to the right of that is at X = 8, and varies in Y and Z
			location_x [2 * FACELIGHTS + row * NCOLS + col] = 8;
			location_y [2 * FACELIGHTS + row * NCOLS + col] = NROWS - row - 1;
			location_z [2 * FACELIGHTS + row * NCOLS + col] = col;

			// the face to the right of that is similar to the face under the top face; except its Z is 8 and its X is inverted
			location_x [3 * FACELIGHTS + row * NCOLS + col] = NCOLS - col - 1;
			location_y [3 * FACELIGHTS + row * NCOLS + col] = NROWS - row - 1;
			location_z [3 * FACELIGHTS + row * NCOLS + col] = 8;

			// the face to the right of that is at X = 0, and varies in Y and Z like #2, except Z is inverted
			location_x [4 * FACELIGHTS + row * NCOLS + col] = 0;
			location_y [4 * FACELIGHTS + row * NCOLS + col] = NROWS - row - 1;
			location_z [4 * FACELIGHTS + row * NCOLS + col] = NCOLS - col - 1;
		}
	}

//#define	DEBUG_LOCATION
#ifdef	DEBUG_LOCATION
// 2023 09 27 locations look good on casual inspection
	for (int i = 0; i < NLIGHTS; i++) {
		int f, r, c;
		index_to_frc (i, &f, &r, &c);
		printf ("%3d %d %d %d   %d %d %d\n", i, f, r, c, location_x [i], location_y [i], location_z [i]);
	}
#endif

	// initialize adjacency matrix
	for (int i = 0; i < NLIGHTS; i++) {
		for (int a = 0; a < 8; a++) {
			adjacency [i][a] = compute_adjacency (i, a);
		}
	}

//#define	DEBUG_ADJACENCY
#ifdef	DEBUG_ADJACENCY
	for (int i = 0; i < NLIGHTS; i++) {
		int f, r, c;
		index_to_frc (i, &f, &r, &c);
		printf ("%3d %d %d %d   ", i, f, r, c);
		for (int a = 0; a < 8; a++) {
			int fa, ra, ca;
			index_to_frc (find_adjacent (i, a), &fa, &ra, &ca);
			printf ("{%d %d %d} ", fa, ra, ca);
		}
		printf ("\n");
	}
#endif

}

