
/*
 *	p-colour-distance.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Generates a pattern where the pixel colour corresponds to the distance of the pixel
 *	to some arbitrary point.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

#define	NSTEPS	100

// Computes each pixel location's distance from a random point and colours accordingly.
bool
pattern_colour_distance (enum PatternPhase phase)
{
	static int rotor;
	static int xc1, yc1, zc1;
	static int xc2, yc2, zc2;
	static uint64_t start;

	if (phase == Start) {
		do {
			xc1 = (rand() & 1) * 8;
			yc1 = (rand() & 1) * 8;
			zc1 = (rand() & 1) * 8;
			xc2 = (rand() & 1) * 8;
			yc2 = (rand() & 1) * 8;
			zc2 = (rand() & 1) * 8;
		} while (xc1 == xc2 && yc1 == yc2 && zc1 == zc2);	// can't all be equal

		rotor = 0;
		start = time_us_64();
	}

	// compute current point
	double scale = (double) rotor / NSTEPS;
	double xc = xc1 + (xc2 - xc1) * scale;
	double yc = yc1 + (yc2 - yc1) * scale;
	double zc = zc1 + (zc2 - zc1) * scale;

	// compute distances; max distance can be 3*8^2 = 192
	for (int i = 0; i < NLIGHTS; i++) {
		double x = fabs ((double) location_x [i] - xc);
		double y = fabs ((double) location_y [i] - yc);
		double z = fabs ((double) location_z [i] - zc);
		int r = pow (2., x); if (r > 255) r = 255;
		int g = pow (2., y); if (g > 255) g = 255;
		int b = pow (2., z); if (b > 255) b = 255;
		setRGB_individual (i, r, g, b);
	}

	if (rotor++ > NSTEPS) {
		rotor = 0;

		// continue from last location
		xc1 = xc2;
		yc1 = yc2;
		zc1 = zc2;
		do {
			xc2 = (rand() & 1) * 8;
			yc2 = (rand() & 1) * 8;
			zc2 = (rand() & 1) * 8;
		} while (xc1 == xc2 && yc1 == yc2 && zc1 == zc2);	// can't all be equal

	}

	return seconds_since (start) < 30;
}

