
/*
 *	utils.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Include file for utilities.
 *
 *	2023 09 28	R. Krten		created
*/

#include <stdint.h>

extern uint8_t ex10 [10];								// logarithmic power with 10 values

uint8_t *pickRGB (uint8_t *rgb);						// selects random exponential-scale colour
int seconds_since (uint64_t t);
void direction_to_colour (int dir, int base, uint8_t *rgb);
double frand (void);

