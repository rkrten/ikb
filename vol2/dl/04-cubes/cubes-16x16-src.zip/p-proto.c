
/*
 *	p-proto.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Use this as a baseline for creating new patterns.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

bool
pattern_use_this_prototype_for_new_patterns (enum PatternPhase phase)
{
	static uint64_t start;
	static int rotor;

	if (phase == Start) {
		start = time_us_64();
		rotor = 0;
	}

	if (rotor++ > some_value) {
		rotor = 0;
		// do something interesting
	}

	return seconds_since (start) < 30;
}

