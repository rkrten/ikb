
/*
 *	p-random-alnum.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Generates random alphanumerical values on each face.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

#define	NSTEPS	200

bool
pattern_random_alnum (enum PatternPhase phase)
{
	static int rotor;
	static uint8_t on [NFACES][3];
	static char chars [NFACES];
	static enum { Warmup, Select, Fade, Hold } state;
	static uint64_t start;

	if (phase == Start) {
		rotor = 0;
		for (int face = 0; face < NFACES; face++) {
			int v;
			do {
				v = rand() & 127;
			} while (!isalnum (v) && v != '+' && v != '*');	// alnum plus selected symbols
			chars [face] = v;
			do {
				pickRGB (on [face]);
			} while (on [face][R] + on [face][G] + on [face][B] < 256);
		}
		state = Warmup;
		start = time_us_64();
	}

	switch (state) {
	case	Warmup:
		for (int face = 0; face < NFACES; face++) {
			set_face_individual (face, on [face][R] * rotor / NSTEPS, on [face][G] * rotor / NSTEPS , on [face][B] * rotor / NSTEPS);
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Select;
		}
		break;

	case	Select:
		for (int face = 0; face < NFACES; face++) {
			set_face_individual (face, on [face][R] * (NSTEPS - rotor) / NSTEPS, on [face][G] * (NSTEPS - rotor) / NSTEPS , on [face][B] * (NSTEPS - rotor) / NSTEPS);
			write_char_on_face_individual (face, chars [face], NROWS / 4, NCOLS / 4, on [face][R], on [face][G], on [face][B]);
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Fade;
		}
		break;

	case	Fade:
		for (int face = 0; face < NFACES; face++) {
			clear_face (face);
			if (rotor < NSTEPS) {
				write_char_on_face_individual (face, chars [face], NROWS / 4, NCOLS / 4, on [face][R] * (NSTEPS - rotor - 1) / NSTEPS, on [face][G] * (NSTEPS - rotor - 1) / NSTEPS, on [face][B] * (NSTEPS - rotor - 1) / NSTEPS);
			}
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Hold;
		}
		break;

	case	Hold:
		if (!rotor) {
			clear_leds ();
		}
		rotor++;
		break;
	}

	if (state == Hold && rotor >= NSTEPS) {
		if (seconds_since (start) < 30) {
			// cut'n'paste from "if (init)..." above
			for (int face = 0; face < NFACES; face++) {
				int v;
				do {
					v = rand() & 127;
				} while (!isalnum (v) && v != '+' && v != '*');	// alnum plus selected symbols
				chars [face] = v;
				do {
					pickRGB (on [face]);
				} while (on [face][R] + on [face][G] + on [face][B] < 256);
			}
			state = Warmup;
			rotor = 0;
		}
	}
	return (rotor <= NSTEPS);
}

