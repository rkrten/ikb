
/*
 *	p-alignment
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	A manufacturing / startup test pattern that labels the faces.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

bool
pattern_alignment (enum PatternPhase phase)
{
	static uint64_t start;
	static bool once = false;

	if (phase == Start) {
		if (!once) {
			clear_leds();
			for (int i = 0; i < NFACES; i++) {
				int face = i + 1;
				uint8_t rgb [3];
				rgb [R] = 255 * !!(face & 1);
				rgb [G] = 255 * !!(face & 2);
				rgb [B] = 255 * !!(face & 4);
				write_char_on_face_individual (i, i + '1', NROWS / 4, NCOLS / 4, rgb [R], rgb [G], rgb [B]);
			}
			start = time_us_64();
		}
	}

//#define	MANUFACTURING
#ifdef	MANUFACTURING
	return true;
#else	// MANUFACTURING
	if (!once && seconds_since (start) < 5) {
		return true;
	}
	once = true;
	return false;
#endif	// MANUFACTURING
}

