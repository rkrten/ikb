
/*
 *	utils.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Utilities
 *
 *	2023 09 28	R. Krten		Created
*/

#include "ikch42.h"

/*
 *	Random RGB selection
 *
 *	While 16M colours seems like a good idea, for something like this project,
 *	1000 colours are plenty. Therefore, the logic selects 10 x 10 x 10 colours
 *	on a exponential scale. This gives nice, vibrant colours.
 *
 *	To make the random number generation less biased, we reject 2.4% of the
 *	values. This is done by selecting 10 bits, but rejecting anything outside
 *	of the range 0..999 by getting another random value.
*/

uint8_t ex10 [10] = { 0, 1, 2, 4, 8, 16, 32, 64, 128, 255 };	// logarithmic power with 10 values

uint8_t *
pickRGB (uint8_t *rgb)
{
	unsigned int v;

	do {
		v = rand() & 1023;
	} while (v >= 1000 || !v);

	rgb [0] = ex10 [ v        % 10];
	rgb [1] = ex10 [(v / 10)  % 10];
	rgb [2] = ex10 [(v / 100) % 10];

	return rgb;
}

int
seconds_since (uint64_t t)
{
	return (time_us_64 () - t) / 1000000;
}

// Cycle dots in three planes
void
direction_to_colour (int dir, int base, uint8_t *rgb)
{
	int dircolour = ((dir + base) % 15) + 1;	// colours 1..15 (generated via {0..14} + 1)
	if (dircolour > 7) dircolour++;				// step over colour 8, which in three bits is colour 0
	rgb [R] = 255 * (dircolour & 1);
	rgb [G] = 255 * (dircolour & 2);
	rgb [B] = 255 * (dircolour & 4);
}

// return a random float value 0..1
double
frand (void)
{
	return (double) rand() / (double) RAND_MAX;
}

