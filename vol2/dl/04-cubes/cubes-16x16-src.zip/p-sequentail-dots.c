
/*
 *	p-sequential-dots.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Generates streaks of colours, like laser beams. Pew! Pew! Pew!
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

#define	MAXDOT	16

bool
pattern_sequential_dots (enum PatternPhase phase)
{
	static int rotor;
	static uint64_t start;
	static uint8_t rgbs [MAXDOT][3];					// dot colour
	static int dots [MAXDOT];							// dot location
	static int directions [MAXDOT];						// direction
	static int speeds [MAXDOT];							// how fast they change location
	static int reset_speeds [MAXDOT];					// speed to reset when timer pops
	static int phases [MAXDOT];							// where we are in the phase of operation
	static int base;									// colour base for direction colours
	int ndots;

	if (phase == Start) {
		rotor = 0;
		ndots = (rand() % (MAXDOT - 1)) + 1;
		base = rand() & 7;								// colour base for direction colours
		for (int i = 0; i < MAXDOT; i++) {
			// pick random locations and directions, make colour match direction
			dots [i] = rand() % NLIGHTS;
			directions [i] = rand() % 8;
			direction_to_colour (directions [i], base, rgbs [i]);
			speeds [i] = reset_speeds [i] = (rand() % 50) + 1;
		}
		start = time_us_64();
	}

	if (rotor++ >= 5) {
		rotor = 0;
		clear_leds ();
		for (int i = 0; i < MAXDOT; i++) {
			setRGB (dots [i], rgbs [i]);
			int l = find_adjacent (dots [i], directions [i]);
			if (l == dots [i]) {
				dots [i] = rand() % NLIGHTS;
				directions [i] = rand() % 8;
				direction_to_colour (directions [i], base, rgbs [i]);
				continue;
			}

			directions [i] = fixdir (directions [i], dots [i], l);
			dots [i] = l;
			direction_to_colour (directions [i], base, rgbs [i]);
			if (speeds [i]-- <= 0) {
				dots [i] = find_adjacent (dots [i], (directions [i] + 2) % 8);
				speeds [i] = reset_speeds [i];
			}
		}
	}

	return seconds_since (start) < 30;
}

