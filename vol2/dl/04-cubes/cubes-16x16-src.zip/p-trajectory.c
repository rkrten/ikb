
/*
 *	p-trajectory.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Lights pixels based on distance from a line.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

#define	NSTEPS	150

// Lights pixels along a trajectory
bool
pattern_trajectory (enum PatternPhase phase)
{
	static int rotor;
	static double a, b, c;								// plane: ax + by + cz = 0
	static double sqrt_abc;
	static uint64_t start;
	static uint8_t rgb_on [3], rgb_off [3];
	static int countdown;

	if (phase == Start) {
		do {
			a = (double) rand() / RAND_MAX * 16 - 8;
			b = (double) rand() / RAND_MAX * 16 - 8;
			c = (double) rand() / RAND_MAX * 16 - 8;
			sqrt_abc = sqrt (a * a + b * b + c * c);
		} while (sqrt_abc == 0);
		rgb_on [R] = rgb_off [R];
		rgb_on [G] = rgb_off [G];
		rgb_on [B] = rgb_off [B];
		pickRGB (rgb_off);

		rotor = 0;
		countdown = 50;
		start = time_us_64();
	}

	// compute distance value
	double distance = (double) (NSTEPS - rotor) / NSTEPS * 14;

	// compute distances; max distance can be 3*8^2 = 192
	int nlit = 0;
	for (int i = 0; i < NLIGHTS; i++) {
		double d = fabs (a * location_x [i] + b * location_y [i] + c * location_z [i]) / sqrt_abc;
		if (d < distance) {
			setRGB (i, rgb_on);
			nlit++;
		} else {
			setRGB (i, rgb_off);
		}
	}

	if (!nlit) {
		countdown--;
	}
	rotor++;
	if (countdown < 0 && seconds_since (start) < 30) {
		// copied from "if (init) ..." above
		do {
			a = (double) rand() / RAND_MAX * 16 - 8;
			b = (double) rand() / RAND_MAX * 16 - 8;
			c = (double) rand() / RAND_MAX * 16 - 8;
			sqrt_abc = sqrt (a * a + b * b + c * c);
		} while (sqrt_abc == 0);
		pickRGB (rgb_on);
		rgb_off [R] = 255 - rgb_on [R];
		rgb_off [G] = 255 - rgb_on [G];
		rgb_off [B] = 255 - rgb_on [B];

		rotor = 0;
		countdown = 50;
	}

	return countdown >= 0;
}

