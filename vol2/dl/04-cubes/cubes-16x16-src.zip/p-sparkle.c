
/*
 *	p-sparkle.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Randomly assign RGB value to pixels.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

bool
pattern_sparkle (enum PatternPhase phase)
{
	static uint64_t start;

	if (phase == Start) {
		start = time_us_64();
	}

	uint8_t rgb [3];
	setRGB (rand() % NLIGHTS, pickRGB (rgb));

	return seconds_since (start) < 30;
}

