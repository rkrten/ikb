
/*
 *	hardware.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Include file for hardware driver.
 *
 *	2023 09 26	R. Krten		created
*/

// hardware defines the ordering of the LEDs
#define	G		0
#define	R		1
#define	B		2

#define	DEFAULT_PERSISTENCE	80							// as a percentage of the previous sample

void write_leds (void);
void init_hardware (void);
void set_persistence (int f);

