
/*
 *	hardware.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Hardware interface for borg cube, IKCH42A.
 *
 *	2023 09 28	R. Krten		Separated out from main
*/

#include "ikch42.h"
#include "ws2812.pio.h"

static uint8_t	persistence [NLIGHTS][3];		// should be an int if we want to avoid chaotic overflow when updating s [colour] with fadeout and factor > 100
static int		factor = DEFAULT_PERSISTENCE;

void
set_persistence (int f)
{
	factor = f;
}

/*
 *	On the 16x16 cube, the LED ordering is odd/even column major ordered:
 *
 *	0		31		32		...		223		224		255
 *	1		30		33		...		222		225		254
 *	2		29		34		...		221		226		253
 *	...		...		...		...		...		...		...
 *	13		18		45		...		210		237		242
 *	14		17		46		...		209		238		241
 *	15		16		47		...		208		239		240
 *
 *	led_number = col * NROWS + row					(when col is even)
 *	led_number = col * NROWS + (NROWS - row - 1)	(when col is odd)
 *
 *	This is (way) different than the software-presented layout (which is row major),
 *	so the hardware serializer performs the conversion using pixel_to_index().
*/

// optimizing this to generate a table just wastes space; the speed is limited by the FIFO, not the translation
static inline int
pixel_to_index (int p)
{
	int col = p / NROWS;
	int row = p % NROWS;

	if (col & 1) {
		row = NROWS - row - 1;
	}

	return col + NCOLS * row;
}

void
write_leds (void)
{
	uint64_t start = time_us_64();
	// we write one value to each face's state machine, and then move on to the next value
	for (int pixel = 0; pixel < FACELIGHTS; pixel++) {
		uint8_t *l = leds [pixel_to_index (pixel)];
		uint8_t *s = persistence [pixel_to_index (pixel)];

		for (int face = 0; face < NFACES; face++) {

			int rgb3 [3];
			for (int colour = 0; colour < 3; colour++) {
				rgb3 [colour] = l [colour] + s [colour];
				if (rgb3 [colour] > 255) {
					rgb3 [colour] = 255;
				}
				s [colour] = rgb3 [colour] * factor / 100;	// fadeout
			}

		    pio_sm_put_blocking (face < 4 ? pio0 : pio1, face % 4, (rgb3 [0] << 8) + (rgb3 [1] << 16) + (rgb3 [2] << 24));

			// stride to next face
		    l += FACELIGHTS * 3;
		    s += FACELIGHTS * 3;
		}
	}
	uint64_t stop = time_us_64();
	printf ("write_led %lld ", stop - start);

	// there's a minimum amount of time that we need to cease activity in order for the latch values to propagate to the LEDs
	sleep_us (300);
}

/*
 *	Initialize PIOs and their state machines.
 *
 *	There are two PIO engines, each with four state machines.
 *	Both engines execute the exact same programs for all state machines.
 *
 *	We assign them in order to the faces; GPIOs are bound directly below.
 *
 *	The WS2812 example from the website indicates speed of 800k (at 7ms/iteration, 140Hz refresh rate).
 *	We've managed to bump it higher; at 1M4 we start to see tearing, 1M3 is fine for things that don't
 *	consume a lot of power, and 1M1 seems stable even with all the LEDs on.
 *
 *		1M3 = 4565 us / iteration, 220 Hz refresh
 *		1M1 = 5397 us / iteration, 185 Hz refresh
*/

void
init_hardware (void)
{
	uint offset;
	const int speed = 1100000;

	offset = pio_add_program (pio0, &ws2812_program);			// location on PBM-02 "dud" board I'm using for the prototype:
	ws2812_program_init (pio0, 0, offset, 18, speed, false);	// pin 24, top of R12, purple (1)
	ws2812_program_init (pio0, 1, offset, 19, speed, false);	// pin 25, right of R11, green (2)
	ws2812_program_init (pio0, 2, offset, 20, speed, false);	// pin 26, left of R14, gray (3)
	ws2812_program_init (pio0, 3, offset, 21, speed, false);	// pin 27, right of R15, black (4)

	offset = pio_add_program (pio1, &ws2812_program);
	ws2812_program_init (pio1, 0, offset, 22, speed, false);	// pin 29, right of R16, white (5)
}

