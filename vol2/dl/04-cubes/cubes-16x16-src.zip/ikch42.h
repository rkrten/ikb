
/*
 *	ikch42.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module is the main include for the borg cube.
 *
 *	2023 09 26	R. Krten		created
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"

#define NELEMENTS(_x) ((sizeof(_x)/sizeof((_x)[0])))

#include "utils.h"
#include "hardware.h"
#include "geometry.h"
#include "pattern.h"

bool pattern_alignment (enum PatternPhase);
bool pattern_colour_distance (enum PatternPhase);
bool pattern_mover (enum PatternPhase);
bool pattern_use_this_prototype_for_new_patterns (enum PatternPhase);
bool pattern_random_alnum (enum PatternPhase);
bool pattern_sequential_dots (enum PatternPhase);
bool pattern_sine (enum PatternPhase);
bool pattern_sparkle (enum PatternPhase);
bool pattern_tetris (enum PatternPhase);
bool pattern_top_bleed (enum PatternPhase);
bool pattern_trajectory (enum PatternPhase);
