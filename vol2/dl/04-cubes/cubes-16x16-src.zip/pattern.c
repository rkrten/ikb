
/*
 *	pattern.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This drives the pattern engine, and contains pattern utility functions.
 *
 *	2023 10 19	R. Krten		created
*/

#include "ikch42.h"

static Pattern *patterns [] =
{
	pattern_alignment,									// shows up once at power up; persists during #define MANUFACTURING
	pattern_tetris,
	pattern_sine,
	pattern_top_bleed,
	pattern_sequential_dots,
	pattern_mover,
	// Past here consume too much power for a mere USB-powered PICO!!!
	// With a PC power supply, the wires get hot!
	pattern_trajectory,
	pattern_random_alnum,
	pattern_sparkle,
	pattern_colour_distance,
#if 0
#endif
};

static enum States { Starting, Running, Finishing } state = Starting;

static int pattern = 0;

static int
next_pattern (void)
{
	return pattern = (pattern + 1) % NELEMENTS (patterns);
}

void
generate_pattern (void)
{
	static uint64_t start;

	switch (state) {
	case	Starting: {									// initialize the pattern
		bool run = patterns [pattern] (Start);
		while (!run) {									// allow a pattern to decline running, in which case, select another one
			run = patterns [next_pattern()] (Start);
		}
		state = Running;
		break; }

	case	Running:
		// run the pattern -- it returns false when it's done
		if (!patterns [pattern] (Run)) {
			next_pattern();
			state = Finishing;
			set_persistence (DEFAULT_PERSISTENCE);		// each pattern can reset this to whatever they want, this is pleasing for most
			clear_leds();
			start = time_us_64();
		}
		break;

	case	Finishing:
		if (time_us_64() - start > 500000) {			// fade out the pattern, and then restart
			state = Starting;
		}
		break;
	}
}

