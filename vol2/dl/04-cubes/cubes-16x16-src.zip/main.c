
/*
 *	main.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module drives the borg cube, IKCH42A.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

// not the best, but better than nothing; more research required
static void
init_seed (void)
{
	adc_init();
	adc_gpio_init(26);
	uint64_t hash = 0;
	for (int j = 0; j < 1000; j++) {
		for (int i = 0; i < 3; i++) {
			adc_select_input(i);
		    uint16_t result = adc_read();
			hash += result;
			sleep_us (100);
		}
	}
	srand (hash);
}

extern int t0h, t0l, t1h, t1l, tdelay;

extern void reset (void);

int main ()
{
//#define	DEBUG
#ifdef	DEBUG
stdio_init_all ();
//stdio_set_translate_crlf (&stdio_usb, false);
sleep_ms (4000);
#endif	// DEBUG

	init_hardware ();
	init_seed ();
	init_metadata ();

int rotor = 0;
	for (;;) {
rotor++;
uint64_t start = time_us_64();
		generate_pattern ();
uint64_t stop = time_us_64();
if (rotor > 100) {
printf ("Pattern %lld", stop - start);
}
		write_leds ();
		sleep_ms (1);
stop = time_us_64();
if (rotor > 100) {
printf (" %5.1f FPS\n", 1e6 / (double) (stop - start));
rotor = 0;
}
	}
}

