
/*
 *	p-mover.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Moves dots in a brownian-motion like manner.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

// mover pattern
bool
pattern_mover (enum PatternPhase phase)
{
	static int rotor;
	static uint64_t start;

	if (phase == Start) {
		clear_leds();
		// decide on a population
		int pop = (rand () % 40) + 40;					// 60 +/- 20 as a start
		int base = rand() % 7;							// colour base for face colours
		while (pop--) {
			int index = rand () % NLIGHTS;
			int face = ((index_to_face (index) + base) % 7) + 1;
			uint8_t rgb [3];
			rgb [R] = 255 * (face & 1);
			rgb [G] = 255 * (face & 2);
			rgb [B] = 255 * (face & 4);
			setRGB (index, rgb);
		}
		set_persistence (98);							// this pattern wants a high persistence
		start = time_us_64();
		rotor = 0;
	}

	if (rotor++ > 5) {
		int todo = 5;									// number of pieces to move at once
		rotor = 0;
		int moved [NLIGHTS] = { 0 };

		while (todo) {
			// find a non-empty source
			int direction = rand() % 8;					// any of the adjacency directions
			int src;
			do {
				src = rand() % NLIGHTS;
				if (moved [src]) continue;
			} while (isempty (src));

			int dst = find_adjacent (src, direction);
			if (dst == src) {
				continue;
			}
			if (!isempty (dst)) {
				continue;
			}
			// and move the light
			setRGB (dst, leds [src]);
			clear_led (src);
			moved [dst] = true;
			todo--;
		}
	}

	return seconds_since (start) < 30;
}
