
/*
 *	geometry.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Includes for geometry.c
 *
 *	2023 09 28	R. Krten		created
*/

#define	NFACES		5
#define	NROWS		16
#define	NCOLS		16
#define	FACELIGHTS	(NROWS * NCOLS)
#define	NLIGHTS	(NFACES * FACELIGHTS)

#define	DIR_UP				0
#define	DIR_UP_RIGHT		1
#define	DIR_RIGHT			2
#define	DIR_RIGHT_DOWN		3
#define	DIR_DOWN			4
#define	DIR_DOWN_LEFT		5
#define	DIR_LEFT			6
#define	DIR_LEFT_UP			7

extern uint8_t	leds [NLIGHTS][3];						// GRB order
extern uint8_t	location_x [NLIGHTS];					// LED locations
extern uint8_t	location_y [NLIGHTS];
extern uint8_t	location_z [NLIGHTS];
extern uint16_t	adjacency [NLIGHTS][8];					// pre-computed adjacency matrix, 8 elements {up, up/right, right, right/down, down, down/left, left, left/up}

static inline void
setRGB_individual (int n, int r, int g, int b)
{
	leds [n][R] = r;
	leds [n][G] = g;
	leds [n][B] = b;
}

static inline void
setRGB (int n, uint8_t *rgb)
{
	leds [n][0] = rgb [0];
	leds [n][1] = rgb [1];
	leds [n][2] = rgb [2];
}

static inline void
clear_leds (void)
{
	memset (leds, 0, sizeof (leds));
}

static inline void
clear_led (int led)
{
	leds [led][0] = leds [led][1] = leds [led][2] = 0;
}

static void
clear_face (int face)
{
	if (face >= 0 && face < NFACES) {
		memset (&leds [face * FACELIGHTS][0], 0, sizeof (leds [0][0]) * FACELIGHTS * 3);
	}
}

static inline int
frc_to_index (int f, int r, int c)
{
	return f * FACELIGHTS + r * NCOLS + c;
}

static inline void
index_to_frc (int i, int *f, int *r, int *c)
{
	*f = i / FACELIGHTS;
	i %= FACELIGHTS;
	*r = i / NROWS;
	i %= NROWS;
	*c = i;
}

static inline int
index_to_face (int i)
{
	return i / FACELIGHTS;
}

static inline bool
isempty (int l)
{
	return leds [l][R] == 0 && leds [l][G] == 0 && leds [l][B] == 0;
}

static inline int
find_adjacent (int p, int a)
{
	return adjacency [p][a];
}

void init_metadata(void);
void set_face (int face, uint8_t *rgb);
void set_face_individual (int face, int r, int g, int b);
void write_char_on_face_individual (int f, int c, int ro, int co, int r, int g, int b);
int fixdir (int dir, int from, int to);
