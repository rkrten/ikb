
/*
 *	p-top-bleed.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Generate melting egg starting at top of cube and running down sides.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

/*
 *	Starts with 4 dots in the center of the top, and expands a band of colour down the cube.
 *	Effectively, there are 12 rings; 4 on the top and 8 down the sides.
*/

bool
pattern_top_bleed (enum PatternPhase phase)
{
	static int ring;
	static int rotor;
	static uint8_t rgb [3];
	static uint8_t ring0 [] = { 27, 28, 35, 36 };
	static uint8_t ring1 [] = { 18, 19, 20, 21, 26, 29, 34, 37, 42, 43, 44, 45 };
	static uint8_t ring2 [] = { 9, 10, 11, 12, 13, 14, 17, 22, 25, 30, 33, 38, 41, 46, 49, 50, 51, 52, 53, 54 };
	static uint8_t ring3 [] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 56, 57, 58, 59, 60, 61, 62, 63 };

	if (phase == Start) {
		ring = 0;
		rotor = 0;
		pickRGB (rgb);
	}

	clear_leds ();
	switch (ring) {
	case	0:	for (int i = 0; i < NELEMENTS (ring0); i++) setRGB (ring0 [i], rgb); break;
	case	1:	for (int i = 0; i < NELEMENTS (ring1); i++) setRGB (ring1 [i], rgb); break;
	case	2:	for (int i = 0; i < NELEMENTS (ring2); i++) setRGB (ring2 [i], rgb); break;
	case	3:	for (int i = 0; i < NELEMENTS (ring3); i++) setRGB (ring3 [i], rgb); break;
	default: {
		int base = ring - 4;
		for (int face = 1; face < NFACES; face++) {
			for (int i = 0; i < NROWS; i++) {
				setRGB (face * FACELIGHTS + base * NCOLS + i, rgb);
			}
		}
		break; }
	}

	if (rotor++ > 10) {
		ring++;
		rotor = 0;
	}
	return (ring < 20);
}

