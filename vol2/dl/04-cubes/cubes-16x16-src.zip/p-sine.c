
/*
 *	p-sine.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Generates columns of sines, with each value being randomly offset.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

bool
pattern_sine (enum PatternPhase phase)
{
	static uint64_t 	start;
	static int			rotor;
	static double		freq [NFACES - 1][NCOLS];
	static uint8_t		rgbs [NFACES - 1][3];
	static int			iteration;

	if (phase == Start) {
		start = time_us_64();
		rotor = 0;

		for (int face = 0; face < NFACES - 1; face++) {
			freq [face][0] = M_PI / 50. + frand() / M_PI / 10;
			double inc = frand() / M_PI / 100.;
			for (int c = 1; c < NCOLS; c++) {
				freq [face][c] = freq [face][c - 1] + inc;
			}
			pickRGB (rgbs [face]);
		}
		iteration = 0;
		set_persistence (90);
	}

	if (rotor++ >= 1) {
		rotor = 0;
		iteration++;
		for (int face = 0; face < NFACES - 1; face++) {
			for (int c = 0; c < NCOLS; c++) {
				double v = (sin (freq [face][c] * iteration) + 1) * (NROWS / 2);
				for (int r = 0; r < NROWS; r++) {
					if ((int) v == r) {
						setRGB (frc_to_index (face + 1, r, c), rgbs [face]);
					} else {
						clear_led (frc_to_index (face + 1, r, c));
					}
				}
			}
		}
	}

	return seconds_since (start) < 30;
}
