
/*
 *	p-tetris.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Auto-play tetris on the cube.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

/*
 *	The tetrominos, using the standard colour scheme:
 *		I	light blue
 *		J	dark blue
 *		L	orange
 *		o	yellow
 *		S	green
 *		T	purple
 *		Z	red
*/

typedef struct
{
	uint32_t	colour;									// 0x AA RR GG BB
	char		name;									// ASCII character name, one of I, J, L, o, S, T, Z
	struct {
		int		h;
		int		w;
		char	array [4][4];							// can occupy up to 4 high or 4 wide, depending on rotation
	}			variants [4];							// up to four different rotations of each
} Tetromino;

Tetromino tetrominos [] =
{
	{ 0 },												// make the zero-th one invalid

	{
		0x008080ff, 'I',
		{
			{ 1, 4, { 1, 1, 1, 1,  0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 4, 1, { 1, 0, 0, 0,  1, 0, 0, 0,  1, 0, 0, 0,  1, 0, 0, 0 } },
			{ 1, 4, { 1, 1, 1, 1,  0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 4, 1, { 1, 0, 0, 0,  1, 0, 0, 0,  1, 0, 0, 0,  1, 0, 0, 0 } },
		}
	},

	{
		0x000000ff, 'J',
		{
			{ 3, 2, { 0, 1, 0, 0,  0, 1, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 1, 0, 0, 0,  1, 1, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 1, 1, 0, 0,  1, 0, 0, 0,  1, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 1, 1, 1, 0,  0, 0, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
		}
	},

	{
		0x00ff8000, 'L',
		{
			{ 3, 2, { 1, 0, 0, 0,  1, 0, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 1, 1, 1, 0,  1, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 1, 1, 0, 0,  0, 1, 0, 0,  0, 1, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 0, 0, 1, 0,  1, 1, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
		}
	},

	{
		0x00ffff00, 'o',
		{
			{ 2, 2, { 1, 1, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 2, { 1, 1, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 2, { 1, 1, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 2, { 1, 1, 0, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
		}
	},

	{
		0x0000ff00, 'S',
		{
			{ 2, 3, { 0, 1, 1, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 1, 0, 0, 0,  1, 1, 0, 0,  0, 1, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 0, 1, 1, 0,  1, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 1, 0, 0, 0,  1, 1, 0, 0,  0, 1, 0, 0,  0, 0, 0, 0 } },
		}
	},

	{
		0x00ff00ff, 'T',
		{
			{ 2, 3, { 0, 1, 0, 0,  1, 1, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 1, 0, 0, 0,  1, 1, 0, 0,  1, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 1, 1, 1, 0,  0, 1, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 0, 1, 0, 0,  1, 1, 0, 0,  0, 1, 0, 0,  0, 0, 0, 0 } },
		}
	},

	{
		0x00ff0000, 'Z',
		{
			{ 2, 3, { 1, 1, 0, 0,  0, 1, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 0, 1, 0, 0,  1, 1, 0, 0,  1, 0, 0, 0,  0, 0, 0, 0 } },
			{ 2, 3, { 1, 1, 0, 0,  0, 1, 1, 0,  0, 0, 0, 0,  0, 0, 0, 0 } },
			{ 3, 2, { 0, 1, 0, 0,  1, 1, 0, 0,  1, 0, 0, 0,  0, 0, 0, 0 } },
		}
	},
};

bool
pattern_tetris (enum PatternPhase phase)
{
#if 0
	static uint64_t start;
	static int rotor = 0;
	static int boards [NFACES][NROWS][NCOLS] = { 0 };

	if (phase == Start) {
		start = time_us_64();
		clear_leds();
	}

	if (rotor++ > 5) {
		rotor = 0;
		switch (rand() % 7) {
		case	0:										// I, light blue
			break;

		case	1:										// J, dark blue
			break;

		case	2:										// L, orange
			break;

		case	3:										// o, yellow
			break;

		case	4:										// S, green
			break;

		case	5:										// T, purple
			break;

		case	6:										// Z, red
			break;

		}
	}

	return seconds_since (start) < 30;
#else
	return false;
#endif
}
