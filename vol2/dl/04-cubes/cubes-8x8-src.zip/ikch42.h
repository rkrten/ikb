
/*
 *	ikch42.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module is the main include for the borg cube.
 *
 *	2023 09 26	R. Krten		created
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"

#define NELEMENTS(_x) ((sizeof(_x)/sizeof((_x)[0])))

#include "utils.h"
#include "hardware.h"
#include "geometry.h"

