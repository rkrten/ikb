
/*
 *	main.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	This module drives the borg cube, IKCH42A.
 *
 *	2023 09 26	R. Krten		created
*/

#include "ikch42.h"

// alignment pattern (shows once at startup in general case, otherwise permanently for manufacturing case)
static bool
pattern_alignment (bool init)
{
	static uint64_t start;
	static bool once = false;

	if (init) {
		if (!once) {
			clear_leds();
			for (int i = 0; i < NFACES; i++) {
				int face = i + 1;
				uint8_t rgb [3];
				rgb [R] = 255 * !!(face & 1);
				rgb [G] = 255 * !!(face & 2);
				rgb [B] = 255 * !!(face & 4);
				write_char_on_face_individual (i, i + '1', rgb [R], rgb [G], rgb [B]);
			}
			start = time_us_64();
		}
	}

//#define	MANUFACTURING
#ifdef	MANUFACTURING
	return true;
#else	// MANUFACTURING
	if (!once && seconds_since (start) < 5) {
		return true;
	}
	once = true;
	return false;
#endif	// MANUFACTURING
}

static int value_r = 1, value_g = 2, value_b = 3;

// colour sequence -- for test only
static int e [] = {0, 1, 2, 4, 8, 16, 32, 64, 128, 255};
static bool
pattern_sequence_colour (bool init)
{
	static uint64_t start;
	static int rotor = 0;

	if (init) {
		clear_leds();
	}

	uint8_t rgb [3];
	for (int i = 0; i < NLIGHTS; i++) {
/*
		int octal = (rotor + i) / 16;
		rgb [R] = octal & 7;
		rgb [G] = (octal >> 3) & 7;
		rgb [B] = (octal >> 6) & 7;
*/
		rgb [R] = e [value_r];
		rgb [G] = e [value_g];
		rgb [B] = e [value_b];
		setRGB (i, rgb);
	}

	return true;
}

// mover pattern
static bool
pattern_mover (bool init)
{
	static int rotor;
	static uint64_t start;

	if (init) {
		clear_leds();
		// decide on a population
		int pop = (rand () % 40) + 40;					// 60 +/- 20 as a start
		int base = rand() % 7;							// colour base for face colours
		while (pop--) {
			int index = rand () % NLIGHTS;
			int face = ((index_to_face (index) + base) % 7) + 1;
			uint8_t rgb [3];
			rgb [R] = 255 * (face & 1);
			rgb [G] = 255 * (face & 2);
			rgb [B] = 255 * (face & 4);
			setRGB (index, rgb);
		}
		set_persistence (90);							// this pattern wants a high persistence
		start = time_us_64();
		rotor = 0;
	}

	if (rotor++ > 5) {
		int todo = 5;									// number of pieces to move at once
		rotor = 0;
		int moved [NLIGHTS] = { 0 };

		while (todo) {
			// find a non-empty source
			int direction = rand() % 8;					// any of the adjacency directions
			int src;
			do {
				src = rand() % NLIGHTS;
				if (moved [src]) continue;
			} while (isempty (src));

			int dst = find_adjacent (src, direction);
			if (dst == src) {
				continue;
			}
			if (!isempty (dst)) {
				continue;
			}
			// and move the light
			setRGB (dst, leds [src]);
			clear_led (src);
			moved [dst] = true;
			todo--;
		}
	}

	return seconds_since (start) < 30;
}

static bool
pattern_sparkle (bool init)
{
	static uint64_t start;

	if (init) {
		start = time_us_64();
	}

	uint8_t rgb [3];
	setRGB (rand() % NLIGHTS, pickRGB (rgb));

	return seconds_since (start) < 30;
}

static bool
pattern_random_alnum (bool init)
{
#define	NSTEPS	200
	static int rotor;
	static uint8_t on [NFACES][3];
	static char chars [NFACES];
	static enum { Warmup, Select, Fade, Hold } state;
	static uint64_t start;

	if (init) {
		rotor = 0;
		for (int face = 0; face < NFACES; face++) {
			int v;
			do {
				v = rand() & 127;
			} while (!isalnum (v) && v != '+' && v != '*');	// alnum plus selected symbols
			chars [face] = v;
			do {
				pickRGB (on [face]);
			} while (on [face][R] + on [face][G] + on [face][B] < 256);
		}
		state = Warmup;
		start = time_us_64();
	}

	switch (state) {
	case	Warmup:
		for (int face = 0; face < NFACES; face++) {
			set_face_individual (face, on [face][R] * rotor / NSTEPS, on [face][G] * rotor / NSTEPS , on [face][B] * rotor / NSTEPS);
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Select;
		}
		break;

	case	Select:
		for (int face = 0; face < NFACES; face++) {
			set_face_individual (face, on [face][R] * (NSTEPS - rotor) / NSTEPS, on [face][G] * (NSTEPS - rotor) / NSTEPS , on [face][B] * (NSTEPS - rotor) / NSTEPS);
			write_char_on_face_individual (face, chars [face], on [face][R], on [face][G], on [face][B]);
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Fade;
		}
		break;

	case	Fade:
		for (int face = 0; face < NFACES; face++) {
			clear_face (face);
			if (rotor < NSTEPS) {
				write_char_on_face_individual (face, chars [face], on [face][R] * (NSTEPS - rotor - 1) / NSTEPS, on [face][G] * (NSTEPS - rotor - 1) / NSTEPS, on [face][B] * (NSTEPS - rotor - 1) / NSTEPS);
			}
		}
		if (rotor++ >= NSTEPS) {
			rotor = 0;
			state = Hold;
		}
		break;

	case	Hold:
		if (!rotor) {
			clear_leds ();
		}
		rotor++;
		break;
	}

	if (state == Hold && rotor >= NSTEPS) {
		if (seconds_since (start) < 30) {
			// cut'n'paste from "if (init)..." above
			for (int face = 0; face < NFACES; face++) {
				int v;
				do {
					v = rand() & 127;
				} while (!isalnum (v) && v != '+' && v != '*');	// alnum plus selected symbols
				chars [face] = v;
				do {
					pickRGB (on [face]);
				} while (on [face][R] + on [face][G] + on [face][B] < 256);
			}
			state = Warmup;
			rotor = 0;
		}
	}
	return (rotor <= NSTEPS);
#undef	NSTEPS
}

// Computes each pixel location's distance from a random point and colours accordingly.
static bool
pattern_colour_distance (bool init)
{
#define	NSTEPS	100
	static int rotor;
	static int xc1, yc1, zc1;
	static int xc2, yc2, zc2;
	static uint64_t start;

	if (init) {
		do {
			xc1 = (rand() & 1) * 8;
			yc1 = (rand() & 1) * 8;
			zc1 = (rand() & 1) * 8;
			xc2 = (rand() & 1) * 8;
			yc2 = (rand() & 1) * 8;
			zc2 = (rand() & 1) * 8;
		} while (xc1 == xc2 && yc1 == yc2 && zc1 == zc2);	// can't all be equal

		rotor = 0;
		start = time_us_64();
	}

	// compute current point
	double scale = (double) rotor / NSTEPS;
	double xc = xc1 + (xc2 - xc1) * scale;
	double yc = yc1 + (yc2 - yc1) * scale;
	double zc = zc1 + (zc2 - zc1) * scale;

	// compute distances; max distance can be 3*8^2 = 192
	for (int i = 0; i < NLIGHTS; i++) {
		double x = fabs ((double) location_x [i] - xc);
		double y = fabs ((double) location_y [i] - yc);
		double z = fabs ((double) location_z [i] - zc);
		int r = pow (2., x); if (r > 255) r = 255;
		int g = pow (2., y); if (g > 255) g = 255;
		int b = pow (2., z); if (b > 255) b = 255;
		setRGB_individual (i, r, g, b);
	}

	if (rotor++ > NSTEPS) {
		rotor = 0;

		// continue from last location
		xc1 = xc2;
		yc1 = yc2;
		zc1 = zc2;
		do {
			xc2 = (rand() & 1) * 8;
			yc2 = (rand() & 1) * 8;
			zc2 = (rand() & 1) * 8;
		} while (xc1 == xc2 && yc1 == yc2 && zc1 == zc2);	// can't all be equal

	}

	return seconds_since (start) < 30;
#undef	NSTEPS
}

// Lights pixels along a trajectory
static bool
pattern_trajectory (bool init)
{
#define	NSTEPS	150
	static int rotor;
	static double a, b, c;								// plane: ax + by + cz = 0
	static double sqrt_abc;
	static uint64_t start;
	static uint8_t rgb_on [3], rgb_off [3];
	static int countdown;

	if (init) {
		do {
			a = (double) rand() / RAND_MAX * 16 - 8;
			b = (double) rand() / RAND_MAX * 16 - 8;
			c = (double) rand() / RAND_MAX * 16 - 8;
			sqrt_abc = sqrt (a * a + b * b + c * c);
		} while (sqrt_abc == 0);
		rgb_on [R] = rgb_off [R];
		rgb_on [G] = rgb_off [G];
		rgb_on [B] = rgb_off [B];
		pickRGB (rgb_off);

		rotor = 0;
		countdown = 50;
		start = time_us_64();
	}

	// compute distance value
	double distance = (double) (NSTEPS - rotor) / NSTEPS * 14;

	// compute distances; max distance can be 3*8^2 = 192
	int nlit = 0;
	for (int i = 0; i < NLIGHTS; i++) {
		double d = fabs (a * location_x [i] + b * location_y [i] + c * location_z [i]) / sqrt_abc;
		if (d < distance) {
			setRGB (i, rgb_on);
			nlit++;
		} else {
			setRGB (i, rgb_off);
		}
	}

	if (!nlit) {
		countdown--;
	}
	rotor++;
	if (countdown < 0 && seconds_since (start) < 30) {
		// copied from "if (init) ..." above
		do {
			a = (double) rand() / RAND_MAX * 16 - 8;
			b = (double) rand() / RAND_MAX * 16 - 8;
			c = (double) rand() / RAND_MAX * 16 - 8;
			sqrt_abc = sqrt (a * a + b * b + c * c);
		} while (sqrt_abc == 0);
		pickRGB (rgb_on);
		rgb_off [R] = 255 - rgb_on [R];
		rgb_off [G] = 255 - rgb_on [G];
		rgb_off [B] = 255 - rgb_on [B];

		rotor = 0;
		countdown = 50;
	}

	return countdown >= 0;
#undef	NSTEPS
}

/*
 *	Starts with 4 dots in the center of the top, and expands a band of colour down the cube.
 *	Effectively, there are 12 rings; 4 on the top and 8 down the sides.
*/

static bool
pattern_top_bleed (bool init)
{
	static int ring;
	static int rotor;
	static uint8_t rgb [3];
	static uint8_t ring0 [] = { 27, 28, 35, 36 };
	static uint8_t ring1 [] = { 18, 19, 20, 21, 26, 29, 34, 37, 42, 43, 44, 45 };
	static uint8_t ring2 [] = { 9, 10, 11, 12, 13, 14, 17, 22, 25, 30, 33, 38, 41, 46, 49, 50, 51, 52, 53, 54 };
	static uint8_t ring3 [] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 16, 23, 24, 31, 32, 39, 40, 47, 48, 55, 56, 57, 58, 59, 60, 61, 62, 63 };

	if (init) {
		ring = 0;
		rotor = 0;
		pickRGB (rgb);
	}

	clear_leds ();
	switch (ring) {
	case	0:	for (int i = 0; i < NELEMENTS (ring0); i++) setRGB (ring0 [i], rgb); break;
	case	1:	for (int i = 0; i < NELEMENTS (ring1); i++) setRGB (ring1 [i], rgb); break;
	case	2:	for (int i = 0; i < NELEMENTS (ring2); i++) setRGB (ring2 [i], rgb); break;
	case	3:	for (int i = 0; i < NELEMENTS (ring3); i++) setRGB (ring3 [i], rgb); break;
	default: {
		int base = ring - 4;
		for (int face = 1; face < NFACES; face++) {
			for (int i = 0; i < NROWS; i++) {
				setRGB (face * FACELIGHTS + base * NCOLS + i, rgb);
			}
		}
		break; }
	}

	if (rotor++ > 10) {
		ring++;
		rotor = 0;
	}
	return (ring < 12);
}

// Cycle dots in three planes
static void
direction_to_colour (int dir, int base, uint8_t *rgb)
{
	int dircolour = ((dir + base) % 15) + 1;	// colours 1..15 (generated via {0..14} + 1)
	if (dircolour > 7) dircolour++;				// step over colour 8, which in three bits is colour 0
	rgb [R] = 255 * (dircolour & 1);
	rgb [G] = 255 * (dircolour & 2);
	rgb [B] = 255 * (dircolour & 4);
}

static bool
pattern_sequential_dots (bool init)
{
#define	MAXDOT	5
	static int rotor;
	static uint64_t start;
	static uint8_t rgbs [MAXDOT][3];					// dot colour
	static int dots [MAXDOT];							// dot location
	static int directions [MAXDOT];						// direction
	static int speeds [MAXDOT];							// how fast they change location
	static int reset_speeds [MAXDOT];					// speed to reset when timer pops
	static int phases [MAXDOT];							// where we are in the phase of operation
	static int base;									// colour base for direction colours
	int ndots;

	if (init) {
		rotor = 0;
		ndots = (rand() % (MAXDOT - 1)) + 1;
		base = rand() & 7;								// colour base for direction colours
		for (int i = 0; i < MAXDOT; i++) {
			// pick random locations and directions, make colour match direction
			dots [i] = rand() % NLIGHTS;
			directions [i] = rand() % 8;
			direction_to_colour (directions [i], base, rgbs [i]);
			speeds [i] = reset_speeds [i] = (rand() % 50) + 1;
		}
		start = time_us_64();
	}

	if (rotor++ >= 1) {
		rotor = 0;
		clear_leds ();
		for (int i = 0; i < MAXDOT; i++) {
			setRGB (dots [i], rgbs [i]);
			int l = find_adjacent (dots [i], directions [i]);
			if (l == dots [i]) {
				dots [i] = rand() % NLIGHTS;
				directions [i] = rand() % 8;
				direction_to_colour (directions [i], base, rgbs [i]);
				continue;
			}

			directions [i] = fixdir (directions [i], dots [i], l);
			dots [i] = l;
			direction_to_colour (directions [i], base, rgbs [i]);
			if (speeds [i]-- <= 0) {
				dots [i] = find_adjacent (dots [i], (directions [i] + 2) % 8);
				speeds [i] = reset_speeds [i];
			}
		}
	}

	return seconds_since (start) < 30;
#undef	MAXDOT
}

#ifdef	PROTOTYPE
static bool
pattern_use_this_prototype_for_new_patterns (bool init)
{
	static uint64_t start;
	static int rotor;

	if (init) {
		start = time_us_64();
		rotor = 0;
	}

	if (rotor++ > some_value) {
		rotor = 0;
		// do something interesting
	}
	return seconds_since (start) < 30;
}
#endif	// PROTOTYPE

static bool
pattern_sine (bool init)
{
	static uint64_t start;
	static int rotor;
	static double freq [4][NCOLS];
	static uint8_t rgbs [4][3];
	static int iteration;

	if (init) {
		start = time_us_64();
		rotor = 0;

		for (int face = 0; face < 4; face++) {
			freq [face][0] = (double) (rand() % 1000) / 20000. ;
			for (int c = 1; c < NCOLS; c++) {
				freq [face][c] = freq [face][c - 1] + (double) (rand() % 1000) / 300000.;
			}
			pickRGB (rgbs [face]);
		}
		iteration = 0;
	}

	if (rotor++ >= 0) {
		rotor = 0;
		iteration++;
		double totals [3] = { 0 };
		for (int face = 0; face < 4; face++) {
			for (int c = 0; c < NCOLS; c++) {
				double v = (sin (freq [face][c] * iteration) + 1) * (NROWS / 2);
				for (int r = 0; r < NROWS; r++) {
					if ((int) v == r) {
						setRGB (frc_to_index (face + 1, r, c), rgbs [face]);
						totals [0] += rgbs [face][0] * r;
						totals [1] += rgbs [face][1] * r;
						totals [2] += rgbs [face][2] * r;
					} else {
						clear_led (frc_to_index (face + 1, r, c));
					}
				}
			}
		}
		totals [0] /= (NFACES - 1) * NROWS * NCOLS * NROWS;
		totals [1] /= (NFACES - 1) * NROWS * NCOLS * NROWS;
		totals [2] /= (NFACES - 1) * NROWS * NCOLS * NROWS;
		if (totals [0] > 255) totals [0] = 255;
		if (totals [1] > 255) totals [1] = 255;
		if (totals [2] > 255) totals [2] = 255;
		set_face_individual (0, totals [R], totals [G], totals [B]);
	}

	return seconds_since (start) < 30;
}

static bool (*patterns []) (bool) =
{
	pattern_alignment,									// shows up once at power up; persists during #define MANUFACTURING
	pattern_sequence_colour,
	pattern_trajectory,
	pattern_top_bleed,
	pattern_sine,
	pattern_mover,
	pattern_sequential_dots,
	pattern_random_alnum,
	pattern_sparkle,
	pattern_colour_distance,
#if 0
#endif
};

static void
generate_pattern (void)
{
	static int rotor = 0;
	static bool init = true;

	if (init) {
		patterns [rotor] (true);						// we're assuming that the pattern will want to get called more than once
		init = false;
	} else {
		if (!patterns [rotor] (false)) {
			rotor = (rotor + 1) % NELEMENTS (patterns);
			init = true;
			set_persistence (DEFAULT_PERSISTENCE);		// each pattern can reset this to whatever they want, this is pleasing for most
		}
	}
}

// not the best, but better than nothing; more research required
static void
init_seed (void)
{
	adc_init();
	adc_gpio_init(26);
	uint64_t hash = 0;
	for (int j = 0; j < 1000; j++) {
		for (int i = 0; i < 3; i++) {
			adc_select_input(i);
		    uint16_t result = adc_read();
			hash += result;
			sleep_us (100);
		}
	}
	srand (hash);
}

extern int t0h, t0l, t1h, t1l, tdelay;

extern void reset (void);

static void use (void)
{
	printf ("Use:\n");
	printf ("a/z +/- T0H\n");
	printf ("s/x +/- T0L\n");
	printf ("d/c +/- T1H\n");
	printf ("f/v +/- T1L\n");
	printf ("w/e +/- TDELAY (by 10)\n");
	printf ("q -- reset to defaults\n");
	printf ("any other key to run pattern\n");
}

int main ()
{
//#define	DEBUG
#ifdef	DEBUG
stdio_init_all ();
//stdio_set_translate_crlf (&stdio_usb, false);
sleep_ms (4000);
use();
#endif	// DEBUG

	init_hardware ();
	init_seed ();
	init_metadata ();

	for (;;) {
		generate_pattern ();
		write_leds();
		sleep_ms (10);
	}
}

