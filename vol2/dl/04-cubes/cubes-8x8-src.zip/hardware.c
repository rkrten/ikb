
/*
 *	hardware.c
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Hardware interface for borg cube, IKCH42A.
 *
 *	2023 09 28	R. Krten		Separated out from main
*/

#include "ikch42.h"

#define	WS2812	21										// this is the next most useless gpio port :-)
														// and yes, you can power the WS2812 *directly* from this PICO pin!

/*
 * The timings for the bits are supposed to be:
 *
 *	T0H		220 -  380 ns
 *	T0L		580 - 1600 ns
 *	T1H		580 - 1600 ns
 *	T1L		220 -  420 ns
 *
 *	but in reality it looks like the tail end (the "low" time) wants to be longer.
 *
 *	Of course, this should be done by the PIO state machines, not by bit banging.
 *
 *	This is what the state machine outputs:
 *
 *		T1	2	250 ns
 *		T2	5	620 ns
 *		T3	3	370 ns
 *
 *	And to output a
 *		0: we go high for T1 and low for (T2 + T3)
 *		1: we go high for (T1 + T2) and low for T3
*/

#define	T0H		10
#define	T0L		30
#define	T1H		30
#define	T1L		30
#define	TDELAY	300										// 275us is the minimum for the '15, 200us works for the '12

#define	HIGH	1
#define	LOW		0

int	t0h = T0H;
int	t0l = T0L;
int	t1h = T1H;
int	t1l = T1L;
int tdelay = TDELAY;

void
reset (void)
{
	t0h = T0H;
	t0l = T0L;
	t1h = T1H;
	t1l = T1L;
	tdelay = TDELAY;
}

static inline void
toggle (int h, int l)
{
	for (int t = 0; t < h; t++) {
		gpio_put (WS2812, HIGH);
	}
	for (int t = 0; t < l; t++) {
		gpio_put (WS2812, LOW);
	}
}

static uint8_t persistence [NLIGHTS][3];
static int factor = DEFAULT_PERSISTENCE;

void
set_persistence (int f)
{
	factor = f;
}

/*
 *	On the 8x8 cube, the led ordering matches the software ordering (both are row major ordered):
 *
 *	0		1		...		6		7
 *	8		9		...		14		15
 *	...		...		...		...		...
 *	46		47		...		54		55
 *	54		55		...		62		63
 *
 *	led_number = row * NCOLS + col
*/

// @@@ todo: change this to use the PIO state machine

void
write_leds (void)
{
//asm volatile ("cpsid i");
	for (int i = 0; i < NLIGHTS; i++) {
		for (int c = 0; c < 3; c++) {
			int v = leds [i][c] + persistence [i][c];
			if (v > 255) v = 255;
			for (int b = 7; b >= 0; b--) {
				if (v & (1 << b)) {
					toggle (T1H, T1L);
				} else {
					toggle (T0H, T0L);
				}
			}
			persistence [i][c] = v * factor / 100;	// fadeout
		}
	}
//asm volatile ("cpsie i");
	sleep_us (tdelay);
}

void
init_hardware (void)
{
	gpio_init (WS2812);
	gpio_set_dir (WS2812, GPIO_OUT);
	gpio_put (WS2812, LOW);
}

