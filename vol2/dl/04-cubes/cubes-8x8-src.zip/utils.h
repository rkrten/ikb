
/*
 *	utils.h
 *
 *	(C) Copyright 2023 by Robert Krten, all rights reserved.
 *
 *	Include file for utilities.
 *
 *	2023 09 28	R. Krten		created
*/

#include <stdint.h>

uint8_t *pickRGB (uint8_t *rgb);						// selects random exponential-scale colour
int seconds_since (uint64_t t);
